# Fixes 1–3 — Status

Six files changed. Run `npm run typecheck` after applying — I can't compile
in this environment, so the type-level claims below are verified by reading
the schema, not by `tsc`.

## #1 — Rate-limit testing values (server/config/rate-limits.ts)

Found **three** testing-mode bumps, not one:

| Limiter | Was (testing) | Restored | Env override |
|---|---|---|---|
| TELEMETRY | 10000/min | 120/min | `RATE_LIMIT_TELEMETRY_MAX` |
| WRITE_OPERATIONS | 5000/min | 60/min | `RATE_LIMIT_WRITE_MAX` |
| ML_TRAINING | 100/hr | 5/hr | `RATE_LIMIT_ML_TRAINING_MAX` |

Added a `maxFromEnv()` helper so future load/accuracy testing raises a
ceiling via env var instead of editing committed code — which is how the
testing values shipped in the first place. Defaults are always the safe
production value.

## #2 — settings-service.ts `as any` removal + a real bug

Removed all 6 live `as any` casts. The schema caught up since the casts were
added (the `alert_settings` table now has `api_key_encrypted`,
`smtp_encrypted_password`, `last_test_status`, `last_test_at`,
`last_test_error`, `email_enabled`, `smtp_host`, etc.), so the encryption-
field and lastTest casts were dead scar tissue — removed.

**Surfaced a real bug:** `shouldSendAlert()` called
`(alertSettingsRepository as any).checkCooldown(...)` — but `checkCooldown`
**does not exist** on the repository (it has `getCooldown`, `isInCooldown`,
etc.). The `as any` made it return `undefined` at runtime, so the
`if (!existing) return { shouldSend: true }` branch always fired —
**alert cooldown was silently disabled, every alert always sent.**

Fixed by wiring to the real `getCooldown(orgId, alertType, alertKey, vesselId)`.
Note: `shouldSendAlert` is currently uncalled (no callers in the tree), so
this is a latent bug — it would have fired the moment an alert pipeline
started using it. Behavior change: cooldown now actually works when wired.
The `entityId` param on `shouldSendAlert`/`recordAlertSent` is now unused
(getCooldown doesn't take it); left in place since `noUnusedParameters`
isn't enabled and removing it would change the public method signature.

## #3 — server/db cross-DB cast cluster (partial — see below)

Reduced server/db `as any` from **121 → 111**. This is deliberately partial:
the cluster splits into categories with very different risk profiles, and
blasting all 121 blind would re-introduce exactly the bugs these casts hide.

### Done

**hub-sync `devices` cluster — fixed a live bug.** `getDevices(orgId, vesselId)`
filtered on `(devices as any).vesselId` and ordered by `(devices as any).name`,
but the `devices` table has no such columns — it has `vessel` and `label`.
The `vesselId` filter produced an invalid query whenever a vesselId was
passed. Fixed to `devices.vessel` / `devices.label`.

**Two dead-broken methods made fail-loud.** `getDeviceByDeviceId` and
`updateDeviceLastSeen` referenced `deviceId` / `lastSeenAt` columns that
**exist on no devices table**, masked by `as any`. Both are uncalled. Rather
than silently mis-query, they now throw a descriptive error documenting the
schema gap, so they fail visibly if anyone wires them before the schema
question is resolved.

**7 redundant casts removed** (column provably exists — zero behavior change):

```
edgeHeartbeats.id        telemetry/db-telemetry.ts
portCall.start           crew-extensions/db-crew-extensions.ts
drydockWindow.start      crew-extensions/db-crew-extensions.ts
rawTelemetry.equipmentId equipment/db-equipment.ts
twinSimulations.equipmentId    equipment/db-equipment.ts
insightReports.equipmentId     equipment/db-equipment.ts
insightSnapshots.equipmentId   equipment/db-equipment.ts
```

### Remaining server/db casts (111), categorized

| Count | Category | Recommended fix |
|---|---|---|
| ~13 | `(table as any).column` — **column genuinely missing** | Per-cast decision: column-name map (like devices) or add column via migration. Each needs verification of intent. Same risk profile as the devices bug — do NOT batch-fix. |
| ~22 | `(table as any).column` — table resolved through `schema-runtime` indirection, couldn't statically verify | Verify each against the live pg/sqlite table the `pickSchema` switch returns. |
| ~15 | `.values(x as any)` — dual-DB insert friction | **Root-cause fix** in `shared/schema-runtime.ts`: align `InsertX` types with the `pickSchema`-returned table type so `.values(x)` typechecks without casts. One fix kills many. |
| ~14 | `.set({...} as any)` — dual-DB update friction | Same root-cause fix as above. |
| ~44 | `}) as any` and misc query-builder coercions | Mostly return-type coercions from the dual-DB `db` client typing; resolve alongside the schema-runtime fix. |

### Why #3 isn't finished in one pass

The 29 insert/set casts and the 44 query-builder casts share **one root
cause**: the `pickSchema<T>(useSqlite, sqliteTable, pgTable): T` helper in
`schema-runtime.ts` returns the Postgres table type, but the `InsertX` /
`SelectX` types and the `db` client typing don't fully align with it, so
Drizzle's `.values()` / `.set()` / `.returning()` reject the inputs. Fixing
that plumbing once (typing `pickSchema` so insert/select types track the
returned table) eliminates most of the 29+44 casts across all 26 files
simultaneously. That's a focused, foundational change worth its own wave —
and worth doing with `tsc` in the loop, which I don't have here.

The 13 column-missing casts are the genuinely dangerous ones (each could be
hiding a bug like the devices/cooldown ones). They need per-cast intent
decisions — exactly the work that shouldn't be automated.

## Suggested next wave

1. **schema-runtime type alignment** — kills ~73 of the remaining 111 casts
   at the root, with tsc verifying. One file, high leverage.
2. **column-missing audit** — walk the 13 (+22 unresolved) `(table as any).column`
   casts one at a time; each is a potential hidden bug like the two I found here.
3. **`as any` regression gate** — baseline 1,102 (whole repo) and block growth
   so this doesn't backslide.
