/**
 * Crew Extensions - Database Storage
 */

import { eq, and, lte, asc, isNull } from "drizzle-orm";
import { db } from "../../db";
import {
  crewCertification,
  crewDocuments,
  crewNotificationSettings,
  portCall,
  drydockWindow,
  type SelectCrewCertification,
  type InsertCrewCertification,
  type SelectCrewDocument,
  type InsertCrewDocument,
  type CrewNotificationSettings,
  type PortCall as SelectPortCall,
  type InsertPortCall,
  type DrydockWindow as SelectDrydockWindow,
  type InsertDrydockWindow,
} from "@shared/schema";
import type { AlertScanResult, NotificationSettingsData } from "./types.js";

export class DbCrewExtensionsStorage {
  async getCrewCertifications(crewId?: string): Promise<SelectCrewCertification[]> {
    const q: any = crewId
      ? db.select().from(crewCertification).where(eq(crewCertification.crewId, crewId))
      : db.select().from(crewCertification);
    return q.orderBy(crewCertification.expiresAt);
  }
  async createCrewCertification(cert: InsertCrewCertification): Promise<SelectCrewCertification> {
    const [n] = await db.insert(crewCertification).values(cert).returning();
    return n;
  }
  async updateCrewCertification(
    id: string,
    cert: Partial<InsertCrewCertification>
  ): Promise<SelectCrewCertification> {
    const [u] = await db
      .update(crewCertification)
      .set(cert)
      .where(eq(crewCertification.id, id))
      .returning();
    if (!u) {
      throw new Error(`Crew certification ${id} not found`);
    }
    return u;
  }
  async deleteCrewCertification(id: string): Promise<void> {
    const r = await db.delete(crewCertification).where(eq(crewCertification.id, id));
    if (r.rowCount === 0) {
      throw new Error(`Crew certification ${id} not found`);
    }
  }
  async getCertificationsExpiring(
    orgId: string,
    daysAhead: number = 90,
    includeAcknowledged: boolean = false
  ): Promise<SelectCrewCertification[]> {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + daysAhead);
    const c = [eq(crewCertification.orgId, orgId), lte(crewCertification.expiresAt, futureDate)];
    if (!includeAcknowledged) {
      c.push(isNull(crewCertification.alertAcknowledgedAt));
    }
    return db
      .select()
      .from(crewCertification)
      .where(and(...c))
      .orderBy(asc(crewCertification.expiresAt));
  }
  async acknowledgeCertificationAlert(
    certId: string,
    userId?: string,
    notes?: string
  ): Promise<SelectCrewCertification> {
    const [u] = await db
      .update(crewCertification)
      .set({
        alertAcknowledged: true,
        alertAcknowledgedAt: new Date(),
        alertAcknowledgedBy: userId || null,
        alertAcknowledgedNotes: notes || null,
      })
      .where(eq(crewCertification.id, certId))
      .returning();
    if (!u) {
      throw new Error(`Crew certification ${certId} not found`);
    }
    return u;
  }
  async updateCertificationAlertFlags(orgId: string): Promise<AlertScanResult> {
    const now = new Date();
    const date30 = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const date60 = new Date(now.getTime() + 60 * 24 * 60 * 60 * 1000);
    const date90 = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000);
    const allCerts = await db
      .select()
      .from(crewCertification)
      .where(and(eq(crewCertification.orgId, orgId), lte(crewCertification.expiresAt, date90)));
    let flagged = 0,
      critical = 0,
      warning = 0,
      notice = 0;
    for (const cert of allCerts) {
      const expiryDate = new Date(cert.expiresAt!);
      const needsUpdate: Partial<InsertCrewCertification> = { alertLastScannedAt: now };
      let needsFlag = false;
      if (expiryDate <= date90 && !cert.alertSent90) {
        needsUpdate.alertSent = true;
        needsUpdate.alertSent90 = true;
        needsFlag = true;
        notice++;
      }
      if (expiryDate <= date60 && !cert.alertSent60) {
        needsUpdate.alertSent = true;
        needsUpdate.alertSent60 = true;
        needsFlag = true;
        warning++;
      }
      if (expiryDate <= date30 && !cert.alertSent30) {
        needsUpdate.alertSent = true;
        needsUpdate.alertSent30 = true;
        needsFlag = true;
        critical++;
      }
      if (needsFlag) {
        await db
          .update(crewCertification)
          .set(needsUpdate)
          .where(eq(crewCertification.id, cert.id));
        flagged++;
      }
    }
    return { scanned: allCerts.length, flagged, critical, warning, notice };
  }

  async getCrewDocuments(crewId: string): Promise<SelectCrewDocument[]> {
    return db.select().from(crewDocuments).where(eq(crewDocuments.crewId, crewId));
  }
  async getCrewDocumentById(id: string): Promise<SelectCrewDocument | undefined> {
    const [doc] = await db.select().from(crewDocuments).where(eq(crewDocuments.id, id));
    return doc;
  }
  async createCrewDocument(doc: InsertCrewDocument): Promise<SelectCrewDocument> {
    const [n] = await db.insert(crewDocuments).values(doc).returning();
    return n;
  }
  async updateCrewDocument(
    id: string,
    doc: Partial<InsertCrewDocument>
  ): Promise<SelectCrewDocument> {
    const [u] = await db
      .update(crewDocuments)
      .set({ ...doc, updatedAt: new Date() })
      .where(eq(crewDocuments.id, id))
      .returning();
    if (!u) {
      throw new Error(`Crew document ${id} not found`);
    }
    return u;
  }
  async deleteCrewDocument(id: string): Promise<void> {
    const r = await db.delete(crewDocuments).where(eq(crewDocuments.id, id));
    if (r.rowCount === 0) {
      throw new Error(`Crew document ${id} not found`);
    }
  }
  async getDocumentsExpiring(
    orgId: string,
    daysAhead: number = 90,
    includeAcknowledged: boolean = false
  ): Promise<SelectCrewDocument[]> {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + daysAhead);
    const c = [eq(crewDocuments.orgId, orgId), lte(crewDocuments.expiresAt, futureDate)];
    if (!includeAcknowledged) {
      c.push(isNull(crewDocuments.alertAcknowledgedAt));
    }
    return db
      .select()
      .from(crewDocuments)
      .where(and(...c))
      .orderBy(asc(crewDocuments.expiresAt));
  }
  async acknowledgeDocumentAlert(
    docId: string,
    userId?: string,
    notes?: string
  ): Promise<SelectCrewDocument> {
    const [u] = await db
      .update(crewDocuments)
      .set({
        alertAcknowledged: true,
        alertAcknowledgedAt: new Date(),
        alertAcknowledgedBy: userId || null,
        alertAcknowledgedNotes: notes || null,
      })
      .where(eq(crewDocuments.id, docId))
      .returning();
    if (!u) {
      throw new Error(`Crew document ${docId} not found`);
    }
    return u;
  }
  async updateDocumentAlertFlags(orgId: string): Promise<AlertScanResult> {
    const now = new Date();
    const date30 = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const date60 = new Date(now.getTime() + 60 * 24 * 60 * 60 * 1000);
    const date90 = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000);
    const allDocs = await db
      .select()
      .from(crewDocuments)
      .where(and(eq(crewDocuments.orgId, orgId), lte(crewDocuments.expiresAt, date90)));
    let flagged = 0,
      critical = 0,
      warning = 0,
      notice = 0;
    for (const doc of allDocs) {
      if (!doc.expiresAt) {
        continue;
      }
      const expiryDate = new Date(doc.expiresAt);
      const needsUpdate: Partial<InsertCrewDocument> = { alertLastScannedAt: now };
      let needsFlag = false;
      if (expiryDate <= date90 && !doc.alertSent90) {
        needsUpdate.alertSent = true;
        needsUpdate.alertSent90 = true;
        needsFlag = true;
        notice++;
      }
      if (expiryDate <= date60 && !doc.alertSent60) {
        needsUpdate.alertSent = true;
        needsUpdate.alertSent60 = true;
        needsFlag = true;
        warning++;
      }
      if (expiryDate <= date30 && !doc.alertSent30) {
        needsUpdate.alertSent = true;
        needsUpdate.alertSent30 = true;
        needsFlag = true;
        critical++;
      }
      if (needsFlag) {
        await db.update(crewDocuments).set(needsUpdate).where(eq(crewDocuments.id, doc.id));
        flagged++;
      }
    }
    return { scanned: allDocs.length, flagged, critical, warning, notice };
  }

  async getCrewNotificationSettings(
    crewId: string,
    orgId: string
  ): Promise<CrewNotificationSettings | undefined> {
    const [s] = await db
      .select()
      .from(crewNotificationSettings)
      .where(
        and(eq(crewNotificationSettings.crewId, crewId), eq(crewNotificationSettings.orgId, orgId))
      );
    return s;
  }
  async upsertCrewNotificationSettings(
    crewId: string,
    orgId: string,
    data: NotificationSettingsData
  ): Promise<CrewNotificationSettings> {
    const existing = await this.getCrewNotificationSettings(crewId, orgId);
    if (existing) {
      const [u] = await db
        .update(crewNotificationSettings)
        .set({ ...data, updatedAt: new Date() })
        .where(eq(crewNotificationSettings.id, existing.id))
        .returning();
      return u;
    }
    const [c] = await db
      .insert(crewNotificationSettings)
      .values({
        crewId,
        orgId,
        emailAlertsEnabled: data.emailAlertsEnabled ?? true,
        certExpiryEmailEnabled: data.certExpiryEmailEnabled ?? true,
        documentExpiryEmailEnabled: data.documentExpiryEmailEnabled ?? true,
        complianceEmailEnabled: data.complianceEmailEnabled ?? true,
        overrideEmail: data.overrideEmail,
      })
      .returning();
    return c;
  }
  async getAllCrewNotificationSettings(orgId: string): Promise<CrewNotificationSettings[]> {
    return db
      .select()
      .from(crewNotificationSettings)
      .where(eq(crewNotificationSettings.orgId, orgId));
  }

  async getPortCalls(vesselId?: string): Promise<SelectPortCall[]> {
    const q: any = vesselId
      ? db.select().from(portCall).where(eq(portCall.vesselId, vesselId))
      : db.select().from(portCall);
    return q.orderBy(portCall.start);
  }
  async createPortCall(portCallData: InsertPortCall): Promise<SelectPortCall> {
    const [n] = await db.insert(portCall).values(portCallData).returning();
    return n;
  }
  async updatePortCall(id: string, portCallData: Partial<InsertPortCall>): Promise<SelectPortCall> {
    const [u] = await db.update(portCall).set(portCallData).where(eq(portCall.id, id)).returning();
    if (!u) {
      throw new Error(`Port call ${id} not found`);
    }
    return u;
  }
  async deletePortCall(id: string): Promise<void> {
    const r = await db.delete(portCall).where(eq(portCall.id, id));
    if (r.rowCount === 0) {
      throw new Error(`Port call ${id} not found`);
    }
  }

  async getDrydockWindows(vesselId?: string): Promise<SelectDrydockWindow[]> {
    const q: any = vesselId
      ? db.select().from(drydockWindow).where(eq(drydockWindow.vesselId, vesselId))
      : db.select().from(drydockWindow);
    return q.orderBy(drydockWindow.start);
  }
  async createDrydockWindow(drydockData: InsertDrydockWindow): Promise<SelectDrydockWindow> {
    const [n] = await db.insert(drydockWindow).values(drydockData).returning();
    return n;
  }
  async updateDrydockWindow(
    id: string,
    drydockData: Partial<InsertDrydockWindow>
  ): Promise<SelectDrydockWindow> {
    const [u] = await db
      .update(drydockWindow)
      .set(drydockData)
      .where(eq(drydockWindow.id, id))
      .returning();
    if (!u) {
      throw new Error(`Drydock window ${id} not found`);
    }
    return u;
  }
  async deleteDrydockWindow(id: string): Promise<void> {
    const r = await db.delete(drydockWindow).where(eq(drydockWindow.id, id));
    if (r.rowCount === 0) {
      throw new Error(`Drydock window ${id} not found`);
    }
  }
}
