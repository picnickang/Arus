/**
 * Inventory Management Page
 *
 * UX / Code fixes applied:
 * 1. Stat cards (Critical/Out, Low Stock) are now clickable and apply the
 *    corresponding stockStatus filter directly.
 * 2. Mobile filter badge no longer overflows for counts > 9 (uses "9+" cap).
 * 3. "Apply Filters" button renamed to "View Results" — filters are already
 *    applied live, the button only closes the sheet.
 * 4. standardCost field allows empty string while editing instead of
 *    immediately resetting to 0.
 * 5. Empty state shown when the inventory is genuinely empty (no parts at all).
 * 6. Category dropdown in Add/Edit form is driven by filterOptions.categories
 *    so dynamically-created categories (e.g. via API) remain selectable.
 *    A hardcoded fallback list is used when filterOptions is not yet loaded.
 */

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ResponsiveDialog } from "@/components/ResponsiveDialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  Plus, Package, DollarSign, TrendingDown, Layers, Download,
  AlertCircle, Filter, PanelLeftClose, PanelLeftOpen, PackageX,
} from "lucide-react";
import VirtualizedInventoryTable from "@/components/inventory/VirtualizedInventoryTable";
import InventoryFilterPanel from "@/components/inventory/InventoryFilterPanel";
import PartDetailDrawer from "@/components/inventory/PartDetailDrawer";
import { SupplierMultiSelect } from "@/components/inventory/SupplierMultiSelect";
import { useInventoryManagementData } from "@/features/inventory";
import { formatCurrency } from "@/lib/formatters";
import { PermissionGate } from "@/components/PermissionGate";

// ── Fallback categories used when filterOptions hasn't loaded yet ──────────────
const FALLBACK_CATEGORIES = [
  "filters", "belts", "fluids", "electrical", "mechanical", "hydraulics",
  "safety", "navigation", "deck", "engine", "other",
];

export default function InventoryManagement() {
  const {
    partsInventory,
    filteredParts,
    isLoadingInventory,
    stats,
    filterOptions,
    activeFilterCount,
    filters,
    setFilters,
    sortField,
    sortDirection,
    handleSort,
    handleClearFilters,
    isAddPartDialogOpen,
    isEditPartDialogOpen,
    editingPart,
    selectedPart,
    isDrawerOpen,
    setIsDrawerOpen,
    isFilterPanelOpen,
    setIsFilterPanelOpen,
    isMobileFilterOpen,
    setIsMobileFilterOpen,
    partForm,
    createPartMutation,
    updatePartMutation,
    handleAddPart,
    handleEditPart,
    handleDeletePart,
    handleRowClick,
    onSubmitPart,
    handleExportCSV,
    handlePartDialogClose,
    handlePartDetailEdit,
  } = useInventoryManagementData();

  // ── Helpers ──────────────────────────────────────────────────────────────────

  // FIX: cap badge display at 9+ to prevent overflow of the 16px badge container
  const filterBadgeLabel = activeFilterCount > 9 ? "9+" : activeFilterCount;

  // FIX: derive category options from live filter data, fall back to static list
  const categoryOptions =
    filterOptions?.categories?.length > 0
      ? filterOptions.categories.map((c: { value: string; label: string }) => c.value)
      : FALLBACK_CATEGORIES;

  // Shortcut: apply a stockStatus filter directly from a stat card click
  const applyStockStatusFilter = (status: string) => {
    setFilters((prev: typeof filters) => ({ ...prev, stockStatus: status }));
  };

  // ── Empty state ──────────────────────────────────────────────────────────────
  const isGenuinelyEmpty = !isLoadingInventory && partsInventory.length === 0;

  return (
    <div className="min-h-screen flex flex-col" data-testid="inventory-management-page">

      {/* ── Toolbar ──────────────────────────────────────────────────────────── */}
      <div className="flex-none p-4 md:p-6 pb-0 md:pb-0">
        <div className="flex flex-wrap items-center justify-end gap-3 mb-4">
          <div className="flex gap-2">
            {/* Mobile filter toggle */}
            <Button
              variant="outline"
              size="icon"
              onClick={() => setIsMobileFilterOpen(true)}
              className="md:hidden relative"
              data-testid="toggle-filters-mobile"
            >
              <Filter className="h-4 w-4" />
              {/* FIX: capped at "9+" to prevent overflow of the fixed 16px badge */}
              {activeFilterCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[1rem] h-4 px-0.5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                  {filterBadgeLabel}
                </span>
              )}
            </Button>

            <PermissionGate resource="inventory" action="export">
              <Button variant="outline" onClick={handleExportCSV} data-testid="button-export-csv">
                <Download className="h-4 w-4 mr-2" />Export CSV
              </Button>
            </PermissionGate>

            <PermissionGate resource="inventory" action="create">
              <Button onClick={handleAddPart} data-testid="button-add-part">
                <Plus className="h-4 w-4 mr-2" />Add Part
              </Button>
            </PermissionGate>
          </div>
        </div>

        {/* ── Stats bar ─────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-4 mb-4">
          <Card className="bg-card" data-testid="stat-total-parts">
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs md:text-sm font-medium text-muted-foreground">Total Parts</p>
                  <h3 className="text-xl md:text-2xl font-bold mt-1">{stats.totalParts}</h3>
                </div>
                <Package className="h-8 w-8 text-muted-foreground opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card" data-testid="stat-total-value">
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs md:text-sm font-medium text-muted-foreground">Total Value</p>
                  <h3 className="text-xl md:text-2xl font-bold mt-1">{formatCurrency(stats.totalValue)}</h3>
                </div>
                <DollarSign className="h-8 w-8 text-green-600 dark:text-green-400 opacity-50" />
              </div>
            </CardContent>
          </Card>

          {/*
            FIX: Critical/Out and Low Stock cards are now clickable.
            They were displayed in red/yellow implying actionability but did nothing on click.
            Clicking now applies the corresponding stockStatus filter.
          */}
          <Card
            className="bg-card cursor-pointer hover:bg-muted/50 transition-colors"
            data-testid="stat-critical"
            onClick={() => applyStockStatusFilter(filters.stockStatus === "critical" ? "all" : "critical")}
            title="Click to filter by Critical / Out of Stock"
          >
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs md:text-sm font-medium text-muted-foreground">Critical/Out</p>
                  <h3 className="text-xl md:text-2xl font-bold mt-1 text-destructive">{stats.criticalCount}</h3>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    {filters.stockStatus === "critical" ? "▶ Filtering now" : "Click to filter"}
                  </p>
                </div>
                <AlertCircle className="h-8 w-8 text-destructive opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card
            className="bg-card cursor-pointer hover:bg-muted/50 transition-colors"
            data-testid="stat-low-stock"
            onClick={() => applyStockStatusFilter(filters.stockStatus === "low" ? "all" : "low")}
            title="Click to filter by Low Stock"
          >
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs md:text-sm font-medium text-muted-foreground">Low Stock</p>
                  <h3 className="text-xl md:text-2xl font-bold mt-1 text-yellow-600 dark:text-yellow-400">
                    {stats.lowStockCount}
                  </h3>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    {filters.stockStatus === "low" ? "▶ Filtering now" : "Click to filter"}
                  </p>
                </div>
                <TrendingDown className="h-8 w-8 text-yellow-600 dark:text-yellow-400 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card" data-testid="stat-categories">
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs md:text-sm font-medium text-muted-foreground">Categories</p>
                  <h3 className="text-xl md:text-2xl font-bold mt-1">{stats.categories}</h3>
                </div>
                <Layers className="h-8 w-8 text-muted-foreground opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ── Main content ──────────────────────────────────────────────────────── */}
      <div className="flex-1 px-4 md:px-6 pb-4 md:pb-6 min-h-0">
        <Card className="h-full flex flex-col">
          <CardHeader className="flex-none pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />Parts Catalog & Stock Levels
                </CardTitle>
                <CardDescription>
                  Showing {filteredParts.length} of {partsInventory.length} parts
                  {activeFilterCount > 0 && (
                    <Badge variant="secondary" className="ml-2">{activeFilterCount} filters active</Badge>
                  )}
                </CardDescription>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
                className="hidden md:flex"
                data-testid="toggle-filters"
              >
                {isFilterPanelOpen
                  ? <><PanelLeftClose className="h-4 w-4 mr-2" />Hide Filters</>
                  : <><PanelLeftOpen  className="h-4 w-4 mr-2" />Show Filters</>}
              </Button>
            </div>
          </CardHeader>

          <CardContent className="flex-1 p-0 min-h-0">
            <div className="flex h-full">
              {isFilterPanelOpen && (
                <div className="w-64 border-r flex-none hidden md:block">
                  <InventoryFilterPanel
                    filters={filters}
                    onFiltersChange={setFilters}
                    filterOptions={filterOptions}
                    activeFilterCount={activeFilterCount}
                    onClearAll={handleClearFilters}
                    className="h-full"
                  />
                </div>
              )}

              <div className="flex-1 p-4 overflow-hidden">
                {/* FIX: empty state when catalog has no parts at all */}
                {isGenuinelyEmpty ? (
                  <div className="flex flex-col items-center justify-center h-full text-center gap-4 text-muted-foreground">
                    <PackageX className="h-16 w-16 opacity-30" />
                    <div>
                      <p className="font-medium text-foreground">No parts in catalog yet</p>
                      <p className="text-sm mt-1">Add your first part to start tracking inventory.</p>
                    </div>
                    <PermissionGate resource="inventory" action="create">
                      <Button onClick={handleAddPart} data-testid="button-add-first-part">
                        <Plus className="h-4 w-4 mr-2" />Add First Part
                      </Button>
                    </PermissionGate>
                  </div>
                ) : (
                  <VirtualizedInventoryTable
                    items={filteredParts}
                    isLoading={isLoadingInventory}
                    sortField={sortField}
                    sortDirection={sortDirection}
                    onSort={handleSort}
                    onRowClick={handleRowClick}
                    onEdit={handleEditPart}
                    onDelete={handleDeletePart}
                  />
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Part detail drawer ────────────────────────────────────────────────── */}
      <PartDetailDrawer
        part={selectedPart}
        open={isDrawerOpen}
        onOpenChange={setIsDrawerOpen}
        onEdit={handlePartDetailEdit}
      />

      {/* ── Mobile filter sheet ───────────────────────────────────────────────── */}
      <Sheet open={isMobileFilterOpen} onOpenChange={setIsMobileFilterOpen}>
        <SheetContent side="left" className="w-[300px] sm:w-[350px] p-0">
          <SheetHeader className="p-4 border-b">
            <div className="flex items-center justify-between">
              <SheetTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />Filters
              </SheetTitle>
              {activeFilterCount > 0 && (
                <Badge variant="secondary">{activeFilterCount} active</Badge>
              )}
            </div>
          </SheetHeader>
          <div className="h-[calc(100vh-80px)] overflow-auto">
            <InventoryFilterPanel
              filters={filters}
              onFiltersChange={setFilters}
              filterOptions={filterOptions}
              activeFilterCount={activeFilterCount}
              onClearAll={handleClearFilters}
              className="h-full"
            />
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t bg-background">
            {/*
              FIX: was "Apply Filters (N results)" implying the button triggers filtering.
              Filters are already applied live. The button just closes the sheet.
              Renamed to "View Results" to accurately describe the action.
            */}
            <Button
              className="w-full"
              onClick={() => setIsMobileFilterOpen(false)}
              data-testid="button-apply-filters-mobile"
            >
              View Results ({filteredParts.length})
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* ── Add / Edit part dialog ────────────────────────────────────────────── */}
      <ResponsiveDialog
        open={isAddPartDialogOpen || isEditPartDialogOpen}
        onOpenChange={handlePartDialogClose}
        title={editingPart ? "Edit Part" : "Add New Part"}
        description={
          editingPart ? "Update the details for this part." : "Enter the details for the new part."
        }
        footer={
          <div className="flex gap-2 w-full">
            <Button
              variant="outline"
              onClick={() => handlePartDialogClose(false)}
              className="flex-1"
              data-testid="button-cancel-part"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              onClick={partForm.handleSubmit(onSubmitPart)}
              disabled={createPartMutation.isPending || updatePartMutation.isPending}
              className="flex-1"
              data-testid="button-save-part"
            >
              {editingPart
                ? updatePartMutation.isPending ? "Updating..." : "Update Part"
                : createPartMutation.isPending ? "Adding..."   : "Add Part"}
            </Button>
          </div>
        }
      >
        <Form {...partForm}>
          <form onSubmit={partForm.handleSubmit(onSubmitPart)} className="space-y-2">

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField control={partForm.control} name="partNumber" render={({ field }) => (
                <FormItem>
                  <FormLabel>Part Number *</FormLabel>
                  <FormControl>
                    <Input placeholder="P12345" {...field} data-testid="input-part-number" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={partForm.control} name="partName" render={({ field }) => (
                <FormItem>
                  <FormLabel>Part Name *</FormLabel>
                  <FormControl>
                    <Input placeholder="Marine engine filter" {...field} data-testid="input-part-name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <FormField control={partForm.control} name="description" render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea placeholder="Part description..." {...field} data-testid="input-description" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/*
                FIX: category dropdown now driven by live filterOptions.categories
                so dynamically-created categories appear here. Falls back to the
                FALLBACK_CATEGORIES constant if filterOptions hasn't loaded yet.
              */}
              <FormField control={partForm.control} name="category" render={({ field }) => (
                <FormItem>
                  <FormLabel>Category *</FormLabel>
                  <FormControl>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categoryOptions.map((cat: string) => (
                          <SelectItem key={cat} value={cat}>
                            {cat.charAt(0).toUpperCase() + cat.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={partForm.control} name="unitOfMeasure" render={({ field }) => (
                <FormItem>
                  <FormLabel>Unit of Measure</FormLabel>
                  <FormControl>
                    <Input placeholder="ea, gal, ft" {...field} data-testid="input-unit-measure" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={partForm.control} name="criticality" render={({ field }) => (
                <FormItem>
                  <FormLabel>Criticality</FormLabel>
                  <FormControl>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <SelectTrigger data-testid="select-criticality">
                        <SelectValue placeholder="Select criticality" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/*
                FIX: standardCost previously reset to 0 immediately when the field was cleared
                (onChange set field to 0 when val === ""). This made it impossible to leave the
                field blank while typing. Now stores an empty string during editing and converts
                to a number only when the value is non-empty. Validation happens on submit.
              */}
              <FormField control={partForm.control} name="standardCost" render={({ field }) => (
                <FormItem>
                  <FormLabel>Standard Cost *</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      value={field.value === 0 ? "" : field.value ?? ""}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "") {
                          // FIX: keep field truly empty while the user is editing
                          // instead of snapping back to 0 on every keystroke
                          field.onChange(undefined);
                        } else {
                          const numVal = Number.parseFloat(val);
                          field.onChange(Number.isNaN(numVal) ? undefined : numVal);
                        }
                      }}
                      onBlur={(e) => {
                        // Normalise to 0 on blur if still empty
                        if (e.target.value === "") { field.onChange(0); }
                        field.onBlur();
                      }}
                      name={field.name}
                      ref={field.ref}
                      data-testid="input-standard-cost"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={partForm.control} name="leadTimeDays" render={({ field }) => (
                <FormItem>
                  <FormLabel>Lead Time (Days) *</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      placeholder="7"
                      min="1"
                      value={field.value === 0 ? "" : field.value ?? ""}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "") {
                          field.onChange(undefined);
                        } else {
                          const numVal = Number.parseInt(val, 10);
                          // FIX: show validation error rather than silently clamping to 1
                          field.onChange(Number.isNaN(numVal) ? undefined : numVal);
                        }
                      }}
                      onBlur={(e) => {
                        const numVal = Number.parseInt(e.target.value, 10);
                        if (Number.isNaN(numVal) || numVal < 1) { field.onChange(1); }
                        field.onBlur();
                      }}
                      name={field.name}
                      ref={field.ref}
                      data-testid="input-lead-time"
                    />
                  </FormControl>
                  <p className="text-xs text-muted-foreground">Minimum 1 day</p>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <FormField control={partForm.control} name="quantityOnHand" render={({ field }) => (
                <FormItem>
                  <FormLabel>Initial Quantity</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min="0"
                      placeholder="0"
                      value={field.value === 0 ? "0" : field.value || ""}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "") { field.onChange(0); }
                        else {
                          const numVal = Number.parseInt(val, 10);
                          field.onChange(Number.isNaN(numVal) ? 0 : Math.max(0, numVal));
                        }
                      }}
                      onBlur={field.onBlur}
                      name={field.name}
                      ref={field.ref}
                      data-testid="input-quantity"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={partForm.control} name="minStockLevel" render={({ field }) => (
                <FormItem>
                  <FormLabel>Min Stock</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min="0"
                      placeholder="1"
                      value={field.value === 0 ? "0" : field.value || ""}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "") { field.onChange(0); }
                        else {
                          const numVal = Number.parseInt(val, 10);
                          field.onChange(Number.isNaN(numVal) ? 0 : Math.max(0, numVal));
                        }
                      }}
                      onBlur={field.onBlur}
                      name={field.name}
                      ref={field.ref}
                      data-testid="input-min-stock"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={partForm.control} name="maxStockLevel" render={({ field }) => (
                <FormItem>
                  <FormLabel>Max Stock</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min="1"
                      placeholder="100"
                      value={field.value === 0 ? "0" : field.value || ""}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "") { field.onChange(1); }
                        else {
                          const numVal = Number.parseInt(val, 10);
                          field.onChange(Number.isNaN(numVal) ? 1 : Math.max(1, numVal));
                        }
                      }}
                      onBlur={field.onBlur}
                      name={field.name}
                      ref={field.ref}
                      data-testid="input-max-stock"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={partForm.control} name="location" render={({ field }) => (
                <FormItem>
                  <FormLabel>Location</FormLabel>
                  <FormControl>
                    <Input placeholder="MAIN" {...field} data-testid="input-location" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <FormField control={partForm.control} name="supplierIds" render={({ field }) => (
              <FormItem>
                <FormLabel>Suppliers</FormLabel>
                <FormControl>
                  <SupplierMultiSelect
                    value={field.value || []}
                    preferredSupplierId={partForm.watch("preferredSupplierId")}
                    onChange={field.onChange}
                    onPreferredChange={(id) => partForm.setValue("preferredSupplierId", id)}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

          </form>
        </Form>
      </ResponsiveDialog>
    </div>
  );
}
