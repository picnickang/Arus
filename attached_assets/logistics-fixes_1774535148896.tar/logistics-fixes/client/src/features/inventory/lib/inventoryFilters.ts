/**
 * Inventory Filter Utilities
 *
 * Fixes applied:
 * 1. Supplier filter matched on supplierName (mutable string). Renaming a supplier
 *    silently emptied all existing filters referencing the old name.
 *    Now filters on supplierId. FilterOptions.suppliers now uses ID as value.
 *    Note: InventoryFilterPanel and its consumers must be updated to store/pass
 *    supplier IDs, not names.
 *
 * 2. parseFiltersFromUrl stockStatus was not validated — any string was accepted.
 *    Now validated against the known enum; unknown values fall back to "all".
 *
 * 3. filterParts spread the full array unconditionally even when no filters were
 *    active. Now returns the original array reference when nothing would change.
 */

import type { PartsInventoryItem } from "@/components/inventory/VirtualizedInventoryTable";
import type { InventoryFilters } from "@/components/inventory/InventoryFilterPanel";
import { getStockStatus } from "./stockUtils";

// ── Constants ─────────────────────────────────────────────────────────────────

export const VALID_STOCK_STATUSES = ["all", "critical", "low", "adequate", "excess", "zero"] as const;
export type ValidStockStatus = typeof VALID_STOCK_STATUSES[number];

// ── Defaults ──────────────────────────────────────────────────────────────────

export const DEFAULT_INVENTORY_FILTERS: InventoryFilters = {
  search:        "",
  categories:    [],
  criticalities: [],
  stockStatus:   "all",
  // FIX: suppliers now stores supplier IDs, not display names
  suppliers:     [],
};

export function createDefaultFilters(): InventoryFilters {
  return { ...DEFAULT_INVENTORY_FILTERS };
}

// ── URL serialisation ─────────────────────────────────────────────────────────

export function parseFiltersFromUrl(searchParams: string): InventoryFilters {
  const params = new URLSearchParams(searchParams);

  // FIX: validate stockStatus against known values — unknown strings now fall back to "all"
  const rawStatus  = params.get("stockStatus") ?? "all";
  const stockStatus = (VALID_STOCK_STATUSES as readonly string[]).includes(rawStatus)
    ? (rawStatus as ValidStockStatus)
    : "all";

  return {
    search:        params.get("search") || "",
    categories:    params.get("categories")?.split(",").filter(Boolean) ?? [],
    criticalities: params.get("criticalities")?.split(",").filter(Boolean) ?? [],
    stockStatus,
    // FIX: supplier values are now IDs
    suppliers:     params.get("suppliers")?.split(",").filter(Boolean) ?? [],
  };
}

export function serializeFiltersToUrl(filters: InventoryFilters): string {
  const params = new URLSearchParams();

  if (filters.search)               { params.set("search", filters.search); }
  if (filters.categories.length)    { params.set("categories", filters.categories.join(",")); }
  if (filters.criticalities.length) { params.set("criticalities", filters.criticalities.join(",")); }
  if (filters.stockStatus !== "all"){ params.set("stockStatus", filters.stockStatus); }
  if (filters.suppliers.length)     { params.set("suppliers", filters.suppliers.join(",")); }

  return params.toString();
}

// ── Filter counting ───────────────────────────────────────────────────────────

export function countActiveFilters(filters: InventoryFilters): number {
  let count = 0;
  if (filters.search)               { count++; }
  count += filters.categories.length;
  count += filters.criticalities.length;
  count += filters.suppliers.length;
  if (filters.stockStatus !== "all"){ count++; }
  return count;
}

// ── Core filter function ──────────────────────────────────────────────────────

export function filterParts(
  parts: PartsInventoryItem[],
  filters: InventoryFilters
): PartsInventoryItem[] {
  // FIX: avoid unconditional array spread when no filters are active.
  // Previously `let result = [...parts]` was always executed, allocating a new
  // array even when the result would be identical to the input.
  const hasAnyFilter =
    !!filters.search ||
    filters.categories.length > 0 ||
    filters.criticalities.length > 0 ||
    filters.suppliers.length > 0 ||
    filters.stockStatus !== "all";

  if (!hasAnyFilter) {
    return parts;
  }

  let result = parts;

  if (filters.search) {
    const searchLower = filters.search.toLowerCase();
    result = result.filter(
      (part) =>
        (part.partNumber   || "").toLowerCase().includes(searchLower) ||
        (part.partName     || "").toLowerCase().includes(searchLower) ||
        (part.category     || "").toLowerCase().includes(searchLower) ||
        (part.description  || "").toLowerCase().includes(searchLower)
    );
  }

  if (filters.categories.length > 0) {
    result = result.filter(
      (part) => part.category && filters.categories.includes(part.category)
    );
  }

  if (filters.criticalities.length > 0) {
    result = result.filter(
      (part) => part.criticality && filters.criticalities.includes(part.criticality)
    );
  }

  /**
   * FIX: previously filtered on part.supplierName (display string).
   * Now filters on part.supplierId (stable ID). The FilterPanel must store
   * supplier IDs in filters.suppliers — see deriveFilterOptions below.
   */
  if (filters.suppliers.length > 0) {
    result = result.filter(
      (part) => part.supplierId && filters.suppliers.includes(part.supplierId)
    );
  }

  if (filters.stockStatus !== "all") {
    result = result.filter((part) => {
      const status = getStockStatus(part);
      switch (filters.stockStatus) {
        case "critical": return status === "critical" || status === "out_of_stock";
        case "low":      return status === "low_stock";
        case "adequate": return status === "adequate";
        case "excess":   return status === "excess_stock";
        case "zero":     return status === "out_of_stock";
        default:         return true;
      }
    });
  }

  return result;
}

// ── Filter option derivation ──────────────────────────────────────────────────

export interface FilterOptions {
  categories:    { value: string; label: string }[];
  /** FIX: value is now supplierId (stable), label is the display name */
  suppliers:     { value: string; label: string; supplierId: string }[];
  criticalities: { value: string; label: string }[];
}

export function deriveFilterOptions(parts: PartsInventoryItem[]): FilterOptions {
  const categories = [
    ...new Set(parts.map((p) => p.category).filter(Boolean)),
  ].sort((a, b) => a.localeCompare(b));

  /**
   * FIX: previously derived supplier options from supplierName strings.
   * Now derives from {supplierId, supplierName} pairs so the filter value
   * is the stable ID. De-duplicates by supplierId.
   */
  const supplierMap = new Map<string, string>(); // id → name
  for (const p of parts) {
    if (p.supplierId && p.supplierName && !supplierMap.has(p.supplierId)) {
      supplierMap.set(p.supplierId, p.supplierName);
    }
  }
  const suppliers = [...supplierMap.entries()]
    .sort(([, nameA], [, nameB]) => nameA.localeCompare(nameB))
    .map(([id, name]) => ({ value: id, label: name, supplierId: id }));

  const criticalities = ["critical", "high", "medium", "low"];

  return {
    categories:    categories.map((c) => ({ value: c, label: c })),
    suppliers,
    criticalities: criticalities.map((c) => ({
      value: c,
      label: c.charAt(0).toUpperCase() + c.slice(1),
    })),
  };
}
