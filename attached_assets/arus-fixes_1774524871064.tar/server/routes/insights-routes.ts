/**
 * Insights Routes (Legacy)
 *
 * FIX C2: All queries now filter by orgId for tenant isolation.
 * Previously, queries joined actionableInsights without org filtering.
 * FIX H4: This file is the canonical insights route source. The duplicate
 * in server/domains/insights/routes.ts should delegate to this or be removed.
 */
import type { Express } from 'express';
import { z } from 'zod';
import { eq, and, sql } from 'drizzle-orm';
import { db } from '../db';
import { actionableInsights, equipment } from '@shared/schema-runtime';
import { InsightEngine } from '../core/insights/insightEngine';
import { logger } from '../utils/logger.js';

const acknowledgeInsightSchema = z.object({
  orgId: z.string().optional().default("default-org"),
  acknowledgedBy: z.string(),
});

const resolveInsightSchema = z.object({
  orgId: z.string().optional().default("default-org"),
  resolvedBy: z.string(),
  resolutionNotes: z.string().optional(),
  workOrderId: z.string().optional(),
});

/**
 * FIX C2: Helper to extract and require orgId from request
 */
function requireOrgIdFromRequest(req: any): string | null {
  const orgId = req.orgId || req.headers?.["x-org-id"];
  return orgId && typeof orgId === "string" && orgId.trim() !== "" ? orgId.trim() : null;
}

export function registerInsightsRoutes(app: Express) {
  app.get('/api/insights', async (req, res) => {
    try {
      // FIX C2: Require orgId for tenant isolation
      const orgId = requireOrgIdFromRequest(req);
      if (!orgId) {
        return res.status(401).json({ error: "Organization ID is required" });
      }

      const { vesselId, equipmentId, severity, resolved, acknowledged } = req.query;

      // FIX C2: Always filter by orgId
      const conditions: any[] = [eq(actionableInsights.orgId, orgId)];

      if (vesselId) {
        conditions.push(eq(actionableInsights.vesselId, vesselId as string));
      }

      if (equipmentId) {
        conditions.push(eq(actionableInsights.equipmentId, equipmentId as string));
      }

      if (severity) {
        conditions.push(eq(actionableInsights.severity, severity as string));
      }

      if (resolved !== undefined) {
        conditions.push(eq(actionableInsights.resolved, resolved === 'true'));
      }

      if (acknowledged !== undefined) {
        conditions.push(eq(actionableInsights.acknowledged, acknowledged === 'true'));
      }

      const results = await db
        .select({
          insight: actionableInsights,
          equipment: {
            id: equipment.id,
            name: equipment.name,
            type: equipment.type,
            vesselId: equipment.vesselId,
          },
        })
        .from(actionableInsights)
        .leftJoin(equipment, eq(actionableInsights.equipmentId, equipment.id))
        .where(and(...conditions))
        .orderBy(sql`${actionableInsights.createdAt} DESC`);

      const insights = results.map((r) => ({
        ...r.insight,
        equipment: r.equipment,
        supportingSignals: r.insight.supportingSignals
          ? JSON.parse(r.insight.supportingSignals)
          : null,
        relatedProcedures: r.insight.relatedProcedures
          ? JSON.parse(r.insight.relatedProcedures)
          : null,
      }));

      res.json(insights);
    } catch (error) {
      logger.error('Failed to fetch insights', { error });
      res.status(500).json({ error: 'Failed to fetch insights' });
    }
  });

  // Note: These specific routes MUST be registered BEFORE the /:id catch-all route
  app.get('/api/insights/snapshots', async (req, res) => {
    try {
      const { scope } = req.query;
      const { insightSnapshots } = await import('@shared/schema-runtime');
      let query = db.select().from(insightSnapshots).$dynamic();
      if (scope) {
        query = query.where(eq(insightSnapshots.scope, scope as string));
      }
      const snapshots = await query.orderBy(sql`${insightSnapshots.createdAt} DESC`).limit(100);
      res.json(snapshots);
    } catch (error) {
      logger.error('Failed to fetch insight snapshots', { error });
      res.status(500).json({ error: 'Failed to fetch insight snapshots' });
    }
  });

  app.get('/api/insights/snapshots/latest', async (req, res) => {
    try {
      const { scope = 'fleet' } = req.query;
      const { insightSnapshots } = await import('@shared/schema-runtime');
      const [snapshot] = await db.select().from(insightSnapshots)
        .where(eq(insightSnapshots.scope, scope as string))
        .orderBy(sql`${insightSnapshots.createdAt} DESC`)
        .limit(1);
      res.json(snapshot || null);
    } catch (error) {
      logger.error('Failed to fetch latest insight snapshot', { error });
      res.status(500).json({ error: 'Failed to fetch latest insight snapshot' });
    }
  });

  // FIX H4: stats/summary must be registered before /:id to avoid shadowing
  app.get('/api/insights/stats/summary', async (req, res) => {
    try {
      // FIX C2: Require orgId
      const orgId = requireOrgIdFromRequest(req);
      if (!orgId) {
        return res.status(401).json({ error: "Organization ID is required" });
      }

      const { vesselId } = req.query;

      // FIX C2: Filter by orgId
      const conditions: any[] = [eq(actionableInsights.orgId, orgId)];
      if (vesselId) {
        conditions.push(eq(actionableInsights.vesselId, vesselId as string));
      }

      const stats = await db
        .select({
          severity: actionableInsights.severity,
          resolved: actionableInsights.resolved,
          count: sql<number>`count(*)`.as('count'),
        })
        .from(actionableInsights)
        .where(and(...conditions))
        .groupBy(actionableInsights.severity, actionableInsights.resolved);

      const summary = {
        total: 0,
        critical: 0,
        high: 0,
        medium: 0,
        low: 0,
        resolved: 0,
        unresolved: 0,
      };

      stats.forEach((stat) => {
        const count = Number(stat.count);
        summary.total += count;

        if (stat.severity === 'critical') {
          summary.critical += count;
        }

        if (stat.severity === 'high') {
          summary.high += count;
        }

        if (stat.severity === 'medium') {
          summary.medium += count;
        }

        if (stat.severity === 'low') {
          summary.low += count;
        }

        if (stat.resolved) {
          summary.resolved += count;
        } else {
          summary.unresolved += count;
        }
      });

      res.json(summary);
    } catch (error) {
      logger.error('Failed to fetch insight stats', { error });
      res.status(500).json({ error: 'Failed to fetch insight stats' });
    }
  });

  app.get('/api/insights/:id', async (req, res) => {
    try {
      // FIX C2: Require orgId
      const orgId = requireOrgIdFromRequest(req);
      if (!orgId) {
        return res.status(401).json({ error: "Organization ID is required" });
      }

      const { id } = req.params;

      // FIX C2: Filter by orgId to prevent cross-tenant access
      const [result] = await db
        .select({
          insight: actionableInsights,
          equipment: {
            id: equipment.id,
            name: equipment.name,
            type: equipment.type,
            vesselId: equipment.vesselId,
          },
        })
        .from(actionableInsights)
        .leftJoin(equipment, eq(actionableInsights.equipmentId, equipment.id))
        .where(and(eq(actionableInsights.id, id), eq(actionableInsights.orgId, orgId)))
        .limit(1);

      if (!result) {
        return res.status(404).json({ error: 'Insight not found' });
      }

      const insight = {
        ...result.insight,
        equipment: result.equipment,
        supportingSignals: result.insight.supportingSignals
          ? JSON.parse(result.insight.supportingSignals)
          : null,
        relatedProcedures: result.insight.relatedProcedures
          ? JSON.parse(result.insight.relatedProcedures)
          : null,
      };

      res.json(insight);
    } catch (error) {
      logger.error('Failed to fetch insight', { error });
      res.status(500).json({ error: 'Failed to fetch insight' });
    }
  });

  app.post('/api/insights/evaluate/:equipmentId', async (req, res) => {
    try {
      const { equipmentId } = req.params;
      const { vesselId } = req.body;
      const orgId = req.body.orgId || (req.headers["x-org-id"] as string) || "default-org";

      const [equipmentRecord] = await db
        .select()
        .from(equipment)
        .where(eq(equipment.id, equipmentId))
        .limit(1);

      if (!equipmentRecord) {
        return res.status(404).json({ error: 'Equipment not found' });
      }

      const insightIds = await InsightEngine.evaluateAndStoreInsights(
        equipmentId,
        orgId,
        vesselId
      );

      res.json({
        success: true,
        equipmentId,
        insightsCreated: insightIds.length,
        insightIds,
      });
    } catch (error) {
      logger.error('Failed to evaluate equipment', { error });
      res.status(500).json({ error: 'Failed to evaluate equipment' });
    }
  });

  app.patch('/api/insights/:id/acknowledge', async (req, res) => {
    try {
      // FIX C2: Require orgId
      const orgId = requireOrgIdFromRequest(req);
      if (!orgId) {
        return res.status(401).json({ error: "Organization ID is required" });
      }

      const { id } = req.params;
      const body = acknowledgeInsightSchema.parse(req.body);

      // FIX C2: Scope update to org
      const [updated] = await db
        .update(actionableInsights)
        .set({
          acknowledged: true,
          acknowledgedAt: new Date(),
          acknowledgedBy: body.acknowledgedBy,
        })
        .where(and(eq(actionableInsights.id, id), eq(actionableInsights.orgId, orgId)))
        .returning();

      if (!updated) {
        return res.status(404).json({ error: 'Insight not found' });
      }

      res.json(updated);
    } catch (error) {
      logger.error('Failed to acknowledge insight', { error });
      res.status(500).json({ error: 'Failed to acknowledge insight' });
    }
  });

  app.patch('/api/insights/:id/resolve', async (req, res) => {
    try {
      // FIX C2: Require orgId
      const orgId = requireOrgIdFromRequest(req);
      if (!orgId) {
        return res.status(401).json({ error: "Organization ID is required" });
      }

      const { id } = req.params;
      const body = resolveInsightSchema.parse(req.body);

      // FIX C2: Scope update to org
      const [updated] = await db
        .update(actionableInsights)
        .set({
          resolved: true,
          resolvedAt: new Date(),
          resolvedBy: body.resolvedBy,
          resolutionNotes: body.resolutionNotes || null,
          workOrderId: body.workOrderId || null,
        })
        .where(and(eq(actionableInsights.id, id), eq(actionableInsights.orgId, orgId)))
        .returning();

      if (!updated) {
        return res.status(404).json({ error: 'Insight not found' });
      }

      res.json(updated);
    } catch (error) {
      logger.error('Failed to resolve insight', { error });
      res.status(500).json({ error: 'Failed to resolve insight' });
    }
  });

  logger.info('Actionable Insights API routes registered (C2: org-scoped)');
}
