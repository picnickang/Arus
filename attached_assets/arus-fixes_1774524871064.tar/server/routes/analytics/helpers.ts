/**
 * Analytics Routes - Shared Helpers
 *
 * FIX C2: getOrgId now throws 401 if orgId is missing instead of
 * silently falling back to "default-org". Every analytics endpoint
 * must receive an explicit org context.
 */
import type { Request, Response } from "express";
import { z } from "zod";
import { createHash } from "node:crypto";

const FAILURE_PREDICTION_NAMESPACE = "f8e7d6c5-b4a3-4a2b-8c1d-0e9f8a7b6c5d";

export function toFailurePredictionUuid(id: number): string {
  const hash = createHash("sha256").update(`${FAILURE_PREDICTION_NAMESPACE}:${id}`).digest("hex");
  return [hash.substring(0, 8), hash.substring(8, 12), `4${  hash.substring(13, 16)}`, ((Number.parseInt(hash.substring(16, 18), 16) & 0x3f) | 0x80).toString(16).padStart(2, "0") + hash.substring(18, 20), hash.substring(20, 32)].join("-");
}

/**
 * FIX C2: Extract and validate orgId from request.
 * Returns the orgId string, or sends a 401 response and returns null.
 * Callers must check for null and return early.
 */
export function getOrgId(req: Request, res: Response): string | null {
  // Try authenticated request first (from auth middleware)
  const authOrgId = (req as any).orgId;
  if (authOrgId && typeof authOrgId === "string" && authOrgId.trim() !== "") {
    return authOrgId.trim();
  }

  // Fallback to header
  const headerOrgId = req.headers["x-org-id"] as string;
  if (headerOrgId && typeof headerOrgId === "string" && headerOrgId.trim() !== "") {
    return headerOrgId.trim();
  }

  // FIX C2: No silent fallback — return 401
  res.status(401).json({
    error: {
      code: "ORG_ID_REQUIRED",
      message: "Organization ID is required. Provide x-org-id header or authenticate.",
    },
    metadata: { timestamp: new Date(), version: "1.0" },
  });
  return null;
}

export function sendValidatedResponse<T>(res: Response, data: unknown, schema: z.ZodSchema<T>): boolean {
  try {
    const validated = schema.parse(data);
    res.json(validated);
    return true;
  } catch (error) {
    console.error("[Analytics API] Response validation failed:", error);
    res.status(500).json({ error: { code: "RESPONSE_VALIDATION_ERROR", message: "Response failed DTO validation", details: process.env.NODE_ENV === "development" ? error : undefined }, metadata: { timestamp: new Date(), version: "1.0" } });
    return false;
  }
}

export function handleError(res: Response, error: unknown, operation: string) {
  console.error(`[Analytics API] ${operation} error:`, error);
  if (error instanceof Error && error.message.includes("not found")) {
    res.status(404).json({ error: { code: "NOT_FOUND", message: error.message }, metadata: { timestamp: new Date(), version: "1.0" } });
    return;
  }
  res.status(500).json({ error: { code: "INTERNAL_ERROR", message: error instanceof Error ? error.message : "An unexpected error occurred", details: process.env.NODE_ENV === "development" ? error : undefined }, metadata: { timestamp: new Date(), version: "1.0" } });
}
