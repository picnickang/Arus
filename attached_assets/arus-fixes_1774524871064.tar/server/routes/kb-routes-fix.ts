/**
 * Knowledge Base Routes - PARTIAL FIX FILE
 *
 * FIX M5: Fixed two catch blocks where the catch parameter was named
 * '_error' but the body referenced 'error', causing ReferenceError.
 *
 * IMPORTANT: This file only contains the two fixed route handlers.
 * In your kb-routes.ts, find and replace these two route handlers.
 * The rest of the file remains unchanged.
 */

// ============================================================
// FIX 1: Search documents endpoint — was: catch (_error)
// Find the router.get('/search', ...) handler and replace the
// catch block. The fix changes _error → error.
// ============================================================

/*
  FIND THIS in your kb-routes.ts:

    } catch (_error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid query parameters', details: error.errors });
      }
      console.error('[KB Search] Failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ error: 'Search failed', details: errorMessage });
    }

  REPLACE WITH:
*/

// Fixed search handler catch block:
// } catch (error) {    // ← FIX M5: was _error, body used error
//   if (error instanceof z.ZodError) {
//     return res.status(400).json({ error: 'Invalid query parameters', details: error.errors });
//   }
//   console.error('[KB Search] Failed:', error);
//   const errorMessage = error instanceof Error ? error.message : 'Unknown error';
//   res.status(500).json({ error: 'Search failed', details: errorMessage });
// }


// ============================================================
// FIX 2: Delete documents endpoint — was: catch (_error)
// Find the router.delete('/documents/:id', ...) handler and
// replace the catch block.
// ============================================================

/*
  FIND THIS in your kb-routes.ts:

    } catch (_error) {
      console.error('[KB Delete] Failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';

  REPLACE WITH:
*/

// Fixed delete handler catch block:
// } catch (error) {    // ← FIX M5: was _error, body used error
//   console.error('[KB Delete] Failed:', error);
//   const errorMessage = error instanceof Error ? error.message : 'Unknown error';


// ============================================================
// For convenience, here are the two complete fixed handlers
// that you can copy-paste to replace the originals:
// ============================================================

export const SEARCH_HANDLER_FIX = `
  // Search documents endpoint
  router.get(
    '/search',
    generalApiRateLimit,
    async (req, res) => {
      try {
        const validatedQuery = searchQuerySchema.parse(req.query);
        const orgId = req.orgId;

        console.log(\`[KB Search] Query: "\${validatedQuery.q}" for org \${orgId}\`);

        const results = await searchKnowledgeBase({
          orgId,
          query: validatedQuery.q,
          limit: validatedQuery.limit,
          threshold: validatedQuery.threshold,
          openAiKey: process.env.OPENAI_API_KEY,
        });

        res.json({
          query: validatedQuery.q,
          results,
          count: results.length,
        });
      } catch (error) {  // FIX M5: was _error
        if (error instanceof z.ZodError) {
          return res.status(400).json({ error: 'Invalid query parameters', details: error.errors });
        }
        console.error('[KB Search] Failed:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        res.status(500).json({ error: 'Search failed', details: errorMessage });
      }
    }
  );
`;

export const DELETE_HANDLER_FIX = `
  // Delete document endpoint
  router.delete(
    '/documents/:id',
    writeOperationRateLimit,
    async (req, res) => {
      try {
        const orgId = req.orgId;
        const { id } = req.params;

        await deleteDocument(id, orgId);

        res.status(204).send();
      } catch (error) {  // FIX M5: was _error
        console.error('[KB Delete] Failed:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';

        if (errorMessage.includes('not found') || errorMessage.includes('access denied')) {
          return res.status(404).json({ error: errorMessage });
        }

        res.status(500).json({ error: 'Failed to delete document', details: errorMessage });
      }
    }
  );
`;
