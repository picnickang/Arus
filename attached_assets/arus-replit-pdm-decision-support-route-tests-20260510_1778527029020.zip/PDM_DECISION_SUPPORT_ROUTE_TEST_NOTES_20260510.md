# ARUS PdM Decision Support — Route Integration Test Update

Generated: 2026-05-10

## Purpose

This update adds API route-level integration coverage for the hexagonal PdM decision-support module.

The previous unit test validates the domain/application service through fake ports. This package adds a route factory and integration tests so the Express API layer is also covered without requiring a live database or vessel telemetry hardware.

## Files included

```text
server/domains/pdm-platform/decision-support/interfaces/routes.ts
tests/integration/pdm-decision-support-routes.test.ts
jest.config.cjs
PDM_DECISION_SUPPORT_ROUTE_TEST_NOTES_20260510.md
```

## Route change

`routes.ts` still exports the production router:

```ts
export { pdmDecisionSupportRouter };
```

It now also exports a factory for tests:

```ts
export function createPdmDecisionSupportRouter(service?: PdmDecisionSupportRouteService): Router
```

Production behavior remains the same: the default router builds the real service with the Drizzle context adapter, operational context adapter, safety adapter, and synthetic telemetry adapter.

The test uses the factory to inject a fake service, which keeps the route test inside the hexagonal boundary and avoids database coupling.

## New integration tests

The test covers:

1. `POST /api/pdm/decision-support/evaluate` success path
2. Evaluate route injects organization context into the service call
3. Evaluate route rejects invalid payloads before calling the service
4. Evaluate route returns `404` when equipment is missing
5. `POST /api/pdm/decision-support/synthetic-telemetry` success path and schema defaults
6. Synthetic telemetry route rejects invalid ranges
7. `POST /api/pdm/decision-support/safety-check` blocks unsafe recommendations
8. Missing org context returns `401`

## How to run in Replit

```bash
npm install
node --experimental-vm-modules node_modules/jest/bin/jest.js tests/integration/pdm-decision-support-routes.test.ts --runInBand
```

Then run the wider project checks:

```bash
npm run typecheck
npm run lint
npm run test:unit
npm run test:integration
npm run test:pdm
npm run build
```

## Notes

This update intentionally does not hit the real database. It proves that the API layer validates requests, maps org context, handles endpoint errors, and returns the expected response shape. Database adapter coverage should remain in adapter-specific integration tests.
