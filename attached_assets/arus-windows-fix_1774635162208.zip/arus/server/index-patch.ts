/**
 * server/index.ts  — entry point patch
 *
 * Add this block at the very top of your existing server/index.ts,
 * BEFORE any Express app setup or startServer() calls.
 *
 * This lets the WiX installer run:
 *   arus-server.exe --init-db
 * as a post-install custom action to bootstrap the SQLite schema,
 * without starting the HTTP server.
 *
 * The rest of your existing server/index.ts is unchanged below this block.
 */

// ── --init-db CLI mode ────────────────────────────────────────────────────────
// Must be checked before any other imports that might try to connect to a DB.

if (process.argv.includes('--init-db')) {
  // Dynamic import keeps this out of the normal server bundle's critical path.
  import('./init-db-entry.js')
    .then(m => m.initDb())
    .then(() => {
      console.log('[ARUS] --init-db complete');
      process.exit(0);
    })
    .catch(err => {
      console.error('[ARUS] --init-db failed:', err);
      process.exit(1);
    });
} else {
  // ── Normal server startup ─────────────────────────────────────────────────
  // Your existing server startup code goes here (or is already below this
  // block in the real file).  In vessel/local mode, call initDb() here too
  // so the schema is always current on startup.

  import('./init-db-entry.js').then(async m => {
    const isVesselMode =
      process.env.DEPLOYMENT_MODE === 'VESSEL' ||
      process.env.LOCAL_MODE === 'true' ||
      process.env.EMBEDDED_MODE === 'true';

    if (isVesselMode) {
      try {
        await m.initDb();
      } catch (err) {
        // Non-fatal on server start — Drizzle will push the full schema anyway.
        console.warn('[ARUS] Pre-start DB init warning:', err);
      }
    }

    // Call your real startServer() here.
    // startServer();
  });
}
