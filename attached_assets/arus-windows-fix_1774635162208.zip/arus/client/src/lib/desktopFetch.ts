/**
 * client/src/lib/desktopFetch.ts
 *
 * Resolves and caches the backend URL for desktop (Tauri) builds.
 *
 * Resolution priority:
 *   1. In-memory cache (_cachedUrl)
 *   2. Tauri IPC: get_backend_config  (reads ARUS_BACKEND_URL env var)
 *   3. localStorage key 'arus_backend_url'  (set by first-run wizard)
 *   4. Hard default: http://localhost:5000
 */

import { isDesktop } from './desktop';

const STORAGE_KEY = 'arus_backend_url';
const DEFAULT_URL = 'http://localhost:5000';

let _cachedUrl: string | null = null;

// ── Dynamic Tauri import (Vite-safe) ─────────────────────────────────────────

function tauriImport(mod: string): Promise<any> {
  return new Function('m', 'return import(m)')(mod).catch(() => null);
}

// ── URL resolution ────────────────────────────────────────────────────────────

export async function resolveBackendUrl(): Promise<string> {
  if (_cachedUrl) return _cachedUrl;

  // 1. Tauri IPC
  if (isDesktop()) {
    try {
      const core = await tauriImport('@tauri-apps/api/core');
      if (core) {
        const config = await core.invoke<{ url: string; mode: string }>('get_backend_config');
        if (config?.url) {
          _cachedUrl = config.url;
          return _cachedUrl;
        }
      }
    } catch {
      // fall through
    }
  }

  // 2. localStorage
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      _cachedUrl = stored;
      return _cachedUrl;
    }
  } catch {
    // localStorage may be unavailable in some contexts
  }

  // 3. Default
  _cachedUrl = DEFAULT_URL;
  return _cachedUrl;
}

export function getBackendUrlSync(): string {
  if (_cachedUrl) return _cachedUrl;
  try {
    return localStorage.getItem(STORAGE_KEY) ?? DEFAULT_URL;
  } catch {
    return DEFAULT_URL;
  }
}

export function setBackendUrl(url: string): void {
  _cachedUrl = url;
  try {
    localStorage.setItem(STORAGE_KEY, url);
  } catch {
    // ignore
  }
}

export function clearBackendUrl(): void {
  _cachedUrl = null;
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}

// ── Health check ──────────────────────────────────────────────────────────────

export async function testBackendConnection(url: string, timeoutMs = 5000): Promise<boolean> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${url}/api/healthz`, {
      signal: controller.signal,
      cache: 'no-store',
    });
    return res.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

// ── Setup guard ───────────────────────────────────────────────────────────────

/**
 * Returns true when the app is ready to make API calls.
 * - Web mode:     always true
 * - Desktop mode: true only when a backend URL is configured and reachable
 */
export async function isDesktopSetupComplete(): Promise<boolean> {
  if (!isDesktop()) return true;
  const url = await resolveBackendUrl();
  return testBackendConnection(url);
}

// ── Patched fetch ─────────────────────────────────────────────────────────────

/**
 * Drop-in replacement for fetch() that prepends the resolved backend URL
 * for any request path starting with /api.
 *
 * Usage: replace window.fetch or use directly in API client functions.
 */
export async function desktopFetch(
  input: RequestInfo | URL,
  init?: RequestInit,
): Promise<Response> {
  if (typeof input === 'string' && input.startsWith('/api')) {
    const base = await resolveBackendUrl();
    return fetch(`${base}${input}`, init);
  }
  return fetch(input, init);
}
