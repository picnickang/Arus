/**
 * client/src/pages/desktop-setup.tsx
 *
 * First-run setup wizard shown when:
 *   - Running inside Tauri (isDesktop() === true)
 *   - AND the backend is not yet reachable (isDesktopSetupComplete() === false)
 *
 * Steps:
 *   1. Mode      — Vessel (SQLite offline) or Cloud (remote Postgres)
 *   2. Backend   — confirm / start the backend; test connection
 *   3. Vessel ID — vessel name/ID (vessel mode only, optional)
 *   4. Password  — set local admin password
 */

import { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'wouter';
import {
  isDesktopSetupComplete,
  setBackendUrl,
  testBackendConnection,
} from '@/lib/desktopFetch';
import { isDesktop } from '@/lib/desktop';

// ── Types ─────────────────────────────────────────────────────────────────────

type Mode = 'vessel' | 'cloud';
type Step = 'mode' | 'backend' | 'vessel-id' | 'password' | 'starting' | 'done';

interface WizardState {
  mode:            Mode;
  backendUrl:      string;
  vesselId:        string;
  adminPassword:   string;
  confirmPassword: string;
}

// ── Tauri event helper (Vite-safe dynamic import) ─────────────────────────────

async function tauriListen(
  event: string,
  handler: (payload: string) => void,
): Promise<() => void> {
  try {
    const { listen } = await new Function('m', 'return import(m)')('@tauri-apps/api/event');
    return listen<string>(event, e => handler(e.payload));
  } catch {
    return () => {};
  }
}

async function tauriInvoke(cmd: string): Promise<void> {
  const core = await new Function('m', 'return import(m)')('@tauri-apps/api/core').catch(() => null);
  if (!core) throw new Error('Tauri core not available');
  return core.invoke(cmd);
}

// ── Component ─────────────────────────────────────────────────────────────────

export default function DesktopSetup() {
  const [, navigate] = useLocation();
  const [step,       setStep]       = useState<Step>('mode');
  const [error,      setError]      = useState<string | null>(null);
  const [busy,       setBusy]       = useState(false);
  const [log,        setLog]        = useState<string[]>([]);
  const [state,      setState]      = useState<WizardState>({
    mode:            'vessel',
    backendUrl:      'http://localhost:5000',
    vesselId:        '',
    adminPassword:   '',
    confirmPassword: '',
  });

  // Skip wizard if already set up.
  useEffect(() => {
    if (!isDesktop()) { navigate('/'); return; }
    isDesktopSetupComplete().then(done => { if (done) navigate('/'); });
  }, []);

  // Subscribe to sidecar log events while on the 'starting' step.
  useEffect(() => {
    if (step !== 'starting') return;

    const unlisteners: Array<() => void> = [];

    (async () => {
      unlisteners.push(
        await tauriListen('backend-log', line =>
          setLog(prev => [...prev.slice(-99), line])
        ),
        await tauriListen('backend-error', line =>
          setLog(prev => [...prev.slice(-99), `[err] ${line}`])
        ),
        await tauriListen('backend-launch-failed', msg => {
          setError(`Backend failed to start: ${msg}`);
          setStep('backend');
        }),
        await tauriListen('backend-terminated', code => {
          setLog(prev => [...prev, `Process exited (${code})`]);
        }),
      );
    })();

    return () => unlisteners.forEach(u => u?.());
  }, [step]);

  // ── Helpers ────────────────────────────────────────────────────────────────

  function set<K extends keyof WizardState>(key: K, val: WizardState[K]) {
    setState(prev => ({ ...prev, [key]: val }));
  }

  function appendLog(line: string) {
    setLog(prev => [...prev.slice(-99), line]);
  }

  const testAndAdvance = useCallback(async () => {
    setError(null);
    setBusy(true);
    const ok = await testBackendConnection(state.backendUrl, 6000);
    setBusy(false);
    if (ok) {
      setBackendUrl(state.backendUrl);
      setStep(state.mode === 'vessel' ? 'vessel-id' : 'password');
    } else {
      setError(
        `Cannot reach ${state.backendUrl}. ` +
        (state.mode === 'vessel'
          ? 'Try clicking "Start Backend" first.'
          : 'Check the URL and try again.')
      );
    }
  }, [state.backendUrl, state.mode]);

  const startSidecarAndAdvance = useCallback(async () => {
    setError(null);
    setLog([]);
    setStep('starting');
    appendLog('Requesting backend start…');
    try {
      await tauriInvoke('start_backend_sidecar');
      setBackendUrl(state.backendUrl);
      setStep(state.mode === 'vessel' ? 'vessel-id' : 'password');
    } catch (e: any) {
      setError(`Could not start backend: ${e?.message ?? String(e)}`);
      setStep('backend');
    }
  }, [state.backendUrl, state.mode]);

  const finishSetup = useCallback(async () => {
    if (state.adminPassword !== state.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (state.adminPassword.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    setError(null);
    setBusy(true);
    try {
      const res = await fetch(`${state.backendUrl}/api/setup/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode:          state.mode,
          vesselId:      state.vesselId || undefined,
          adminPassword: state.adminPassword,
        }),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || `HTTP ${res.status}`);
      }
      setStep('done');
      setTimeout(() => navigate('/'), 1800);
    } catch (e: any) {
      setError(`Setup failed: ${e?.message ?? String(e)}`);
    } finally {
      setBusy(false);
    }
  }, [state, navigate]);

  // ── Render ─────────────────────────────────────────────────────────────────

  const stepList: Step[] = state.mode === 'vessel'
    ? ['mode', 'backend', 'vessel-id', 'password']
    : ['mode', 'backend', 'password'];

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 overflow-hidden">

        {/* ── Header ── */}
        <div className="px-8 pt-8 pb-4 text-center">
          <div className="text-2xl font-bold text-white tracking-tight">ARUS Marine</div>
          <p className="text-slate-500 text-sm mt-1">Initial Setup</p>
          <ProgressBar steps={stepList} current={step} />
        </div>

        {/* ── Error banner ── */}
        {error && (
          <div className="mx-8 mb-4 bg-red-950 border border-red-800 text-red-300
                          text-sm rounded-lg px-4 py-3 leading-relaxed">
            {error}
          </div>
        )}

        <div className="px-8 pb-8 space-y-5">

          {/* ── Step 1: Mode ── */}
          {step === 'mode' && (
            <>
              <StepHeading title="Deployment Mode"
                sub="How will ARUS be used on this machine?" />
              <div className="grid grid-cols-2 gap-3">
                {(['vessel', 'cloud'] as Mode[]).map(m => (
                  <button key={m} onClick={() => set('mode', m)}
                    className={`rounded-xl p-4 text-left border transition-all ${
                      state.mode === m
                        ? 'border-blue-500 bg-blue-950 text-white'
                        : 'border-slate-700 bg-slate-800 text-slate-300 hover:border-slate-500'
                    }`}>
                    <div className="font-semibold capitalize text-sm">{m}</div>
                    <div className="text-xs mt-1 opacity-60 leading-snug">
                      {m === 'vessel'
                        ? 'Offline-first. SQLite database on this vessel computer.'
                        : 'Online. Connects to a remote PostgreSQL server.'}
                    </div>
                  </button>
                ))}
              </div>
              <Btn onClick={() => {
                if (state.mode === 'vessel') set('backendUrl', 'http://localhost:5000');
                setStep('backend');
              }}>Continue</Btn>
            </>
          )}

          {/* ── Step 2: Backend ── */}
          {step === 'backend' && (
            <>
              <StepHeading
                title="Backend Connection"
                sub={state.mode === 'vessel'
                  ? 'The ARUS backend service runs on this machine. Start it if needed, then test the connection.'
                  : 'Enter the URL of your ARUS cloud server.'}
              />
              <Field label="Backend URL">
                <input
                  type="url"
                  value={state.backendUrl}
                  onChange={e => set('backendUrl', e.target.value)}
                  placeholder="http://localhost:5000"
                  readOnly={state.mode === 'vessel'}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg
                             px-3 py-2 text-sm focus:outline-none focus:border-blue-500
                             disabled:opacity-50 read-only:opacity-60"
                />
              </Field>
              <div className={`grid gap-3 ${state.mode === 'vessel' ? 'grid-cols-2' : 'grid-cols-1'}`}>
                {state.mode === 'vessel' && (
                  <Btn variant="secondary" onClick={startSidecarAndAdvance} disabled={busy}>
                    Start Backend
                  </Btn>
                )}
                <Btn onClick={testAndAdvance} disabled={busy}>
                  {busy ? 'Testing…' : 'Test & Continue'}
                </Btn>
              </div>
              <BackBtn onClick={() => setStep('mode')} />
            </>
          )}

          {/* ── Step: Starting (boot log) ── */}
          {step === 'starting' && (
            <>
              <StepHeading title="Starting Backend…"
                sub="Please wait while the ARUS service starts." />
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 h-48
                              overflow-y-auto font-mono text-xs text-emerald-400 space-y-px">
                {log.length === 0
                  ? <span className="text-slate-600">Waiting for output…</span>
                  : log.map((line, i) => (
                      <div key={i} className={line.startsWith('[err]') ? 'text-red-400' : ''}>
                        {line}
                      </div>
                    ))
                }
              </div>
              <p className="text-slate-500 text-xs text-center">
                First launch may take 10–20 seconds while the database initialises.
              </p>
            </>
          )}

          {/* ── Step 3: Vessel ID ── */}
          {step === 'vessel-id' && (
            <>
              <StepHeading title="Vessel Identification"
                sub="Set the identifier for this vessel. Used in fleet reports and sync." />
              <Field label="Vessel ID" hint="Optional — can be set later in Settings.">
                <input
                  type="text"
                  value={state.vesselId}
                  onChange={e => set('vesselId', e.target.value)}
                  placeholder="e.g. MV-AURORA-01"
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg
                             px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
                />
              </Field>
              <Btn onClick={() => setStep('password')}>Continue</Btn>
              <BackBtn onClick={() => setStep('backend')} />
            </>
          )}

          {/* ── Step 4: Admin Password ── */}
          {step === 'password' && (
            <>
              <StepHeading title="Admin Password"
                sub="Set a local administrator password for this installation." />
              <Field label="Password">
                <input type="password" value={state.adminPassword}
                  onChange={e => set('adminPassword', e.target.value)}
                  autoComplete="new-password"
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg
                             px-3 py-2 text-sm focus:outline-none focus:border-blue-500" />
              </Field>
              <Field label="Confirm Password">
                <input type="password" value={state.confirmPassword}
                  onChange={e => set('confirmPassword', e.target.value)}
                  autoComplete="new-password"
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg
                             px-3 py-2 text-sm focus:outline-none focus:border-blue-500" />
              </Field>
              <Btn onClick={finishSetup} disabled={busy}>
                {busy ? 'Setting up…' : 'Finish Setup'}
              </Btn>
              <BackBtn onClick={() => setStep(state.mode === 'vessel' ? 'vessel-id' : 'backend')} />
            </>
          )}

          {/* ── Done ── */}
          {step === 'done' && (
            <div className="text-center py-6 space-y-3">
              <div className="text-5xl">✅</div>
              <div className="text-white font-semibold text-lg">Setup Complete</div>
              <div className="text-slate-400 text-sm">Loading ARUS…</div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────────────────────────

function ProgressBar({ steps, current }: { steps: Step[]; current: Step }) {
  const idx = steps.indexOf(current);
  if (idx < 0) return null;
  return (
    <div className="flex justify-center gap-1.5 mt-4">
      {steps.map((s, i) => (
        <div key={s} className={`h-1 w-8 rounded-full transition-all duration-300 ${
          i <= idx ? 'bg-blue-500' : 'bg-slate-700'
        }`} />
      ))}
    </div>
  );
}

function StepHeading({ title, sub }: { title: string; sub: string }) {
  return (
    <div>
      <h2 className="text-white font-semibold text-base">{title}</h2>
      <p className="text-slate-400 text-sm mt-0.5 leading-snug">{sub}</p>
    </div>
  );
}

function Field({ label, hint, children }: {
  label: string; hint?: string; children: React.ReactNode;
}) {
  return (
    <div className="space-y-1">
      <label className="block text-slate-300 text-sm font-medium">{label}</label>
      {children}
      {hint && <p className="text-slate-500 text-xs">{hint}</p>}
    </div>
  );
}

function Btn({ children, onClick, disabled, variant = 'primary' }: {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  variant?: 'primary' | 'secondary';
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-full font-medium rounded-xl py-2.5 text-sm transition-colors
        disabled:opacity-50 disabled:cursor-not-allowed ${
        variant === 'primary'
          ? 'bg-blue-600 hover:bg-blue-500 text-white'
          : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
      }`}
    >
      {children}
    </button>
  );
}

function BackBtn({ onClick }: { onClick: () => void }) {
  return (
    <button onClick={onClick}
      className="w-full text-slate-500 hover:text-slate-300 text-sm py-1 transition-colors">
      ← Back
    </button>
  );
}
