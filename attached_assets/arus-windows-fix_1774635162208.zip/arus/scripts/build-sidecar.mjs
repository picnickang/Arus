#!/usr/bin/env node
/**
 * build-sidecar.mjs
 *
 * Compiles the Express backend to a standalone binary for use as a
 * Tauri sidecar.  Two-stage process:
 *
 *   Stage 1 — esbuild bundles server/index.ts → dist/server-bundle.cjs
 *             Native addons (.node files) are marked external so esbuild
 *             doesn't try to inline them.
 *
 *   Stage 2 — @yao-pkg/pkg compiles the bundle + a pkg-assets.json
 *             snapshot manifest that tells pkg to include all native
 *             .node binaries at their expected require() paths.
 *
 * Output:
 *   src-tauri/binaries/arus-server-{triple}[.exe]   (used by Tauri)
 *   src-tauri/binaries/arus-server[.exe]             (dev copy, no triple suffix)
 *
 * Usage:
 *   node scripts/build-sidecar.mjs              # current platform only
 *   node scripts/build-sidecar.mjs --all        # all four platform targets
 *
 * Requirements (devDependencies):
 *   @yao-pkg/pkg   esbuild   glob
 */

import { execSync }                            from 'node:child_process';
import { mkdirSync, copyFileSync,
         writeFileSync, existsSync,
         readdirSync }                         from 'node:fs';
import { join, dirname, relative, extname }    from 'node:path';
import { fileURLToPath }                       from 'node:url';
import { platform, arch }                      from 'node:process';

const __dirname  = dirname(fileURLToPath(import.meta.url));
const root       = join(__dirname, '..');
const binDir     = join(root, 'src-tauri', 'binaries');
const bundleOut  = join(root, 'dist', 'server-bundle.cjs');
const assetsJson = join(root, 'dist', 'pkg-assets.json');

// ── Platform → pkg target mapping ────────────────────────────────────────────

const TARGETS = {
  'x86_64-pc-windows-msvc':   { pkg: 'node20-win-x64',    ext: '.exe' },
  'aarch64-apple-darwin':     { pkg: 'node20-macos-arm64', ext: ''     },
  'x86_64-apple-darwin':      { pkg: 'node20-macos-x64',  ext: ''     },
  'x86_64-unknown-linux-gnu': { pkg: 'node20-linux-x64',  ext: ''     },
};

function currentTriple() {
  if (platform === 'win32')   return 'x86_64-pc-windows-msvc';
  if (platform === 'darwin')  return arch === 'arm64'
    ? 'aarch64-apple-darwin'
    : 'x86_64-apple-darwin';
  return 'x86_64-unknown-linux-gnu';
}

// ── Native addon discovery ────────────────────────────────────────────────────
//
// We walk node_modules looking for pre-built .node files so pkg can snapshot
// them into the binary.  pkg resolves native require() calls at runtime from
// a virtual filesystem embedded in the exe.

function findNativeAddons(searchRoot) {
  const results = [];

  function walk(dir) {
    let entries;
    try { entries = readdirSync(dir, { withFileTypes: true }); }
    catch { return; }

    for (const entry of entries) {
      const full = join(dir, entry.name);
      if (entry.isDirectory()) {
        // Skip deeply nested test/example dirs to keep the asset list small.
        if (['test', 'tests', 'example', 'examples', '.bin'].includes(entry.name)) continue;
        walk(full);
      } else if (entry.isFile() && extname(entry.name) === '.node') {
        results.push(full);
      }
    }
  }

  walk(searchRoot);
  return results;
}

function buildAssetsManifest() {
  const nmDir    = join(root, 'node_modules');
  const addons   = findNativeAddons(nmDir);
  const assets   = {};

  for (const addonPath of addons) {
    // pkg asset path must be relative to the bundle file.
    const rel = relative(dirname(bundleOut), addonPath).replace(/\\/g, '/');
    assets[rel] = { isAsset: true };
  }

  // Also include any .db files that ship with libsql (WASM fallback etc.)
  const extraGlobs = [
    join(nmDir, '@libsql', '**', '*.wasm'),
    join(nmDir, '@libsql', '**', '*.js'),
  ];
  // (We skip the glob walk for brevity; add here if needed.)

  writeFileSync(assetsJson, JSON.stringify({ assets }, null, 2));
  console.log(`  📎 Asset manifest: ${addons.length} native addon(s) indexed`);
  return addons.length;
}

// ── Stage 1: esbuild bundle ───────────────────────────────────────────────────

function bundleServer() {
  console.log('\n📦 Stage 1 — Bundling with esbuild…');
  mkdirSync(dirname(bundleOut), { recursive: true });

  // These packages contain native .node binaries.  esbuild must not try to
  // inline them — pkg will snapshot them separately via the assets manifest.
  const externals = [
    '@libsql/client',
    '@libsql/darwin-arm64',
    '@libsql/darwin-x64',
    '@libsql/linux-x64-gnu',
    '@libsql/win32-x64-msvc',
    'better-sqlite3',
    'bcrypt',
    'sharp',
    'cpu-features',
    'ssh2',
  ].map(p => `--external:${p}`).join(' ');

  execSync(
    `npx esbuild server/index.ts ` +
    `--platform=node --target=node20 --bundle --format=cjs ` +
    `--outfile=${bundleOut} --allow-overwrite ` +
    externals,
    { stdio: 'inherit', cwd: root }
  );

  console.log(`  ✅ Bundle: ${bundleOut}`);
}

// ── Stage 2: pkg compile ──────────────────────────────────────────────────────

function compileTarget(triple) {
  const t = TARGETS[triple];
  if (!t) { console.error(`Unknown triple: ${triple}`); process.exit(1); }

  const outFile = join(binDir, `arus-server-${triple}${t.ext}`);
  console.log(`\n🔨 Stage 2 — Compiling ${triple}…`);
  mkdirSync(binDir, { recursive: true });

  execSync(
    `npx pkg ${bundleOut} ` +
    `--target ${t.pkg} ` +
    `--config ${assetsJson} ` +
    `--output ${outFile} ` +
    `--compress GZip`,
    { stdio: 'inherit', cwd: root }
  );

  console.log(`  ✅ ${outFile}`);
  return outFile;
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  const buildAll = process.argv.includes('--all');

  bundleServer();
  buildAssetsManifest();
  mkdirSync(binDir, { recursive: true });

  if (buildAll) {
    for (const triple of Object.keys(TARGETS)) {
      compileTarget(triple);
    }
  } else {
    const triple  = currentTriple();
    const outFile = compileTarget(triple);

    // Write an un-suffixed dev copy so `tauri dev` can find it without the
    // target triple (Tauri strips the triple in dev mode).
    const devCopy = join(binDir, `arus-server${TARGETS[triple].ext}`);
    copyFileSync(outFile, devCopy);
    console.log(`  ✅ Dev copy → ${devCopy}`);
  }

  console.log('\n✅ Sidecar build complete.\n');
}

main().catch(e => { console.error(e); process.exit(1); });
