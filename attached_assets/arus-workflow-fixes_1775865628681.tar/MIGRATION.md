# Workflow Fixes — Migration Guide

5 fixes from the UX/Workflow audit, built as a hexagonal domain module + frontend components.

## Files

### Server — Hexagonal Work Orders Domain
```
server/domains/work-orders/
  domain/
    types.ts          — PredictionFeedback, QuickWorkOrder, CompletionValidation types
    ports.ts          — IWorkOrderRepository, ICostSavingsPort, IPredictionFeedbackPort
  application/
    wo-workflow-service.ts  — Orchestrates completion+feedback, cancellation+void, quick create
  infrastructure/
    adapters.ts       — Drizzle/PostgreSQL implementations of all ports
  interfaces/
    routes.ts         — API endpoints: /quick, /complete-with-feedback, /cancel, /is-predictive
  index.ts            — Module entry: wires adapters → service → routes
```

### Client — UI Components
```
client/src/
  components/work-orders/
    PredictionFeedbackForm.tsx    — "Was the failure confirmed?" radio group (Audit #3)
    QuickWorkOrderSheet.tsx       — 4-field mobile WO creation bottom sheet (Audit #5)
  components/shared/
    PendingApprovalsBanner.tsx    — Top banner for AI draft approvals (Audit #2)
  lib/
    briefing-redirect.ts         — Role-based landing page redirect logic (Audit #1)
```

## Integration Steps

### 1. Register the Work Orders domain

In your server bootstrap (`server/bootstrap/services.ts` or equivalent):

```typescript
import { registerWorkOrderDomain } from "./domains/work-orders";

// After existing route registrations:
registerWorkOrderDomain(app, { writeOperationRateLimit, generalApiRateLimit });
```

### 2. Add PendingApprovalsBanner to the layout

In `dashboard-improved.tsx` or the layout wrapper, add above the main content:

```tsx
import { PendingApprovalsBanner } from "@/components/shared/PendingApprovalsBanner";

// Inside the page, before the main content:
<PendingApprovalsBanner />
```

Also add to the briefing page:
```tsx
<PendingApprovalsBanner />
```

### 3. Add PredictionFeedbackForm to the WO completion dialog

In the existing work order completion flow (WorkOrderFormDialog or
WorkOrderDetailDrawer completion button handler):

```tsx
import { PredictionFeedbackForm } from "@/components/work-orders/PredictionFeedbackForm";

// Inside the completion dialog, before the submit button:
<PredictionFeedbackForm
  workOrderId={workOrder.id}
  predictionId={workOrder.predictionId}
  onChange={(feedback) => setPredictionFeedback(feedback)}
/>
```

Then update the completion submit to call the new endpoint:

```typescript
// Instead of:
await apiRequest("POST", `/api/work-orders/${id}/complete`);

// Use:
await apiRequest("POST", `/api/work-orders/${id}/complete-with-feedback`, {
  completionNotes,
  actualHours,
  predictionFeedback,
});
```

### 4. Add QuickWorkOrderSheet to mobile navigation

In the BottomNav or home page, add a quick-create trigger:

```tsx
import { QuickWorkOrderSheet } from "@/components/work-orders/QuickWorkOrderSheet";

const [quickWoOpen, setQuickWoOpen] = useState(false);

// In the bottom nav or a floating action button:
<button onClick={() => setQuickWoOpen(true)}>+ Quick WO</button>
<QuickWorkOrderSheet
  open={quickWoOpen}
  onClose={() => setQuickWoOpen(false)}
  vesselId={currentVesselId}
/>
```

### 5. Add briefing redirect to home page

In `home.tsx`, add the redirect check after role is confirmed:

```tsx
import { getBriefingRedirect } from "@/lib/briefing-redirect";

// At the top of the HomePage component, after role is loaded:
const redirect = getBriefingRedirect();
if (redirect) {
  return <Redirect to={redirect} />;
}
```

Add a "Customize →" link to disable the redirect for power users:
```tsx
import { disableLandingRedirect } from "@/lib/briefing-redirect";

// In settings or the home page:
<button onClick={() => { disableLandingRedirect(); window.location.href = "/"; }}>
  Show navigation grid on startup
</button>
```

## What Each Fix Does

### Fix #1 — Briefing as Landing Page
**Before:** Engineer opens ARUS → navigation grid → 4-5 taps to find what happened overnight.
**After:** Engineer opens ARUS → briefing page with AI summary, overnight alerts, pending approvals. Zero taps.

### Fix #2 — Pending Approvals Banner
**Before:** AI draft WO sitting in the Copilot chat → 20px badge on a floating button → engineer doesn't see it.
**After:** "AI Copilot: 2 items awaiting approval — [Review]" banner at the top of every page until acknowledged.

### Fix #3 — Prediction Feedback on WO Completion
**Before:** WO completes → savings record auto-created as "valid" → false alarms counted as real savings → trust erodes.
**After:** WO completes → "Was the failure confirmed?" → false alarm → savings auto-disputed → PdM team notified.

### Fix #4 — Auto-Void on Cancellation
**Before:** WO cancelled → savings record may remain as "valid" → financial reports inflated.
**After:** WO cancelled → savings auto-voided with reason "Work order cancelled" → reports accurate.

### Fix #5 — Quick WO for Mobile
**Before:** 15+ field form → API calls timeout on poor connectivity → engineer gives up and uses SHIPMATE.
**After:** Bottom sheet → equipment + description + priority + optional photo → 30 seconds → syncs when connected.

## Hexagonal Architecture Notes

The work-orders domain follows the same pattern as `domains/certificates/` and `domains/agent/`:

- **domain/** — pure types and port interfaces. No imports from infrastructure.
- **application/** — orchestration service. Depends only on ports.
- **infrastructure/** — Drizzle/PostgreSQL adapters implementing ports.
- **interfaces/** — Express routes. Depends on application service.
- **index.ts** — wires everything together. The only file that knows about all layers.

The application service (`WorkOrderWorkflowService`) can be unit tested by mocking the three ports. No database required in tests.
