/**
 * Work Orders Domain — Module Entry Point
 *
 * Wires the hexagonal architecture:
 *   domain/ports → infrastructure/adapters → application/service → interfaces/routes
 *
 * Usage in server bootstrap:
 *   import { registerWorkOrderDomain } from "./domains/work-orders";
 *   registerWorkOrderDomain(app, rateLimiters);
 */

import type { Express } from "express";
import { WorkOrderRepositoryAdapter, CostSavingsAdapter, PredictionFeedbackAdapter } from "./infrastructure/adapters";
import { WorkOrderWorkflowService } from "./application/wo-workflow-service";
import { registerWorkOrderWorkflowRoutes } from "./interfaces/routes";

// Re-export types for consumers
export * from "./domain/types";
export * from "./domain/ports";
export { WorkOrderWorkflowService } from "./application/wo-workflow-service";

export function registerWorkOrderDomain(
  app: Express,
  rateLimiters: { writeOperationRateLimit: any; generalApiRateLimit: any },
) {
  // 1. Create infrastructure adapters
  const woRepo = new WorkOrderRepositoryAdapter();
  const savings = new CostSavingsAdapter();
  const predictionFeedback = new PredictionFeedbackAdapter();

  // 2. Create application service with injected ports
  const service = new WorkOrderWorkflowService(woRepo, savings, predictionFeedback);

  // 3. Register routes with injected service
  registerWorkOrderWorkflowRoutes(app, service, rateLimiters);

  console.log("[WorkOrders] Domain registered: quick-create, complete-with-feedback, cancel-with-void");

  return service;
}
