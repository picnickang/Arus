/**
 * Work Orders Domain — Ports
 *
 * Hexagonal interfaces for infrastructure adapters.
 * The application layer depends on these ports, not on concrete implementations.
 */

import type {
  QuickWorkOrderInput,
  QuickWorkOrderResult,
  CompletionPredictionFeedback,
  WorkOrderCompletionInput,
  WorkOrderCompletionResult,
} from "./types";

// ─── Work Order Repository Port ─────────────────────────────────────────────

export interface IWorkOrderRepository {
  /** Create a quick work order with minimal fields */
  createQuick(orgId: string, input: QuickWorkOrderInput): Promise<QuickWorkOrderResult>;

  /** Get work order by ID with prediction and cost context */
  findById(id: string, orgId: string): Promise<WorkOrderWithContext | null>;

  /** Update status with transition validation */
  updateStatus(
    id: string,
    orgId: string,
    newStatus: string,
    updatedBy?: string,
  ): Promise<boolean>;

  /** Get the next WO number */
  nextWorkOrderNumber(orgId: string): Promise<string>;

  /** Check if a WO is prediction-triggered */
  isPredictive(id: string, orgId: string): Promise<boolean>;
}

export interface WorkOrderWithContext {
  id: string;
  workOrderNumber: string;
  equipmentId: string;
  vesselId: string | null;
  status: string;
  maintenanceType: string | null;
  predictionId?: string | number | null;
  costJustification: string | null;
  estimatedRepairCost: number | null;
  estimatedFailureCost: number | null;
  totalCost: number | null;
  totalLaborCost: number | null;
  totalPartsCost: number | null;
}

// ─── Cost Savings Port ──────────────────────────────────────────────────────

export interface ICostSavingsPort {
  /** Calculate and persist savings on WO completion */
  processCompletion(workOrderId: string, orgId: string): Promise<{
    saved: boolean;
    savingsId?: string;
  }>;

  /** Void savings when WO is cancelled */
  voidForWorkOrder(workOrderId: string, orgId: string, reason: string, changedBy?: string): Promise<number>;

  /** Update validation status based on prediction feedback */
  updateValidation(
    workOrderId: string,
    orgId: string,
    status: "valid" | "disputed" | "voided",
    reason: string,
    changedBy: string,
  ): Promise<boolean>;
}

// ─── Prediction Feedback Port ───────────────────────────────────────────────

export interface IPredictionFeedbackPort {
  /** Record prediction outcome when WO completes */
  recordFeedback(feedback: CompletionPredictionFeedback, orgId: string, userId: string): Promise<void>;
}
