/**
 * Work Orders Domain — Extended Types
 *
 * Adds three workflow concepts identified in the UX audit:
 *   1. PredictionFeedback — "Was the predicted failure confirmed?" on WO completion
 *   2. QuickWorkOrder — 4-field mobile WO creation with offline queue
 *   3. CompletionValidation — Links WO completion outcome to savings integrity
 */

// ─── Prediction Feedback (Audit Item #3) ────────────────────────────────────

export type PredictionOutcome = "confirmed" | "partial" | "false_alarm";

export interface CompletionPredictionFeedback {
  workOrderId: string;
  predictionId?: string | number | null;
  /** Did the engineer find the predicted condition? */
  outcome: PredictionOutcome;
  /** Free-text notes from the engineer */
  notes?: string;
}

/**
 * Maps prediction outcome to cost_savings validationStatus.
 * - confirmed → "valid" (the prediction was correct, savings are real)
 * - partial → "valid" (condition existed, intervention justified)
 * - false_alarm → "disputed" (prediction wrong, savings claim questionable)
 */
export function mapOutcomeToValidation(outcome: PredictionOutcome): "valid" | "disputed" {
  if (outcome === "false_alarm") return "disputed";
  return "valid";
}

// ─── Quick Work Order (Audit Item #5) ───────────────────────────────────────

export interface QuickWorkOrderInput {
  equipmentId: string;
  description: string;
  priority: "low" | "medium" | "high";
  photoBase64?: string;
  /** Set by the client from cached vessel context */
  vesselId?: string;
}

export interface QuickWorkOrderResult {
  id: string;
  workOrderNumber: string;
  status: "open";
  createdVia: "quick_mobile";
  queuedOffline: boolean;
}

// ─── Completion with Validation (combines existing completion + feedback) ───

export interface WorkOrderCompletionInput {
  workOrderId: string;
  orgId: string;
  completionNotes?: string;
  actualHours?: number;
  /** Only required when maintenanceType is "predictive" */
  predictionFeedback?: CompletionPredictionFeedback;
}

export interface WorkOrderCompletionResult {
  workOrderId: string;
  completed: boolean;
  savingsCalculated: boolean;
  savingsValidationStatus?: string;
  predictionFeedbackRecorded: boolean;
}
