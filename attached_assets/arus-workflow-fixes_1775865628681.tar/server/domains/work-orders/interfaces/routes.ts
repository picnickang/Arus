/**
 * Work Orders Domain — Interface Routes
 *
 * Hexagonal: routes depend on application service, not on infrastructure.
 * The service is injected at registration time.
 *
 * New endpoints:
 *   POST /api/work-orders/quick      — 4-field mobile WO creation (Audit #5)
 *   POST /api/work-orders/:id/complete-with-feedback — WO completion + prediction feedback (Audit #3)
 *   POST /api/work-orders/:id/cancel  — Cancellation with auto-void savings (Audit #4)
 *   GET  /api/work-orders/:id/is-predictive — Check if WO is prediction-triggered
 */

import type { Express, Request, Response } from "express";
import { requireOrgId, requireOrgIdAndValidateBody } from "../../../middleware/auth";
import { withErrorHandling, sendCreated, sendNotFound } from "../../../lib/route-utils";
import type { WorkOrderWorkflowService } from "../application/wo-workflow-service";

function getOrgId(req: any): string {
  return req.orgId || req.headers["x-org-id"] || "";
}

function getUserId(req: any): string {
  return req.userId || req.user?.id || req.headers["x-user-id"] || "unknown";
}

export function registerWorkOrderWorkflowRoutes(
  app: Express,
  service: WorkOrderWorkflowService,
  rateLimiters: { writeOperationRateLimit: any; generalApiRateLimit: any },
) {
  const { writeOperationRateLimit, generalApiRateLimit } = rateLimiters;

  // ── POST /api/work-orders/quick ─────────────────────────────────────────
  // Audit Item #5: Quick WO for mobile. 4 fields only.
  app.post(
    "/api/work-orders/quick",
    requireOrgIdAndValidateBody,
    writeOperationRateLimit,
    withErrorHandling("quick work order creation", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const { equipmentId, description, priority, photoBase64, vesselId } = req.body;

      if (!equipmentId || !description || !priority) {
        return res.status(400).json({
          error: "equipmentId, description, and priority are required",
        });
      }

      if (!["low", "medium", "high"].includes(priority)) {
        return res.status(400).json({
          error: "priority must be low, medium, or high",
        });
      }

      const result = await service.createQuick(orgId, {
        equipmentId,
        description,
        priority,
        photoBase64,
        vesselId,
      });

      sendCreated(res, result);
    }),
  );

  // ── POST /api/work-orders/:id/complete-with-feedback ────────────────────
  // Audit Item #3: WO completion with prediction feedback.
  // When maintenanceType is predictive, the predictionFeedback field is expected.
  app.post(
    "/api/work-orders/:id/complete-with-feedback",
    requireOrgIdAndValidateBody,
    writeOperationRateLimit,
    withErrorHandling("complete work order with feedback", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const userId = getUserId(req);
      const workOrderId = req.params.id;

      const {
        completionNotes,
        actualHours,
        predictionFeedback,
      } = req.body;

      // Validate prediction feedback if provided
      if (predictionFeedback) {
        const validOutcomes = ["confirmed", "partial", "false_alarm"];
        if (!validOutcomes.includes(predictionFeedback.outcome)) {
          return res.status(400).json({
            error: `predictionFeedback.outcome must be one of: ${validOutcomes.join(", ")}`,
          });
        }
      }

      const result = await service.completeWithFeedback(
        {
          workOrderId,
          orgId,
          completionNotes,
          actualHours,
          predictionFeedback: predictionFeedback
            ? {
                workOrderId,
                predictionId: predictionFeedback.predictionId,
                outcome: predictionFeedback.outcome,
                notes: predictionFeedback.notes,
              }
            : undefined,
        },
        userId,
      );

      if (!result.completed) {
        return sendNotFound(res, "Work Order");
      }

      res.json(result);
    }),
  );

  // ── POST /api/work-orders/:id/cancel ────────────────────────────────────
  // Audit Item #4: Cancellation with auto-void savings.
  app.post(
    "/api/work-orders/:id/cancel",
    requireOrgIdAndValidateBody,
    writeOperationRateLimit,
    withErrorHandling("cancel work order", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const userId = getUserId(req);
      const workOrderId = req.params.id;
      const { reason } = req.body;

      if (!reason || reason.trim().length === 0) {
        return res.status(400).json({ error: "Cancellation reason is required" });
      }

      const result = await service.cancelWithVoid(workOrderId, orgId, reason, userId);

      if (!result.cancelled) {
        return sendNotFound(res, "Work Order");
      }

      res.json(result);
    }),
  );

  // ── GET /api/work-orders/:id/is-predictive ──────────────────────────────
  // Used by the frontend to decide whether to show the prediction feedback form.
  app.get(
    "/api/work-orders/:id/is-predictive",
    requireOrgId,
    generalApiRateLimit,
    withErrorHandling("check if work order is predictive", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const workOrderId = req.params.id;

      const isPredictive = await service.woRepo.isPredictive(workOrderId, orgId);
      res.json({ workOrderId, isPredictive });
    }),
  );
}
