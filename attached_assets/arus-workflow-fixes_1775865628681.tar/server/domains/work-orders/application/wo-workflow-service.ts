/**
 * Work Orders Domain — Application Service
 *
 * Orchestrates the three audit items:
 *   #3: Prediction feedback on WO completion → savings validation
 *   #4: Auto-void savings on WO cancellation
 *   #5: Quick WO creation for mobile
 *
 * Depends only on ports — no direct DB or infrastructure imports.
 */

import type {
  IWorkOrderRepository,
  ICostSavingsPort,
  IPredictionFeedbackPort,
} from "../domain/ports";
import type {
  WorkOrderCompletionInput,
  WorkOrderCompletionResult,
  QuickWorkOrderInput,
  QuickWorkOrderResult,
} from "../domain/types";
import { mapOutcomeToValidation } from "../domain/types";

export class WorkOrderWorkflowService {
  constructor(
    private woRepo: IWorkOrderRepository,
    private savings: ICostSavingsPort,
    private predictionFeedback: IPredictionFeedbackPort,
  ) {}

  // ─── Audit Item #3: Complete WO with Prediction Feedback ────────────────

  /**
   * Completes a work order and processes the full chain:
   *   1. Update WO status to "completed"
   *   2. If predictive WO: record prediction feedback
   *   3. Calculate and persist savings
   *   4. If false alarm: auto-dispute the savings record
   *
   * This replaces the existing completion flow by adding the feedback step.
   */
  async completeWithFeedback(
    input: WorkOrderCompletionInput,
    userId: string,
  ): Promise<WorkOrderCompletionResult> {
    const { workOrderId, orgId, predictionFeedback: feedback } = input;

    // 1. Mark WO as completed
    const updated = await this.woRepo.updateStatus(workOrderId, orgId, "completed", userId);
    if (!updated) {
      return {
        workOrderId,
        completed: false,
        savingsCalculated: false,
        predictionFeedbackRecorded: false,
      };
    }

    // 2. Record prediction feedback if provided
    let feedbackRecorded = false;
    if (feedback) {
      try {
        await this.predictionFeedback.recordFeedback(feedback, orgId, userId);
        feedbackRecorded = true;
      } catch (err) {
        // Non-critical — log but don't block completion
        console.error(
          `[WOWorkflow] Failed to record prediction feedback for WO ${workOrderId}:`,
          err instanceof Error ? err.message : "unknown",
        );
      }
    }

    // 3. Calculate and persist savings
    let savingsCalculated = false;
    let savingsValidationStatus: string | undefined;
    try {
      const result = await this.savings.processCompletion(workOrderId, orgId);
      savingsCalculated = result.saved;

      // 4. If false alarm → dispute the savings
      if (result.saved && feedback?.outcome === "false_alarm") {
        await this.savings.updateValidation(
          workOrderId,
          orgId,
          "disputed",
          "Predicted condition not confirmed during work — flagged as false alarm by completing engineer.",
          userId,
        );
        savingsValidationStatus = "disputed";
      } else if (result.saved) {
        savingsValidationStatus = mapOutcomeToValidation(feedback?.outcome ?? "confirmed");
      }
    } catch (err) {
      console.error(
        `[WOWorkflow] Savings calculation failed for WO ${workOrderId}:`,
        err instanceof Error ? err.message : "unknown",
      );
    }

    return {
      workOrderId,
      completed: true,
      savingsCalculated,
      savingsValidationStatus,
      predictionFeedbackRecorded: feedbackRecorded,
    };
  }

  // ─── Audit Item #4: Cancel WO with Auto-Void ───────────────────────────

  /**
   * Cancels a work order and voids any associated savings.
   * This ensures cancelled WOs never retain valid savings claims.
   */
  async cancelWithVoid(
    workOrderId: string,
    orgId: string,
    reason: string,
    userId: string,
  ): Promise<{ cancelled: boolean; savingsVoided: number }> {
    const updated = await this.woRepo.updateStatus(workOrderId, orgId, "cancelled", userId);
    if (!updated) {
      return { cancelled: false, savingsVoided: 0 };
    }

    const voided = await this.savings.voidForWorkOrder(
      workOrderId,
      orgId,
      `Work order cancelled: ${reason}`,
      userId,
    );

    if (voided > 0) {
      console.log(
        `[WOWorkflow] Voided ${voided} savings record(s) for cancelled WO ${workOrderId}`,
      );
    }

    return { cancelled: true, savingsVoided: voided };
  }

  // ─── Audit Item #5: Quick Work Order for Mobile ─────────────────────────

  /**
   * Creates a minimal work order from the mobile quick-create flow.
   * Only 4 fields required: equipment, description, priority, optional photo.
   * Returns immediately — the WO is created in "open" status.
   */
  async createQuick(
    orgId: string,
    input: QuickWorkOrderInput,
  ): Promise<QuickWorkOrderResult> {
    return this.woRepo.createQuick(orgId, input);
  }
}
