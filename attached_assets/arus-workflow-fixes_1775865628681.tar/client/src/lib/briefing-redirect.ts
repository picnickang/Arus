/**
 * Briefing Landing — Role-Based Redirect Hook
 *
 * AUDIT ITEM #1: Make the briefing page the default landing for vessel roles.
 *
 * After the user selects their role on first visit, subsequent visits should
 * land on the briefing page (for vessel roles) or the dashboard (for shore roles),
 * not the navigation grid.
 *
 * Vessel roles (chief_engineer, deck_officer) → /briefing
 * Shore roles (fleet_manager) → /dashboard
 * System admin → /system
 * Unknown/default → home page (navigation grid)
 *
 * Usage: Call in home.tsx after role is confirmed.
 *   const redirect = useBriefingRedirect();
 *   if (redirect) return <Redirect to={redirect} />;
 */

const VESSEL_ROLES = ["chief_engineer", "deck_officer"];
const SHORE_ROLES = ["fleet_manager"];
const ADMIN_ROLES = ["system_admin"];

const ROLE_LANDING: Record<string, string> = {
  chief_engineer: "/briefing",
  deck_officer: "/briefing",
  fleet_manager: "/dashboard",
  system_admin: "/system",
};

const STORAGE_KEY = "arus-user-role";
const REDIRECT_DISABLED_KEY = "arus-landing-redirect-disabled";

/**
 * Returns the landing page URL for the current user's role,
 * or null if no redirect should happen (first visit, or user disabled it).
 */
export function getBriefingRedirect(): string | null {
  // User can opt out of auto-redirect
  if (typeof window !== "undefined" && localStorage.getItem(REDIRECT_DISABLED_KEY) === "true") {
    return null;
  }

  const role = typeof window !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null;
  if (!role || role === "default") return null;

  return ROLE_LANDING[role] || null;
}

/**
 * Returns true if the current role is a vessel role that should see the briefing.
 */
export function isVesselRole(): boolean {
  const role = typeof window !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null;
  return VESSEL_ROLES.includes(role || "");
}

/**
 * Disables the auto-redirect for users who prefer the navigation grid.
 */
export function disableLandingRedirect(): void {
  localStorage.setItem(REDIRECT_DISABLED_KEY, "true");
}

/**
 * Re-enables the auto-redirect.
 */
export function enableLandingRedirect(): void {
  localStorage.removeItem(REDIRECT_DISABLED_KEY);
}
