#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"
PATCH_DIR="workflow-persistence-update"
if [ ! -d "$PATCH_DIR" ]; then
  echo "Could not find $PATCH_DIR. Extract the update archive at your Replit project root first." >&2
  exit 1
fi
files=(
  "server/domains/workflow/application/attention-service.ts"
  "server/domains/workflow/interfaces/routes.ts"
  "server/routes/domain-router-registry.ts"
  "client/src/features/workflow/types.ts"
  "client/src/features/workflow/useOperationalWorkflow.ts"
  "client/src/features/workflow/pages/AttentionInboxPage.tsx"
  "client/src/features/workflow/components/AttentionItemCard.tsx"
  "client/src/features/workflow/components/ResolveBlockerPanel.tsx"
  "client/src/features/workflow/components/HandoverNotesPanel.tsx"
  "client/src/features/workflow/components/ReportIssueFlowCard.tsx"
  "scripts/check-workflow-routes.mjs"
  "WORKFLOW_PERSISTENCE_UPDATE_SUMMARY_20260426.md"
)
for f in "${files[@]}"; do
  mkdir -p "$(dirname "$f")"
  cp "$PATCH_DIR/$f" "$f"
done
mkdir -p data/workflow
echo "Workflow persistence update applied."
echo "Next: node scripts/check-workflow-routes.mjs && npm run typecheck && npm run build"
