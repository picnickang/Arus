# ARUS Workflow Persistence Update — 2026-04-26

This update is applied on top of the post workflow-action source. It focuses on making the Attention Inbox workflows more persistent, auditable, and operationally precise without introducing a risky database migration.

## What changed

### Backend workflow domain

Added persistent workflow-state endpoints under the existing workflow domain:

- `GET /api/attention/items`
  - Still returns aggregated attention items.
  - Now includes `sources` health metadata so the UI can warn when work orders, alerts, equipment, or inventory are partially unavailable.
  - Blocked count now excludes waiting-on-parts items.
  - Waiting-on-parts count includes both parts-blocked work orders and low-stock inventory items.
  - Attention items can include `lastResolution` metadata.

- `GET /api/attention/handover/latest`
  - Returns the latest saved handover record.

- `GET /api/attention/handovers`
  - Returns recent saved handover records.

- `POST /api/attention/handover`
  - Saves a backend handover draft with note, watch label, generated summary, item IDs, author, and timestamp.

- `POST /api/attention/blocker-resolutions`
  - Saves blocker resolution state for work orders or inventory items.
  - Captures blocker type, reason, owner, ETA, status, note, author, and timestamp.

- `POST /api/attention/issues`
  - Saves a guided issue-report draft and returns a suggested downstream workflow URL.

Persistent workflow state is stored in:

```txt
data/workflow/attention-workflow-state.json
```

This avoids changing the work-order database schema while still making blocker/handover/issue actions stateful. A future migration can promote blocker reason, ETA, and resolution status into first-class work-order columns.

## Frontend workflow improvements

### Attention Inbox

- Shows source-health warnings when the aggregated inbox is partial.
- Shows separate handover metrics for:
  - blocked jobs
  - waiting on parts
  - ready for closeout
  - open work orders
  - low-stock parts
- Does not show work-order lifecycle strip for inventory-only blockers.

### ResolveBlockerPanel

- Now works differently for inventory blockers vs work-order blockers.
- Inventory blockers show inventory/PR-specific actions.
- Work-order blockers keep work-order, inventory, and service-request actions.
- Saves workflow state through `POST /api/attention/blocker-resolutions`.
- Captures owner, ETA, status, and resolution note.

### HandoverNotesPanel

- Loads the latest saved backend handover.
- Saves new handover records through `POST /api/attention/handover`.
- Keeps local storage as a fallback if the backend save fails.
- Adds a watch/shift label.

### ReportIssueFlowCard

- Replaced the static card with a guided issue form.
- Captures severity, route target, owner, due date, vessel, equipment, location, impact, and evidence note.
- Saves issue drafts through `POST /api/attention/issues`.
- Opens the suggested downstream workflow after save.

## Files changed

- `server/domains/workflow/application/attention-service.ts`
- `server/domains/workflow/interfaces/routes.ts`
- `server/routes/domain-router-registry.ts`
- `client/src/features/workflow/types.ts`
- `client/src/features/workflow/useOperationalWorkflow.ts`
- `client/src/features/workflow/pages/AttentionInboxPage.tsx`
- `client/src/features/workflow/components/AttentionItemCard.tsx`
- `client/src/features/workflow/components/ResolveBlockerPanel.tsx`
- `client/src/features/workflow/components/HandoverNotesPanel.tsx`
- `client/src/features/workflow/components/ReportIssueFlowCard.tsx`
- `scripts/check-workflow-routes.mjs`

## Verification commands

Run these in Replit after upload:

```bash
npm install
node scripts/check-workflow-routes.mjs
node scripts/check-route-registration.mjs
npm run check:guards
npm run typecheck
npm run build
```

## Notes

The update intentionally does not add a database migration because the current canonical work-order schema does not contain a `blockedReason` column. The workflow state store gives the user persistent operational state now, while preserving the current schema and hexagonal domain boundaries.
