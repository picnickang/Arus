# ARUS — Remaining Phase 1 + Phase 2 Items

Closes all outstanding evaluation items except Phase 3 (operational/field work).

## What's Included

| Phase | # | Item | Files | Status |
|-------|---|------|-------|--------|
| P1 | 3 | Logbook correction workflow | `006-*.sql`, `logbook/routes.ts` | **Done** |
| P2 | 2 | Deployment playbook | `docs/DEPLOYMENT-PLAYBOOK.md` | **Done** |
| P2 | 3 | Connectivity indicator | Already wired — `ConnectivityBanner` in `App.tsx` | **Verified** |
| P2 | 4 | Desktop crash recovery | Included in deployment playbook | **Done** |
| P2 | 5 | Sensor calibration registry | `006-*.sql`, `sensors/routes.ts` | **Done** |

## Integration Steps

### 1. Run migration

```bash
psql $DATABASE_URL -f server/migrations/006-logbook-corrections-sensor-calibration.sql
```

Creates: `logbook_audit_log`, `sensor_calibrations`, `sensor_calibration_events` tables.
Adds: `correction_of`, `correction_reason`, `is_corrected` columns to `log_entries`.
Adds: Immutability triggers on `logbook_audit_log` and delete-prevention on `log_entries`.

### 2. Register routes

```typescript
import { logbookCorrectionRouter } from "./domains/logbook/routes.js";
import { sensorCalibrationRouter } from "./domains/sensors/routes.js";

app.use("/api/logbook", logbookCorrectionRouter);
app.use("/api/sensors/calibration", sensorCalibrationRouter);
```

### 3. Distribute deployment playbook

Copy `docs/DEPLOYMENT-PLAYBOOK.md` to your project's `docs/` directory.
This is the step-by-step guide for deploying ARUS on a vessel alongside SHIPMATE.

## API Endpoints

### Logbook Corrections
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/logbook/corrections` | Create a correction (new entry referencing original) |
| GET | `/api/logbook/:entryId/corrections` | List corrections for an entry |
| GET | `/api/logbook/:entryId/audit` | Full audit trail |
| GET | `/api/logbook/psc-view` | PSC inspection view (all entries + corrections) |
| POST | `/api/logbook/:entryId/countersign` | Countersign an entry |

### Sensor Calibration
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/sensors/calibration/summary` | Fleet calibration overview + data quality score |
| GET | `/api/sensors/calibration/overdue` | List overdue calibrations |
| GET | `/api/sensors/calibration` | List all sensors (filter by vessel, type, status) |
| GET | `/api/sensors/calibration/:id` | Sensor detail + calibration history |
| POST | `/api/sensors/calibration` | Register a new sensor |
| POST | `/api/sensors/calibration/:id/calibrate` | Record a calibration event |
| DELETE | `/api/sensors/calibration/:id` | Decommission a sensor (soft delete) |
