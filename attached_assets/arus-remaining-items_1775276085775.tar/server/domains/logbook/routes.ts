/**
 * Logbook Correction Routes
 *
 * Implements the maritime logbook correction workflow:
 *   - Original entries are NEVER modified or deleted
 *   - Corrections are new entries referencing the original
 *   - Every operation is logged to an immutable audit trail
 *   - PSC officers can view the complete correction history
 *
 * This meets flag state requirements for official log entries under
 * ISM Code Section 11 (Documentation) and SOLAS Chapter V.
 *
 * Register: app.use("/api/logbook", logbookCorrectionRouter);
 */

import { Router, Request, Response } from "express";
import { z } from "zod";
import { db } from "../../db.js";
import { eq, and, desc, sql } from "drizzle-orm";
import { requireOrgId, type AuthenticatedRequest } from "../../middleware/auth.js";
import { createRateLimiter } from "../../lib/rate-limit-factory.js";
import { createLogger } from "../../lib/structured-logger.js";

const logger = createLogger("logbook-corrections");
const router = Router();
const generalLimit = createRateLimiter("general");
const writeLimit = createRateLimiter("write");

function getOrgId(req: Request): string {
  return (req as AuthenticatedRequest).orgId as string;
}

function getUser(req: Request): { id: string; name?: string; rank?: string } {
  const user = (req as any).user || {};
  return {
    id: user.id || "unknown",
    name: user.name || user.displayName || "Unknown",
    rank: user.rank || user.role || "Unknown",
  };
}

// ── Validation schemas ──────────────────────────────────────────────────────

const correctionSchema = z.object({
  originalEntryId: z.string().min(1),
  correctedFields: z.record(z.unknown()),
  reason: z.string().min(10, "Correction reason must be at least 10 characters"),
});

// ── POST /api/logbook/corrections — Create a correction ─────────────────────

router.post("/corrections", requireOrgId, writeLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const user = getUser(req);
    const data = correctionSchema.parse(req.body);

    // Step 1: Verify original entry exists and belongs to this org
    const [original] = await db.execute(
      sql`SELECT * FROM log_entries WHERE id = ${data.originalEntryId} AND org_id = ${orgId}`
    ) as any[];

    // Handle both row array and result.rows patterns
    const originalEntry = Array.isArray(original)
      ? original[0]
      : (original as any)?.rows?.[0];

    if (!originalEntry) {
      return res.status(404).json({ error: "Original log entry not found" });
    }

    // Step 2: Merge corrected fields with original entry data
    const correctedData = {
      ...originalEntry,
      ...data.correctedFields,
      // Override system fields
      id: undefined, // Let DB generate new ID
      correction_of: data.originalEntryId,
      correction_reason: data.reason,
      is_corrected: false, // The correction itself is not corrected
      corrected_by_id: user.id,
      created_at: new Date(),
      updated_at: new Date(),
    };

    // Remove fields that shouldn't be copied
    delete correctedData.id;

    // Step 3: Insert the correction as a new entry
    const insertResult = await db.execute(sql`
      INSERT INTO log_entries (
        org_id, vessel_id, log_type, entry_date, watch_period,
        data, correction_of, correction_reason, corrected_by_id,
        author_id, author_name, author_rank,
        created_at, updated_at
      ) VALUES (
        ${orgId},
        ${originalEntry.vessel_id},
        ${originalEntry.log_type},
        ${originalEntry.entry_date},
        ${originalEntry.watch_period || null},
        ${JSON.stringify(data.correctedFields)},
        ${data.originalEntryId},
        ${data.reason},
        ${user.id},
        ${user.id},
        ${user.name},
        ${user.rank},
        NOW(), NOW()
      )
      RETURNING *
    `);

    const correctionEntry = Array.isArray(insertResult)
      ? insertResult[0]
      : (insertResult as any)?.rows?.[0];

    // Step 4: Mark original entry as corrected
    await db.execute(sql`
      UPDATE log_entries
      SET is_corrected = true, updated_at = NOW()
      WHERE id = ${data.originalEntryId} AND org_id = ${orgId}
    `);

    // Step 5: Write to immutable audit log
    await db.execute(sql`
      INSERT INTO logbook_audit_log (
        org_id, vessel_id, log_entry_id, action,
        performed_by, performed_by_name, performed_by_rank,
        details, ip_address, user_agent
      ) VALUES (
        ${orgId},
        ${originalEntry.vessel_id},
        ${data.originalEntryId},
        'corrected',
        ${user.id},
        ${user.name},
        ${user.rank},
        ${JSON.stringify({
          originalEntryId: data.originalEntryId,
          correctionEntryId: correctionEntry?.id,
          reason: data.reason,
          correctedFields: Object.keys(data.correctedFields),
        })},
        ${req.ip || null},
        ${req.headers["user-agent"] || null}
      )
    `);

    logger.info("Logbook correction created", {
      orgId,
      originalId: data.originalEntryId,
      correctionId: correctionEntry?.id,
      reason: data.reason.substring(0, 100),
      user: user.name,
    });

    res.status(201).json({
      correction: correctionEntry,
      originalMarked: true,
      auditLogged: true,
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: err.flatten() });
    }
    logger.error("Error creating correction", { error: err });
    res.status(500).json({ error: "Failed to create correction" });
  }
});

// ── GET /api/logbook/:entryId/corrections — List corrections for an entry ───

router.get("/:entryId/corrections", requireOrgId, generalLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const { entryId } = req.params;

    const result = await db.execute(sql`
      SELECT * FROM log_entries
      WHERE correction_of = ${entryId} AND org_id = ${orgId}
      ORDER BY created_at DESC
    `);

    const corrections = Array.isArray(result) ? result : (result as any)?.rows || [];

    res.json(corrections);
  } catch (err) {
    logger.error("Error listing corrections", { error: err });
    res.status(500).json({ error: "Failed to list corrections" });
  }
});

// ── GET /api/logbook/:entryId/audit — Full audit trail for an entry ─────────

router.get("/:entryId/audit", requireOrgId, generalLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const { entryId } = req.params;

    const result = await db.execute(sql`
      SELECT * FROM logbook_audit_log
      WHERE log_entry_id = ${entryId} AND org_id = ${orgId}
      ORDER BY created_at ASC
    `);

    const trail = Array.isArray(result) ? result : (result as any)?.rows || [];

    res.json(trail);
  } catch (err) {
    logger.error("Error fetching audit trail", { error: err });
    res.status(500).json({ error: "Failed to fetch audit trail" });
  }
});

// ── GET /api/logbook/psc-view — PSC inspection view (all entries + corrections) ──

router.get("/psc-view", requireOrgId, generalLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const { vesselId, logType, from, to } = req.query;

    if (!vesselId) {
      return res.status(400).json({ error: "vesselId is required" });
    }

    // Build date filter
    const fromDate = from ? new Date(from as string) : new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
    const toDate = to ? new Date(to as string) : new Date();

    // Get all entries including corrections, with correction chain visible
    const result = await db.execute(sql`
      SELECT
        le.*,
        CASE WHEN le.correction_of IS NOT NULL THEN 'correction' ELSE 'original' END as entry_role,
        corrected.id as corrected_by_entry_id,
        corrected.created_at as corrected_at,
        corrected.corrected_by_id as corrected_by_user
      FROM log_entries le
      LEFT JOIN log_entries corrected ON corrected.correction_of = le.id
      WHERE le.org_id = ${orgId}
        AND le.vessel_id = ${vesselId as string}
        AND le.entry_date >= ${fromDate}
        AND le.entry_date <= ${toDate}
        ${logType ? sql`AND le.log_type = ${logType as string}` : sql``}
      ORDER BY le.entry_date DESC, le.created_at DESC
    `);

    const entries = Array.isArray(result) ? result : (result as any)?.rows || [];

    // Get audit summary
    const auditResult = await db.execute(sql`
      SELECT action, COUNT(*) as count
      FROM logbook_audit_log
      WHERE org_id = ${orgId}
        AND vessel_id = ${vesselId as string}
        AND created_at >= ${fromDate}
        AND created_at <= ${toDate}
      GROUP BY action
    `);

    const auditSummary = Array.isArray(auditResult) ? auditResult : (auditResult as any)?.rows || [];

    res.json({
      vessel_id: vesselId,
      period: { from: fromDate, to: toDate },
      totalEntries: entries.length,
      correctedEntries: entries.filter((e: any) => e.is_corrected).length,
      corrections: entries.filter((e: any) => e.correction_of).length,
      auditSummary,
      entries,
    });
  } catch (err) {
    logger.error("Error generating PSC view", { error: err });
    res.status(500).json({ error: "Failed to generate PSC view" });
  }
});

// ── POST /api/logbook/:entryId/countersign — Countersign an entry ───────────

router.post("/:entryId/countersign", requireOrgId, writeLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const user = getUser(req);
    const { entryId } = req.params;

    // Write to audit log
    await db.execute(sql`
      INSERT INTO logbook_audit_log (
        org_id, vessel_id, log_entry_id, action,
        performed_by, performed_by_name, performed_by_rank,
        details
      )
      SELECT
        ${orgId},
        vessel_id,
        ${entryId},
        'countersigned',
        ${user.id},
        ${user.name},
        ${user.rank},
        ${JSON.stringify({ countersignedBy: user.name, rank: user.rank })}
      FROM log_entries
      WHERE id = ${entryId} AND org_id = ${orgId}
    `);

    res.json({ success: true, countersignedBy: user.name });
  } catch (err) {
    logger.error("Error countersigning entry", { error: err });
    res.status(500).json({ error: "Failed to countersign" });
  }
});

export { router as logbookCorrectionRouter };
export default router;
