/**
 * Migration 006: Logbook Corrections + Sensor Calibration Registry
 *
 * Phase 1 #3: Logbook correction workflow (visible audit trail)
 * Phase 2 #5: Sensor calibration tracking registry
 *
 * LOGBOOK CORRECTIONS
 * -------------------
 * Maritime logbooks (deck, engine, radio) are legal documents.
 * Flag state regulations require:
 *   - Original entries NEVER deleted
 *   - Corrections recorded as new entries that reference the original
 *   - Reason for correction documented
 *   - Both original and correction visible to PSC officers
 *   - Correction author and timestamp immutable
 *
 * This migration adds a correction workflow to the existing log_entries table:
 *   - correction_of: FK to original entry being corrected
 *   - correction_reason: required text when correcting
 *   - is_corrected: flag on original entry (set when a correction exists)
 *   - Immutable audit log for all logbook operations
 *
 * SENSOR CALIBRATION
 * ------------------
 * Maritime sensors (vibration, temperature, pressure, flow) drift over time.
 * Calibration tracking is needed for PdM credibility — predictions from
 * an uncalibrated sensor are meaningless.
 */

-- ============================================================================
-- PART 1: Logbook Correction Audit Trail
-- ============================================================================

-- Add correction fields to existing log_entries table
ALTER TABLE log_entries
  ADD COLUMN IF NOT EXISTS correction_of      VARCHAR REFERENCES log_entries(id),
  ADD COLUMN IF NOT EXISTS correction_reason   TEXT,
  ADD COLUMN IF NOT EXISTS is_corrected        BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS corrected_by_id     VARCHAR;
  -- Original entry is never modified; is_corrected is set when a correction row exists

-- Index for finding corrections of a given entry
CREATE INDEX IF NOT EXISTS idx_log_entries_correction_of
  ON log_entries (correction_of)
  WHERE correction_of IS NOT NULL;

-- Index for finding corrected entries (for PSC display)
CREATE INDEX IF NOT EXISTS idx_log_entries_corrected
  ON log_entries (org_id, is_corrected)
  WHERE is_corrected = true;

-- Immutable logbook audit log (append-only — no UPDATE or DELETE allowed)
CREATE TABLE IF NOT EXISTS logbook_audit_log (
  id              VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id          VARCHAR NOT NULL,
  vessel_id       VARCHAR NOT NULL,
  log_entry_id    VARCHAR NOT NULL,
  action          TEXT NOT NULL,
  -- Actions: 'created', 'corrected', 'countersigned', 'viewed_by_psc'
  performed_by    VARCHAR NOT NULL,
  performed_by_name TEXT,
  performed_by_rank TEXT,
  details         JSONB,
  -- For corrections: { originalEntryId, reason, correctedFields }
  -- For countersign: { countersignedBy, rank }
  ip_address      TEXT,
  user_agent      TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- NO update or delete triggers — this table is append-only
CREATE INDEX IF NOT EXISTS idx_logbook_audit_entry
  ON logbook_audit_log (log_entry_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_logbook_audit_vessel
  ON logbook_audit_log (org_id, vessel_id, created_at DESC);

-- Prevent updates and deletes on the audit log
CREATE OR REPLACE FUNCTION prevent_audit_modification()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Logbook audit log is immutable. Updates and deletes are not permitted.';
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_prevent_audit_update ON logbook_audit_log;
CREATE TRIGGER trg_prevent_audit_update
  BEFORE UPDATE OR DELETE ON logbook_audit_log
  FOR EACH ROW
  EXECUTE FUNCTION prevent_audit_modification();

-- Prevent deletion of log entries (only correction allowed)
CREATE OR REPLACE FUNCTION prevent_log_entry_delete()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Log entries cannot be deleted. Use the correction workflow instead.';
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_prevent_log_delete ON log_entries;
CREATE TRIGGER trg_prevent_log_delete
  BEFORE DELETE ON log_entries
  FOR EACH ROW
  EXECUTE FUNCTION prevent_log_entry_delete();


-- ============================================================================
-- PART 2: Sensor Calibration Registry
-- ============================================================================

CREATE TABLE IF NOT EXISTS sensor_calibrations (
  id                  VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id              VARCHAR NOT NULL REFERENCES organizations(id),
  vessel_id           VARCHAR NOT NULL REFERENCES vessels(id),
  equipment_id        VARCHAR REFERENCES equipment(id),

  -- Sensor identity
  sensor_tag          TEXT NOT NULL,
  -- Tag format: vessel-specific identifier (e.g., "ME-TC-VIB-001")
  sensor_type         TEXT NOT NULL,
  -- Types: 'vibration', 'temperature', 'pressure', 'flow', 'level',
  --        'rpm', 'torque', 'humidity', 'exhaust_gas', 'fuel_flow', 'other'
  sensor_location     TEXT,
  manufacturer        TEXT,
  model               TEXT,
  serial_number       TEXT,

  -- Calibration schedule
  calibration_interval_days INTEGER NOT NULL DEFAULT 365,
  last_calibration_date     DATE,
  next_calibration_due      DATE,
  calibration_standard      TEXT,
  -- e.g., "ISO 10816-3" for vibration, "IEC 60751" for temperature

  -- Last calibration results
  calibration_status        TEXT NOT NULL DEFAULT 'unknown',
  -- Statuses: 'calibrated', 'due', 'overdue', 'failed', 'decommissioned', 'unknown'
  drift_percentage          REAL,
  -- Measured drift from reference standard (null if not measured)
  accuracy_class            TEXT,
  -- e.g., "Class A" for Pt100, "±0.5%" for pressure transducer
  reference_instrument      TEXT,
  -- What was used as the reference standard

  -- Operational limits
  measurement_range_min     REAL,
  measurement_range_max     REAL,
  measurement_unit          TEXT,
  -- e.g., 'mm/s', '°C', 'bar', 'm³/h', 'RPM'
  alarm_low                 REAL,
  alarm_high                REAL,
  trip_low                  REAL,
  trip_high                 REAL,

  -- Metadata
  installed_date            DATE,
  decommissioned_date       DATE,
  notes                     TEXT,
  certificate_url           TEXT,
  -- URL to calibration certificate PDF

  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_sensor_cal_org_vessel
  ON sensor_calibrations (org_id, vessel_id);
CREATE INDEX IF NOT EXISTS idx_sensor_cal_equipment
  ON sensor_calibrations (equipment_id)
  WHERE equipment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_sensor_cal_due
  ON sensor_calibrations (org_id, next_calibration_due)
  WHERE calibration_status IN ('due', 'overdue');
CREATE INDEX IF NOT EXISTS idx_sensor_cal_tag
  ON sensor_calibrations (org_id, sensor_tag);

-- Calibration history (each calibration event)
CREATE TABLE IF NOT EXISTS sensor_calibration_events (
  id                  VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id              VARCHAR NOT NULL,
  calibration_id      VARCHAR NOT NULL REFERENCES sensor_calibrations(id) ON DELETE CASCADE,
  calibration_date    DATE NOT NULL,
  performed_by        TEXT,
  performed_by_rank   TEXT,

  -- Results
  status              TEXT NOT NULL,
  -- 'pass', 'fail', 'adjusted', 'replaced'
  drift_before        REAL,
  drift_after         REAL,
  reference_value     REAL,
  measured_value      REAL,
  adjusted_to         REAL,

  -- Documentation
  certificate_number  TEXT,
  certificate_url     TEXT,
  notes               TEXT,
  method              TEXT,
  -- 'field_check', 'workshop', 'manufacturer_service', 'external_lab'

  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sensor_cal_events
  ON sensor_calibration_events (calibration_id, calibration_date DESC);

-- Comments
COMMENT ON TABLE logbook_audit_log IS 'Immutable audit trail for all logbook operations. Cannot be updated or deleted. PSC officers reference this to verify logbook integrity.';
COMMENT ON TABLE sensor_calibrations IS 'Sensor calibration registry. Tracks calibration schedules, drift, accuracy, and operational limits for all sensors feeding telemetry data. Essential for PdM credibility.';
COMMENT ON COLUMN log_entries.correction_of IS 'FK to original entry being corrected. NULL for original entries. Corrections are new rows that reference the original — originals are never modified.';
COMMENT ON COLUMN log_entries.is_corrected IS 'Set to true when a correction exists for this entry. The original entry remains visible alongside the correction for PSC audit.';
