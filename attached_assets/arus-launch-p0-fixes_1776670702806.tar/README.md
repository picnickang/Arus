# ARUS Launch P0 Fixes — 4 Critical Deployment Blockers

These are the four concrete engineering fixes from the launch readiness
assessment that close real P0/P1 gaps without depending on external inputs
(cert procurement, real SHIPMATE data, vessel hardware, etc.).

**What this does NOT cover:** code-signing, streaming SHIPMATE parser,
72hr offline test, customer runbook, clean-VM install validation, or
anything else from the assessment that requires info or artifacts I don't
have. Those need you or your customer to unblock.

---

## The four fixes

### Fix #1 — SHIPMATE vessel resolver: exact match only

**Was:** `LIKE %name%` fallback silently matched "MV Sentinel" to
"MV Sentinel II" → cross-vessel data corruption on first real import.

**Now:** exact case-insensitive match only. Multiple matches or zero
matches throw `VesselResolutionError` with useful candidates. Caller
must handle and surface to UI (recommend showing a dropdown instead of
free-text name input).

**File:** `server/import-adapters/shipmate/import-service.ts` (full rewrite)

**Breaking change:** the `resolveVesselId` function no longer returns
null when a name doesn't match — it throws. Code paths that rely on
"import proceeds with null vesselId" will now fail. That's intentional;
the previous behavior was the bug.

### Fix #2 — SHIPMATE imports wrapped in transactions + audit manifest

**Was:** row-by-row upserts with no transaction wrapper. Mid-import crash
left the vessel DB in an undocumented partial state. No way for the
operator to answer "what did this import actually do?"

**Now:** each `importFile()` call wraps the entire per-module upsert loop
in `db.transaction()`. A new `import_manifest` table records one row per
import attempt with: source, module, vessel, row counts, status
(`running` / `committed` / `failed`), errors, timing. Row-level failures
abort the whole transaction (all-or-nothing semantics — the right default
for maritime audit). The operator can query `import_manifest` to see
exactly what happened.

**Files:**
- `shared/schema/import-manifest.ts` (new Drizzle table)
- `migrations/0015_import_manifest.sql`
- `server/import-adapters/shipmate/import-service.ts` (same file as Fix #1 — combined rewrite)

**Behavior change:** a single bad row now rolls back the entire
per-module import. If the operator is accustomed to best-effort imports
with a list of skipped rows, this is a change. The rationale: for
audit-critical maritime data, "90% imported, 10% silently missing" is
worse than "nothing imported, fix the bad row, re-try." The manifest
table makes the retry safe (it's idempotent at the module level).

### Fix #3 — Email worker expire-on-skip

**Was:** when SMTP was unconfigured, items stayed queued as "pending"
forever. First time SMTP was configured would trigger a backlog flush
— sending weeks-old alerts at once, blowing through rate limits,
burning sender reputation.

**Now:**
- Items older than `EMAIL_QUEUE_MAX_AGE_HOURS` (default 24) are marked
  `expired` in a single UPDATE at the top of every batch.
- When SMTP isn't configured, all `pending` items are immediately
  marked `expired` with a clear error message.
- New `getExpiredEmails()` and `requeueExpiredEmail()` helpers for
  operator visibility and manual re-send (not bulk).

**File:** `server/purchasing/email-worker.ts` (full rewrite)

**No DB migration needed** — `email_queue.status` is a free-form text
column; `expired` is just a new value used alongside the existing
`pending` / `sent` / `dead_letter` / `failed`.

### Fix #4 — STCW CSV parser

**Was:** hand-rolled `line.split(",")` corrupted any row where a field
contained a comma (crew names like "Lim, Ah Beng"), had quoted fields,
or used CRLF line endings.

**Now:** uses `papaparse` (already a dep) with `header: true` and
`skipEmptyLines: true`. RFC 4180 compliant — handles quoted fields,
escaped quotes, mixed line endings. CSV-parsing logic extracted to a
`parseRestCsv()` function so it can be unit-tested independently if
desired.

**File:** `server/domains/stcw-rest/routes/import.ts` (full rewrite)

**No new deps** — papaparse is already in package.json and used
elsewhere in the codebase.

---

## Application order

### 1. Drop in the new schema file

```bash
cp launch-p0/shared/schema/import-manifest.ts \
   shared/schema/import-manifest.ts
```

Re-export from your schema barrel (`shared/schema/index.ts`):

```ts
export * from "./import-manifest";
```

If you maintain a schema-runtime.ts cloud-only list, add `import_manifest`
— this table is cloud-only (the vessel side doesn't run imports directly).

### 2. Run the migration

```bash
psql "$DATABASE_URL" -f launch-p0/migrations/0015_import_manifest.sql
# or via your migration runner
```

Idempotent — uses `CREATE TABLE IF NOT EXISTS`.

### 3. Drop in the three rewritten files

```bash
cp launch-p0/server/import-adapters/shipmate/import-service.ts \
   server/import-adapters/shipmate/import-service.ts

cp launch-p0/server/purchasing/email-worker.ts \
   server/purchasing/email-worker.ts

cp launch-p0/server/domains/stcw-rest/routes/import.ts \
   server/domains/stcw-rest/routes/import.ts
```

### 4. Update the SHIPMATE import API handler

The HTTP handler that calls `shipmateImport.importFile()` needs to
catch `VesselResolutionError` and return a 400 with the candidates.
Find the caller with:

```bash
grep -rn "shipmateImport.importFile\|shipmateImport\.importFile" server/ client/
```

Update the handler along these lines:

```ts
import { VesselResolutionError } from "@/server/import-adapters/shipmate/import-service";

try {
  const result = await shipmateImport.importFile(orgId, csvText, options);
  res.json(result);
} catch (err) {
  if (err instanceof VesselResolutionError) {
    res.status(400).json({
      error: err.message,
      candidates: err.candidates,
    });
    return;
  }
  throw err;
}
```

### 5. Verify

```bash
npm run check 2>&1 | grep -c "error TS"
# Expect: approximately the same count as before (~3,540). These fixes
# don't target type errors specifically; they fix runtime correctness.

npm run test:unit
# Must stay 337/337. If any test touches SHIPMATE import or STCW CSV,
# it may need updates for the new transaction/parser behavior.

# Boot check:
npm start
# App should boot clean. No new domain registration failures.
```

### 6. Smoke-test the changed paths

**SHIPMATE import (exact name required):**
```bash
# Should succeed with exact match:
curl -X POST -H "Content-Type: application/json" \
  -d '{"module":"pms_equipment","vesselName":"MV Sentinel","csv":"..."}' \
  http://localhost:5000/api/shipmate/import

# Should 400 with candidates listed:
curl -X POST -H "Content-Type: application/json" \
  -d '{"module":"pms_equipment","vesselName":"MV Sentinal","csv":"..."}' \
  http://localhost:5000/api/shipmate/import
```

**Import manifest visibility:**
```bash
psql "$DATABASE_URL" -c "SELECT id, module, status, rows_total, rows_imported, error_message FROM import_manifest ORDER BY started_at DESC LIMIT 5;"
```

**STCW CSV with comma in crew name:**
```bash
curl -X POST -H "Content-Type: application/json" \
  -d '{"csv":"date,h0,h1\n2026-01-01,1,1","sheet":{"crewId":"test","crewName":"Lim, Ah Beng"}}' \
  http://localhost:5000/api/crew/rest/import
# Row should parse as {date: "2026-01-01", h0: 1, h1: 1}, not get scrambled
```

**Email worker expire-on-skip:**
```bash
# Without SMTP_HOST set, insert a pending email and wait 30s:
psql "$DATABASE_URL" -c "INSERT INTO email_queue (org_id, recipient_email, subject, html_content, status) VALUES ('test-org', 'x@test.com', 'test', '<p>x</p>', 'pending');"
# Wait ~35s for the worker poll:
psql "$DATABASE_URL" -c "SELECT id, status, error_message FROM email_queue WHERE recipient_email='x@test.com';"
# Expect: status='expired', error_message='SMTP not configured at time of attempt'
```

---

## Package contents

```
shared/schema/
  import-manifest.ts                              ← NEW

migrations/
  0015_import_manifest.sql                        ← NEW

server/import-adapters/shipmate/
  import-service.ts                               ← FULL REWRITE (Fix #1 + #2)

server/purchasing/
  email-worker.ts                                 ← FULL REWRITE (Fix #3)

server/domains/stcw-rest/routes/
  import.ts                                       ← FULL REWRITE (Fix #4)

README.md                                         ← This file
```

---

## What changed in behavior (read carefully)

Three of these fixes change observable behavior. Flag these when handing
off to UAT:

1. **SHIPMATE import now fails on ambiguous/missing vessel names.**
   The 400 error message tells the user what similar vessels exist. The
   UI should ideally be updated to use a vessel picker instead of a text
   field, but the error itself is actionable.

2. **SHIPMATE imports are now all-or-nothing per module.** One bad row
   in the CSV aborts the entire module's import. Before: partial success
   with skipped-rows list. After: fail fast, fix the bad row, re-upload.
   The `import_manifest` table makes re-imports auditable.

3. **Email queue entries expire.** Anything pending for 24+ hours (or all
   pending when SMTP is unconfigured) becomes status='expired' and never
   sends. Previously these would accumulate indefinitely. If the customer
   expects to see old queued emails eventually deliver once SMTP comes
   online, they should know that's no longer the case. The behavior change
   is deliberate — sending stale alerts is worse than not sending them.

---

## What's still not addressed from the assessment

These remain on the launch-readiness TODO list and are not in this package:

- **P0:** Code-signing cert (procurement, ~1 week lead time)
- **P0:** Non-streaming SHIPMATE parser (needs real export shape to design
  for — ask ARUS Sdn Bhd for a sanitized sample)
- **P0:** Outbox 10K silent drop (needs product decision: disk persistence
  vs backpressure vs operator escalation)
- **P0:** No 72hr offline test (needs vessel network profile to design
  for)
- **P0:** No customer runbook (writing task — engineering or customer
  success owns)
- **P1:** Clock-skew handling for LWW
- **P1:** Scheduled reports silent-fail on vessel mode
- **P1:** Upgrade rollback in installer
- **P1:** `atomicWriteEnv` admin-token corruption risk
- **P1:** Work-order completion payload lacks Zod validation
- **P1:** Dual-schema behavioral (not just structural) parity tests

Send me word on any of these when you have what's needed to work on them.
