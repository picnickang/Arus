/**
 * Crew Hub — Deferred Loading
 */

import { IconGridLayout, type GridItem } from "@/components/layouts";
import { Users, CalendarCheck, Clock, Shield } from "lucide-react";

const crewItems: GridItem[] = [
  {
    id: "roster",
    label: "Crew Roster",
    icon: Users,
    description: "Manage crew",
    load: () => import("./crew-management"),
    loaderVariant: "table",
    legacyRoutes: ["/crew-management"],
  },
  {
    id: "schedule",
    label: "Schedule Planner",
    icon: CalendarCheck,
    description: "SmartPAL scheduling",
    load: () => import("./schedule-planner"),
    loaderVariant: "table",
    legacyRoutes: ["/crew-scheduler", "/schedule-planner"],
  },
  {
    id: "hours-of-rest",
    label: "Hours of Rest",
    icon: Clock,
    description: "Rest compliance",
    load: () => import("./hours-of-rest"),
    loaderVariant: "table",
    legacyRoutes: ["/hours-of-rest"],
  },
];

export default function CrewHub() {
  return (
    <IconGridLayout
      title="Crew & Compliance"
      description="Crew management, scheduling, hours of rest, and STCW/MLC compliance"
      items={crewItems}
      defaultItemId="roster"
      baseRoute="/crew"
    />
  );
}
