/**
 * Home Page — Fixes Applied
 *
 * FIX: Single API call for attention items (was 3 separate queries)
 * FIX: trackPageVisit imported from shared module (was defined locally)
 * FIX: "Since last visit" section for watch handover awareness
 */

import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { PageHeader } from "@/components/navigation/PageHeader";
import { NavigationCard } from "@/components/navigation/NavigationCard";
import { QuickActions } from "@/components/shared/QuickActions";
import { AttentionBanner } from "@/components/shared/AttentionBanner";
import { homePageGroups, type HomePageGroup } from "@/config/navigationConfig";
import { trackPageVisit } from "@/lib/pageTracking";
import {
  Wrench, AlertTriangle, Clock, Activity, Ship, Shield,
  ClipboardCheck, Anchor, BookOpen, BarChart3, Settings,
  ChevronRight, Gauge, History,
} from "lucide-react";

// Re-export for backward compatibility (other files may import from here)
export { trackPageVisit };

// ============================================================================
// Role definitions
// ============================================================================

export interface RoleConfig {
  id: string;
  label: string;
  description: string;
  icon: any;
  quickActions: Array<{ label: string; icon: any; href: string; variant?: "default" | "destructive" | "outline" }>;
  pinnedGroups: string[];
}

const ROLES: Record<string, RoleConfig> = {
  chief_engineer: {
    id: "chief_engineer",
    label: "Chief Engineer",
    description: "Work orders, equipment health, PdM alerts",
    icon: Wrench,
    quickActions: [
      { label: "New Work Order", icon: ClipboardCheck, href: "/work-orders?action=create" },
      { label: "Log Engine Entry", icon: BookOpen, href: "/engine-logbook?action=new" },
      { label: "Report Defect", icon: AlertTriangle, href: "/work-orders?action=create&type=corrective" },
      { label: "Check PdM Alerts", icon: Activity, href: "/pdm-dashboard" },
    ],
    pinnedGroups: ["maintenance", "operations", "fleet"],
  },
  deck_officer: {
    id: "deck_officer",
    label: "Deck Officer",
    description: "Logbooks, STCW hours, vessel track, weather",
    icon: Anchor,
    quickActions: [
      { label: "New Deck Entry", icon: BookOpen, href: "/deck-logbook?action=new" },
      { label: "Record Rest Hours", icon: Clock, href: "/hours-of-rest?action=record" },
      { label: "Vessel Position", icon: Ship, href: "/vessel-track-log" },
      { label: "Compliance Check", icon: Shield, href: "/logs-compliance" },
    ],
    pinnedGroups: ["records", "crew", "operations"],
  },
  fleet_manager: {
    id: "fleet_manager",
    label: "Fleet Manager (Shore)",
    description: "Fleet health, CII compliance, analytics, costs",
    icon: BarChart3,
    quickActions: [
      { label: "Fleet Dashboard", icon: Gauge, href: "/dashboard" },
      { label: "Analytics", icon: BarChart3, href: "/analytics" },
      { label: "Scheduled Reports", icon: ClipboardCheck, href: "/scheduled-reports" },
      { label: "Governance", icon: Shield, href: "/governance-dashboard" },
    ],
    pinnedGroups: ["operations", "analytics", "fleet"],
  },
  system_admin: {
    id: "system_admin",
    label: "System Admin",
    description: "Diagnostics, configuration, sensors, users",
    icon: Settings,
    quickActions: [
      { label: "Diagnostics", icon: Activity, href: "/diagnostics" },
      { label: "Configuration", icon: Settings, href: "/configuration" },
      { label: "Sensor Management", icon: Activity, href: "/sensors" },
      { label: "System Admin", icon: Shield, href: "/system-administration" },
    ],
    pinnedGroups: ["system", "analytics", "operations"],
  },
};

const STORAGE_KEY = "arus-user-role";
const LAST_VISIT_KEY = "arus-last-visit-time";

// ============================================================================
// Role selector
// ============================================================================

function RoleSelector({ onSelect }: { onSelect: (roleId: string) => void }) {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
      <div className="max-w-lg w-full text-center mb-8">
        <h1 className="text-2xl font-bold mb-2" data-testid="text-welcome-title">Welcome to ARUS</h1>
        <p className="text-muted-foreground">
          Choose your role to customize your home screen. You can change this anytime in Settings.
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg w-full">
        {Object.values(ROLES).map((role) => {
          const Icon = role.icon;
          return (
            <button
              key={role.id}
              onClick={() => onSelect(role.id)}
              data-testid={`button-role-${role.id}`}
              className="flex flex-col items-center gap-3 p-6 rounded-xl border border-border bg-card hover:border-primary hover:bg-primary/5 transition-all text-left cursor-pointer touch-target"
            >
              <Icon className="h-8 w-8 text-primary" />
              <div className="text-center">
                <div className="font-semibold text-sm">{role.label}</div>
                <div className="text-xs text-muted-foreground mt-1">{role.description}</div>
              </div>
            </button>
          );
        })}
      </div>
      <button
        onClick={() => onSelect("default")}
        data-testid="button-skip-role"
        className="mt-6 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        Skip — show all categories
      </button>
    </div>
  );
}

// ============================================================================
// FIX: Single API call for attention items
// ============================================================================

function useAttentionItems() {
  // Single endpoint that returns all attention counts
  const { data } = useQuery<{
    overdueWorkOrders: number;
    unacknowledgedAlerts: number;
    highRiskEquipment: number;
    newSinceLastVisit?: {
      newAlerts: number;
      completedWorkOrders: number;
      newWorkOrders: number;
    };
  }>({
    queryKey: ["/api/home/attention-summary"],
    refetchInterval: 60000,
  });

  return useMemo(() => {
    if (!data) return { attentionItems: [], sinceLastVisit: null };

    const items: Array<{ label: string; count: number; severity: string; href: string }> = [];

    if (data.overdueWorkOrders > 0) {
      items.push({ label: "Overdue work orders", count: data.overdueWorkOrders, severity: "critical", href: "/work-orders?status=overdue" });
    }
    if (data.unacknowledgedAlerts > 0) {
      items.push({ label: "Unacknowledged alerts", count: data.unacknowledgedAlerts, severity: "warning", href: "/dashboard" });
    }
    if (data.highRiskEquipment > 0) {
      items.push({ label: "High-risk equipment", count: data.highRiskEquipment, severity: "warning", href: "/pdm-dashboard" });
    }

    return { attentionItems: items, sinceLastVisit: data.newSinceLastVisit || null };
  }, [data]);
}

// ============================================================================
// FIX: "Since Last Visit" section for watch handover
// ============================================================================

function SinceLastVisit({ data }: { data: { newAlerts: number; completedWorkOrders: number; newWorkOrders: number } }) {
  const [, setLocation] = useLocation();

  const hasChanges = data.newAlerts > 0 || data.completedWorkOrders > 0 || data.newWorkOrders > 0;
  if (!hasChanges) return null;

  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 mb-3">
        <History className="h-4 w-4 text-muted-foreground" />
        <h2 className="text-sm font-semibold text-foreground">Since Your Last Visit</h2>
      </div>
      <div className="flex gap-3 overflow-x-auto pb-1">
        {data.newAlerts > 0 && (
          <button
            onClick={() => setLocation("/dashboard")}
            className="flex items-center gap-2 px-3 py-2 rounded-lg border border-yellow-500/30 bg-yellow-500/5 hover:bg-yellow-500/10 transition-colors text-sm flex-shrink-0"
            data-testid="since-last-visit-alerts"
          >
            <span className="font-bold text-yellow-500">{data.newAlerts}</span>
            <span className="text-muted-foreground">new alert{data.newAlerts !== 1 ? "s" : ""}</span>
          </button>
        )}
        {data.newWorkOrders > 0 && (
          <button
            onClick={() => setLocation("/work-orders")}
            className="flex items-center gap-2 px-3 py-2 rounded-lg border border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors text-sm flex-shrink-0"
            data-testid="since-last-visit-new-wo"
          >
            <span className="font-bold text-primary">{data.newWorkOrders}</span>
            <span className="text-muted-foreground">new work order{data.newWorkOrders !== 1 ? "s" : ""}</span>
          </button>
        )}
        {data.completedWorkOrders > 0 && (
          <button
            onClick={() => setLocation("/work-orders?status=completed")}
            className="flex items-center gap-2 px-3 py-2 rounded-lg border border-green-500/30 bg-green-500/5 hover:bg-green-500/10 transition-colors text-sm flex-shrink-0"
            data-testid="since-last-visit-completed"
          >
            <span className="font-bold text-green-500">{data.completedWorkOrders}</span>
            <span className="text-muted-foreground">completed</span>
          </button>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// My Tasks
// ============================================================================

function MyTasks() {
  const { data: myWorkOrders } = useQuery({
    queryKey: ["/api/work-orders?assignedToMe=true&status=open"],
    refetchInterval: 60000,
  });

  const [, setLocation] = useLocation();
  const tasks = Array.isArray(myWorkOrders) ? myWorkOrders.slice(0, 5) : [];

  if (tasks.length === 0) return null;

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-semibold text-foreground">My Tasks</h2>
        <button
          onClick={() => setLocation("/work-orders?assignedToMe=true")}
          data-testid="link-view-all-tasks"
          className="text-xs text-primary hover:underline flex items-center gap-1"
        >
          View all <ChevronRight className="h-3 w-3" />
        </button>
      </div>
      <div className="space-y-2">
        {tasks.map((task: any) => (
          <button
            key={task.id}
            onClick={() => setLocation(`/work-orders?id=${task.id}`)}
            data-testid={`button-task-${task.id}`}
            className="w-full flex items-center gap-3 p-3 rounded-lg border border-border bg-card hover:border-primary/50 transition-colors text-left touch-target"
          >
            <div className={cn(
              "w-2 h-2 rounded-full flex-shrink-0",
              task.priority === 1 ? "bg-destructive" : task.priority === 2 ? "bg-yellow-500" : "bg-muted-foreground"
            )} />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{task.title}</div>
              <div className="text-xs text-muted-foreground">{task.equipmentName || task.equipment?.name || "Unassigned"}</div>
            </div>
            <div className="text-xs text-muted-foreground flex-shrink-0">
              {task.dueDate ? new Date(task.dueDate).toLocaleDateString() : "No due date"}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// Main Home Page
// ============================================================================

export default function HomePage() {
  const [role, setRole] = useState<string | null>(() => {
    try { return localStorage.getItem(STORAGE_KEY); } catch { return null; }
  });

  const { attentionItems, sinceLastVisit } = useAttentionItems();
  const roleConfig = role ? ROLES[role] : null;

  const handleSelectRole = (roleId: string) => {
    localStorage.setItem(STORAGE_KEY, roleId);
    setRole(roleId);
    // Record visit time when role is first selected
    localStorage.setItem(LAST_VISIT_KEY, new Date().toISOString());
  };

  // Record last visit time on mount
  useState(() => {
    try { localStorage.setItem(LAST_VISIT_KEY, new Date().toISOString()); } catch {}
  });

  if (!role) {
    return <RoleSelector onSelect={handleSelectRole} />;
  }

  const pinnedGroupIds = roleConfig?.pinnedGroups ?? homePageGroups.map((g) => g.id);
  const pinnedGroups = pinnedGroupIds
    .map((id) => homePageGroups.find((g) => g.id === id))
    .filter(Boolean) as HomePageGroup[];
  const otherGroups = homePageGroups.filter((g) => !pinnedGroupIds.includes(g.id));

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-4">
      <PageHeader
        title="ARUS"
        subtitle={roleConfig?.label}
        showHome={false}
        action={
          <button
            onClick={() => { localStorage.removeItem(STORAGE_KEY); setRole(null); }}
            data-testid="button-change-role"
            className="text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded"
          >
            Change role
          </button>
        }
      />

      <div className="px-4 lg:px-6 pt-2">
        {attentionItems.length > 0 && (
          <AttentionBanner items={attentionItems} className="mb-4" />
        )}

        {roleConfig && (
          <QuickActions actions={roleConfig.quickActions} className="mb-6" />
        )}

        {sinceLastVisit && <SinceLastVisit data={sinceLastVisit} />}

        <MyTasks />

        <div className="space-y-6">
          {pinnedGroups.map((group) => (
            <div key={group.id}>
              <h2 className="text-sm font-semibold text-foreground mb-3">{group.name}</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {group.items.map((item) => (
                  <NavigationCard key={item.href} name={item.name} href={item.href} icon={item.icon} description={item.description} />
                ))}
              </div>
            </div>
          ))}
        </div>

        {otherGroups.length > 0 && (
          <details className="mt-8">
            <summary className="text-sm font-semibold text-muted-foreground cursor-pointer hover:text-foreground mb-3" data-testid="button-more-categories">
              More categories ({otherGroups.length})
            </summary>
            <div className="space-y-6 mt-3">
              {otherGroups.map((group) => (
                <div key={group.id}>
                  <h2 className="text-sm font-semibold text-foreground mb-3">{group.name}</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {group.items.map((item) => (
                      <NavigationCard key={item.href} name={item.name} href={item.href} icon={item.icon} description={item.description} />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </details>
        )}
      </div>
    </div>
  );
}
