/**
 * Dashboard Extracted Components
 *
 * FIX: The dashboard had 500+ character single-line JSX expressions that
 * were functionally correct but unmaintainable. These extracted components
 * replace the inline table/list renderers in dashboard-improved.tsx.
 *
 * Import these in dashboard-improved.tsx and replace the inline JSX.
 */

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { StatusIndicator } from "@/components/status-indicator";
import { HealthIndexTooltip } from "@/components/HealthLegend";
import { Eye, Plus } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

// ============================================================================
// Devices Table
// ============================================================================

interface Device {
  id: string;
  vessel?: string;
  status: string;
  lastHeartbeat?: {
    cpuPct?: number;
    memPct?: number;
    ts?: string;
  };
}

export function DevicesTable({ devices, isLoading }: { devices: Device[]; isLoading: boolean }) {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Device ID</TableHead>
            <TableHead>Vessel</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>CPU</TableHead>
            <TableHead>Memory</TableHead>
            <TableHead>Last Heartbeat</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center text-muted-foreground">
                Loading devices...
              </TableCell>
            </TableRow>
          ) : (
            devices?.map((device) => (
              <TableRow key={device.id} className="hover:bg-muted">
                <TableCell className="font-mono text-sm" data-testid={`device-id-${device.id}`}>
                  {device.id}
                </TableCell>
                <TableCell data-testid={`device-vessel-${device.id}`}>
                  {device.vessel || "Unknown"}
                </TableCell>
                <TableCell>
                  <StatusIndicator status={device.status} showLabel />
                </TableCell>
                <TableCell data-testid={`device-cpu-${device.id}`}>
                  {device.lastHeartbeat?.cpuPct ? `${device.lastHeartbeat.cpuPct}%` : "–"}
                </TableCell>
                <TableCell data-testid={`device-memory-${device.id}`}>
                  {device.lastHeartbeat?.memPct ? `${device.lastHeartbeat.memPct}%` : "–"}
                </TableCell>
                <TableCell data-testid={`device-heartbeat-${device.id}`}>
                  {device.lastHeartbeat?.ts
                    ? formatDistanceToNow(new Date(device.lastHeartbeat.ts), { addSuffix: true })
                    : "Never"}
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}

// ============================================================================
// Telemetry Readings Table
// ============================================================================

interface TelemetryReading {
  equipmentId: string;
  sensorType: string;
  value?: number;
  unit?: string;
  status?: string;
  ts?: string;
}

function getReadingStatusClassName(status?: string): string {
  switch (status?.toLowerCase()) {
    case "normal": return "bg-green-500/10 text-green-500";
    case "warning": return "bg-yellow-500/10 text-yellow-500";
    case "critical": return "bg-destructive/10 text-destructive";
    default: return "bg-muted text-muted-foreground";
  }
}

export function TelemetryTable({
  readings,
  isLoading,
  getEquipmentName,
}: {
  readings: TelemetryReading[];
  isLoading: boolean;
  getEquipmentName: (id: string) => string;
}) {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Equipment</TableHead>
            <TableHead>Sensor Type</TableHead>
            <TableHead>Value</TableHead>
            <TableHead>Unit</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Timestamp</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center text-muted-foreground">
                Loading latest readings...
              </TableCell>
            </TableRow>
          ) : readings?.length > 0 ? (
            readings.slice(0, 10).map((reading, index) => (
              <TableRow
                key={`${reading.equipmentId}-${reading.sensorType}-${index}`}
                className="hover:bg-muted"
              >
                <TableCell className="font-medium">
                  {getEquipmentName(reading.equipmentId)}
                </TableCell>
                <TableCell>{reading.sensorType}</TableCell>
                <TableCell className="font-medium">
                  {reading.value?.toFixed(2) || "–"}
                </TableCell>
                <TableCell>{reading.unit || "–"}</TableCell>
                <TableCell>
                  <span className={`px-2 py-1 text-xs rounded-full ${getReadingStatusClassName(reading.status)}`}>
                    {reading.status?.toUpperCase() || "UNKNOWN"}
                  </span>
                </TableCell>
                <TableCell>
                  {reading.ts
                    ? formatDistanceToNow(new Date(reading.ts), { addSuffix: true })
                    : "Never"}
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={6} className="text-center text-muted-foreground">
                No telemetry readings available
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}

// ============================================================================
// Equipment Health List
// ============================================================================

interface EquipmentHealthItem {
  id: string;
  name?: string;
  vessel?: string;
  status: string;
  healthIndex: number;
  predictedDueDays?: number;
}

function getHealthClassName(healthIndex: number): string {
  if (healthIndex >= 70) return "text-green-500";
  if (healthIndex >= 40) return "text-yellow-500";
  return "text-destructive";
}

export function EquipmentHealthList({
  equipment,
  isLoading,
  isFocusMode = false,
}: {
  equipment: EquipmentHealthItem[];
  isLoading: boolean;
  isFocusMode?: boolean;
}) {
  const displayEquipment = isFocusMode
    ? equipment.filter((e) => e.healthIndex < 50)
    : equipment;

  if (isLoading) {
    return <div className="text-center text-muted-foreground py-4">Loading equipment health...</div>;
  }

  return (
    <div className="space-y-0">
      {displayEquipment.map((eq) => (
        <div
          key={eq.id}
          className={`flex flex-wrap items-center gap-3 py-2.5 px-1 border-b border-border/30 last:border-0 hover:bg-muted/30 transition-colors ${
            eq.healthIndex < 50 ? "bg-destructive/5" : ""
          }`}
          data-testid={`equipment-${eq.id}`}
        >
          <StatusIndicator status={eq.status} />
          <div className="flex-1 min-w-0">
            <span className="font-medium text-foreground truncate">
              {eq.name || eq.id}
            </span>
            <span className="text-xs text-muted-foreground ml-2 truncate">
              • {eq.vessel}
            </span>
          </div>
          <div className="flex items-center gap-3 sm:gap-4 text-sm flex-shrink-0">
            <HealthIndexTooltip>
              <div className="text-right cursor-help">
                <span className={`font-medium ${getHealthClassName(eq.healthIndex)}`}>
                  {eq.healthIndex}%
                </span>
              </div>
            </HealthIndexTooltip>
            <div className="text-right min-w-[50px]">
              <span className="text-xs text-muted-foreground">
                {eq.predictedDueDays}d
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ============================================================================
// Work Orders Table
// ============================================================================

interface WorkOrderItem {
  id: string;
  workOrderNumber?: string;
  equipmentId: string;
  priority: number;
  status: string;
  createdAt: string;
}

function getPriorityClassName(priority: number): string {
  switch (priority) {
    case 1: return "bg-destructive/10 text-destructive";
    case 2: return "bg-yellow-500/10 text-yellow-500";
    default: return "bg-muted text-muted-foreground";
  }
}

function getPriorityText(priority: number): string {
  switch (priority) {
    case 1: return "Critical";
    case 2: return "High";
    case 3: return "Medium";
    default: return "Low";
  }
}

export function WorkOrdersTable({
  workOrders,
  isLoading,
  isFocusMode = false,
  getEquipmentName,
  onNewOrder,
}: {
  workOrders: WorkOrderItem[];
  isLoading: boolean;
  isFocusMode?: boolean;
  getEquipmentName: (id: string) => string;
  onNewOrder?: () => void;
}) {
  const displayOrders = isFocusMode
    ? workOrders.filter((wo) => wo.priority <= 2)
    : workOrders?.slice(0, 10);

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Order ID</TableHead>
            <TableHead>Equipment</TableHead>
            <TableHead>Priority</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Created</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center text-muted-foreground">
                Loading work orders...
              </TableCell>
            </TableRow>
          ) : (
            displayOrders?.map((order) => (
              <TableRow key={order.id} className="hover:bg-muted">
                <TableCell className="font-mono text-sm" data-testid={`work-order-id-${order.id}`}>
                  {order.workOrderNumber || order.id}
                </TableCell>
                <TableCell data-testid={`work-order-equipment-${order.id}`}>
                  {getEquipmentName(order.equipmentId)}
                </TableCell>
                <TableCell>
                  <span className={`px-2 py-1 text-xs rounded-full ${getPriorityClassName(order.priority)}`}>
                    {getPriorityText(order.priority)}
                  </span>
                </TableCell>
                <TableCell data-testid={`work-order-status-${order.id}`}>
                  {order.status}
                </TableCell>
                <TableCell data-testid={`work-order-created-${order.id}`}>
                  {formatDistanceToNow(new Date(order.createdAt), { addSuffix: true })}
                </TableCell>
                <TableCell>
                  <Button variant="ghost" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
