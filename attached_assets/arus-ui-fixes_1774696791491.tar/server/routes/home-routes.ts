/**
 * Home Attention Summary Route
 *
 * FIX: Single endpoint replacing 3 separate queries from the home page.
 * Returns overdue work orders, unacknowledged alerts, high-risk equipment,
 * and "since last visit" delta counts — all in one response.
 *
 * Register: app.get("/api/home/attention-summary", ...)
 */

import type { Express, Request, Response } from "express";
import { withErrorHandling } from "../lib/route-utils";
import { logger } from "../utils/logger";

export function registerHomeRoutes(app: Express, deps: { storage: any; generalApiRateLimit: any }) {
  const { storage, generalApiRateLimit } = deps;

  app.get("/api/home/attention-summary", generalApiRateLimit,
    withErrorHandling("get home attention summary", async (req: Request, res: Response) => {
      const orgId = (req as any).orgId || req.headers["x-org-id"] as string;
      if (!orgId) {
        return res.status(401).json({ message: "Organization ID required" });
      }

      // Parse last visit time from header (sent by the frontend)
      const lastVisitHeader = req.headers["x-last-visit"] as string;
      const lastVisitTime = lastVisitHeader ? new Date(lastVisitHeader) : null;

      // Run all queries in parallel — single round trip from the client
      const [workOrderSummary, alerts, pdmRiskQueue] = await Promise.allSettled([
        storage.getWorkOrderSummary?.(orgId).catch(() => null),
        storage.getAlertNotifications?.(false, orgId).catch(() => []),
        storage.getPdmRiskQueue?.(orgId).catch(() => []),
      ]);

      // Extract counts
      const woData = workOrderSummary.status === "fulfilled" ? workOrderSummary.value : null;
      const alertData = alerts.status === "fulfilled" ? alerts.value : [];
      const pdmData = pdmRiskQueue.status === "fulfilled" ? pdmRiskQueue.value : [];

      const overdueWorkOrders = woData?.overdue ?? woData?.overdueCount ?? 0;
      const unacknowledgedAlerts = Array.isArray(alertData) ? alertData.length : 0;
      const highRiskEquipment = Array.isArray(pdmData)
        ? pdmData.filter((e: any) => e.riskLevel === "high" || e.riskLevel === "critical").length
        : 0;

      // "Since last visit" delta (optional — only if lastVisitTime provided)
      let newSinceLastVisit = undefined;

      if (lastVisitTime && !isNaN(lastVisitTime.getTime())) {
        try {
          const [recentAlerts, recentWOs, completedWOs] = await Promise.allSettled([
            storage.getAlertNotificationsSince?.(orgId, lastVisitTime).catch(() => []),
            storage.getWorkOrdersSince?.(orgId, lastVisitTime, "created").catch(() => []),
            storage.getWorkOrdersSince?.(orgId, lastVisitTime, "completed").catch(() => []),
          ]);

          newSinceLastVisit = {
            newAlerts: Array.isArray(recentAlerts.status === "fulfilled" ? recentAlerts.value : [])
              ? (recentAlerts.status === "fulfilled" ? recentAlerts.value : []).length
              : 0,
            newWorkOrders: Array.isArray(recentWOs.status === "fulfilled" ? recentWOs.value : [])
              ? (recentWOs.status === "fulfilled" ? recentWOs.value : []).length
              : 0,
            completedWorkOrders: Array.isArray(completedWOs.status === "fulfilled" ? completedWOs.value : [])
              ? (completedWOs.status === "fulfilled" ? completedWOs.value : []).length
              : 0,
          };
        } catch {
          // Delta is optional — don't fail the whole response
        }
      }

      res.json({
        overdueWorkOrders,
        unacknowledgedAlerts,
        highRiskEquipment,
        newSinceLastVisit,
      });
    })
  );

  logger.info("HomeRoutes", "Registered /api/home/attention-summary");
}
