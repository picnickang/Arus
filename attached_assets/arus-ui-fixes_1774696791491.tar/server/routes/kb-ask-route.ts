/**
 * KB Ask Route — Unified search + analyze
 *
 * FIX: Single endpoint for the Inline AI Assistant instead of
 * two sequential client calls to /api/kb/search + /api/llm/analyze.
 *
 * Register: app.post("/api/kb/ask", ...)
 */

import type { Express, Request, Response } from "express";
import { withErrorHandling } from "../lib/route-utils";
import { logger } from "../utils/logger";

export function registerKbAskRoute(app: Express, deps: {
  generalApiRateLimit: any;
  writeOperationRateLimit: any;
}) {
  const { writeOperationRateLimit } = deps;

  app.post("/api/kb/ask", writeOperationRateLimit,
    withErrorHandling("kb ask", async (req: Request, res: Response) => {
      const orgId = (req as any).orgId || req.headers["x-org-id"] as string;
      if (!orgId) {
        return res.status(401).json({ message: "Organization ID required" });
      }

      const { query, context, equipmentId, vesselId } = req.body;

      if (!query || typeof query !== "string") {
        return res.status(400).json({ message: "query is required" });
      }

      // Step 1: Search knowledge base
      let kbResults: any[] = [];
      let kbContext = "";
      try {
        const { searchKnowledgeBase } = await import("../services/kb-search");
        kbResults = await searchKnowledgeBase({
          orgId,
          query,
          limit: 3,
          threshold: 0.3,
          openAiKey: process.env.OPENAI_API_KEY,
        });
        kbContext = kbResults.map((r: any) => r.content || r.text || "").filter(Boolean).join("\n\n");
      } catch (err) {
        logger.warn("KbAsk", "KB search failed, continuing with LLM only", err);
      }

      // Step 2: Analyze with LLM (if available)
      let answer = "";
      try {
        const { analyzeWithLlm } = await import("../services/llm-analysis");
        const llmResult = await analyzeWithLlm({
          query,
          context: [context, kbContext].filter(Boolean).join("\n\n"),
          equipmentId,
          vesselId,
          orgId,
        });
        answer = llmResult?.analysis || llmResult?.response || llmResult?.text || "";
      } catch (err) {
        logger.warn("KbAsk", "LLM analysis failed, returning KB results only", err);
        // Fallback: return raw KB content
        if (kbResults.length > 0) {
          answer = kbContext;
        } else {
          answer = "I couldn't find relevant information for your query. Please try rephrasing or check the Knowledge Base for uploaded documentation.";
        }
      }

      const sources = kbResults.map((r: any) => ({
        title: r.title || r.documentTitle || "Document",
        relevance: r.relevance || r.score || 0,
        documentId: r.documentId || r.id,
      }));

      res.json({
        answer,
        sources,
        query,
        context: context || null,
      });
    })
  );

  logger.info("KbAskRoute", "Registered POST /api/kb/ask");
}
