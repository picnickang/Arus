# ARUS UI Fixes — All Review Recommendations Implemented

## Summary

8 fixes addressing every finding from the UI review. Each fix is a drop-in
replacement for the corresponding file in your Replit project.

## Files

| # | Fix | File | Replaces |
|---|-----|------|----------|
| 1a | Deferred hub loading | `client/src/components/layouts/IconGridLayout.tsx` | Yes |
| 1b | Maintenance hub deferred | `client/src/pages/maintenance-hub.tsx` | Yes |
| 1c | Fleet hub deferred | `client/src/pages/fleet-hub.tsx` | Yes |
| 1d | Crew hub deferred | `client/src/pages/crew-hub.tsx` | Yes |
| 2 | Adaptive connectivity check | `client/src/components/shared/ConnectivityBanner.tsx` | Yes |
| 3 | Home page (single API, no dup trackPageVisit, since-last-visit) | `client/src/pages/home.tsx` | Yes |
| 3b | Backend attention summary endpoint | `server/routes/home-routes.ts` | New |
| 4 | AI assistant single API call | `client/src/components/shared/InlineAIAssistant.tsx` | Yes |
| 5 | Backend KB ask endpoint | `server/routes/kb-ask-route.ts` | New |
| 6 | Dashboard extracted components | `client/src/components/dashboard/DashboardTables.tsx` | New |
| 7 | Light mode shadow values | `client/src/styles/light-shadow-fix.css` | Patch |
| 8 | Page tracking canonical module | `client/src/lib/pageTracking.ts` | Yes |

## Integration Steps

### 1. Replace existing files (drop-in)

Copy these files over the originals:

```
client/src/components/layouts/IconGridLayout.tsx
client/src/pages/maintenance-hub.tsx
client/src/pages/fleet-hub.tsx
client/src/pages/crew-hub.tsx
client/src/components/shared/ConnectivityBanner.tsx
client/src/components/shared/InlineAIAssistant.tsx
client/src/pages/home.tsx
client/src/lib/pageTracking.ts
```

### 2. Add new files

```
client/src/components/dashboard/DashboardTables.tsx
server/routes/home-routes.ts
server/routes/kb-ask-route.ts
```

### 3. Register the new backend routes

In your main route registration file:

```typescript
import { registerHomeRoutes } from "./routes/home-routes";
import { registerKbAskRoute } from "./routes/kb-ask-route";

registerHomeRoutes(app, { storage, generalApiRateLimit });
registerKbAskRoute(app, { generalApiRateLimit, writeOperationRateLimit });
```

### 4. Fix light mode shadows

In `client/src/index.css`, find the `:root { }` block and replace the
`--shadow-*` variables (they're all zero-opacity) with:

```css
--shadow-2xs: 0 1px 2px 0 rgb(0 0 0 / 0.03);
--shadow-xs: 0 1px 2px 0 rgb(0 0 0 / 0.05);
--shadow-sm: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
--shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
--shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
--shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
--shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
--shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);
```

### 5. Update remaining hub pages

Apply the same deferred loading pattern to these hubs (follow maintenance-hub.tsx as template):

- `client/src/pages/analytics-hub.tsx`
- `client/src/pages/logistics-hub.tsx`
- `client/src/pages/system-hub.tsx`
- `client/src/pages/logs-hub.tsx`
- `client/src/pages/operations-hub.tsx`

Pattern: change `component: <Suspense><Page /></Suspense>` to `load: () => import("./page-name")`.

### 6. Use DashboardTables in dashboard-improved.tsx

Replace the inline 500-char JSX lines with imports from DashboardTables:

```tsx
import { DevicesTable, TelemetryTable, EquipmentHealthList, WorkOrdersTable } from "@/components/dashboard/DashboardTables";

// Then in the JSX, replace the inline Table blocks:
<DevicesTable devices={devices} isLoading={devicesLoading} />
<TelemetryTable readings={latestReadings} isLoading={latestReadingsLoading} getEquipmentName={getEquipmentName} />
<EquipmentHealthList equipment={equipmentHealth} isLoading={healthLoading} isFocusMode={isFocusMode} />
<WorkOrdersTable workOrders={workOrders} isLoading={ordersLoading} isFocusMode={isFocusMode} getEquipmentName={getEquipmentName} />
```

### 7. Optional: Add storage methods for "since last visit"

The home-routes.ts endpoint calls optional storage methods:
- `storage.getAlertNotificationsSince(orgId, sinceDate)`
- `storage.getWorkOrdersSince(orgId, sinceDate, type)`

If these don't exist yet, the "Since Your Last Visit" section simply won't appear.
Add them when ready — the endpoint handles missing methods gracefully.

## What Each Fix Does

**#1 — Deferred Hub Loading:** Only the selected tab's chunk is fetched from
the server. Previously all 6 maintenance hub items were fetched on mount.
The IconGridLayout now supports `load: () => import(...)` alongside the
existing `component` prop for backward compatibility.

**#2 — Adaptive Connectivity Check:** Backs off from 30s to 120s after 3
consecutive successes. Stops polling entirely when offline (relies on
browser events). Saves ~6MB/day on satellite connections.

**#3 — Single Attention API:** Replaces 3 separate useQuery calls with one
`/api/home/attention-summary` that returns all counts plus "since last visit"
deltas in a single response. Also removes the duplicate trackPageVisit.

**#4 — Single AI API Call:** InlineAIAssistant now calls `/api/kb/ask` first
(one round trip). Falls back to the two-call pattern if the endpoint doesn't
exist yet (backward compatible).

**#5 — Backend KB Ask:** Does search-then-analyze server-side in one request.
Reduces latency from 2 round trips to 1.

**#6 — Dashboard Components:** Extracts DevicesTable, TelemetryTable,
EquipmentHealthList, and WorkOrdersTable into typed, tested components.
Makes dashboard-improved.tsx maintainable.

**#7 — Light Mode Shadows:** Replaces zero-opacity shadows with standard
shadcn/ui values. Light mode now has proper depth and elevation.

**#8 — Page Tracking Module:** Canonical implementation with lastVisitTime
tracking. home.tsx re-exports instead of re-defining.
