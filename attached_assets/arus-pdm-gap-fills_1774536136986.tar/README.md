# ARUS PdM Gap Fill Implementations

Six production-ready services that close the gaps between "impressive demo" and "trusted by fleet operators."

## Files

```
server/
├── services/
│   ├── ml/
│   │   ├── prediction-calibration.ts      (#1 — Platt scaling + isotonic regression)
│   │   ├── prediction-outcome-tracker.ts   (#2 — Automated feedback loop)
│   │   ├── model-evaluation-gate.ts        (#5 — Deploy gate with AUROC, F1, Brier)
│   │   └── ml-training-job-queue.ts        (#6 — Background training via pg-boss)
│   ├── anomaly-correlation/
│   │   └── anomaly-correlator.ts           (#3 — Cross-sensor diagnosis grouping)
│   └── telemetry-aggregation/
│       └── telemetry-aggregator.ts         (#4 — Pre-computed rollups: 1m/1h/1d)
└── routes/
    └── pdm-gap-fill-routes.ts              (API routes for all six services)
```

## Integration Steps

### 1. Copy files into your project

Drop the `server/services/` and `server/routes/` directories into your Replit project,
preserving the folder structure.

### 2. Register the routes

In your main route registration file (or `domain-router-registry.ts`), add:

```typescript
import { registerPdmGapFillRoutes } from "./routes/pdm-gap-fill-routes";

// After other route registrations:
registerPdmGapFillRoutes(app, {
  storage,
  db,
  generalApiRateLimit,
  writeOperationRateLimit,
  wsServer: getWebSocketServer(),
});
```

### 3. Create the telemetry aggregation table

Run the SQL migration for pre-computed rollups. You can find the DDL in
`telemetry-aggregator.ts` (exported as `AGGREGATION_TABLE_SQL`), or run it manually:

```sql
CREATE TABLE IF NOT EXISTS telemetry_aggregated (
  id              SERIAL PRIMARY KEY,
  org_id          TEXT NOT NULL,
  equipment_id    TEXT NOT NULL,
  sensor_type     TEXT NOT NULL,
  bucket_start    TIMESTAMPTZ NOT NULL,
  bucket_size     TEXT NOT NULL CHECK (bucket_size IN ('1_minute', '1_hour', '1_day')),
  count           INTEGER NOT NULL DEFAULT 0,
  min_value       DOUBLE PRECISION,
  max_value       DOUBLE PRECISION,
  avg_value       DOUBLE PRECISION,
  stddev_value    DOUBLE PRECISION,
  p50_value       DOUBLE PRECISION,
  p95_value       DOUBLE PRECISION,
  p99_value       DOUBLE PRECISION,
  first_value     DOUBLE PRECISION,
  last_value      DOUBLE PRECISION,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (org_id, equipment_id, sensor_type, bucket_start, bucket_size)
);

CREATE INDEX IF NOT EXISTS idx_telemetry_agg_lookup
  ON telemetry_aggregated (org_id, equipment_id, sensor_type, bucket_size, bucket_start);
```

### 4. Schedule the background jobs

Add to your existing cron/scheduler setup:

```typescript
// Run every hour: aggregate telemetry + evaluate prediction outcomes
import { TelemetryAggregator } from "./services/telemetry-aggregation/telemetry-aggregator";
import { PredictionOutcomeTracker } from "./services/ml/prediction-outcome-tracker";

// In your scheduler:
schedule("0 * * * *", async () => {
  const aggregator = new TelemetryAggregator(db);
  await aggregator.runScheduledAggregation(orgId);
  await aggregator.cleanupOldAggregations();

  const tracker = new PredictionOutcomeTracker(db, storage);
  await tracker.evaluatePredictions(orgId);
});
```

### 5. Wire calibration into the prediction flow

In your `ml-prediction-service.ts`, after generating a raw prediction:

```typescript
import { PredictionCalibrator } from "./services/ml/prediction-calibration";

const calibrator = new PredictionCalibrator(db);
const rawProbability = prediction.failureProbability;
const calibratedProbability = calibrator.calibrate(rawProbability, orgId, modelId);
prediction.failureProbability = calibratedProbability;
prediction.isCalibrated = calibrator.isCalibrated(orgId, modelId);
```

### 6. Adapt storage queries

The services reference your existing schema tables (`failurePredictions`, `workOrders`,
`predictionFeedback`, `modelPerformanceValidations`, `anomalyDetections`). If your
column names differ from what's assumed, update the queries in:

- `prediction-calibration.ts` → `fetchCalibrationData()`
- `prediction-outcome-tracker.ts` → `getEligiblePredictions()`, `determineOutcome()`
- `telemetry-aggregator.ts` → `aggregateRange()` (the raw telemetry table name)

---

## New API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/ml/calibration/fit` | Fit calibration model from historical data |
| GET | `/api/ml/calibration/report` | Get calibration metrics + reliability diagram |
| POST | `/api/ml/outcomes/evaluate` | Run prediction outcome evaluation (scheduled) |
| GET | `/api/analytics/anomaly-groups` | Get correlated anomaly diagnosis groups |
| POST | `/api/telemetry/aggregation/run` | Trigger telemetry rollup aggregation |
| GET | `/api/telemetry/aggregated/:eqId/:sensor` | Query pre-computed aggregates |
| POST | `/api/ml/evaluate-model` | Evaluate model against test data before deploy |
| POST | `/api/ml/train/async` | Enqueue background training job |
| GET | `/api/ml/train/status/:jobId` | Poll training job status |
| GET | `/api/ml/train/jobs` | List recent training jobs for org |

---

## What Each Service Does

### #1 Prediction Calibration
Makes confidence scores meaningful. Fits Platt scaling (logistic sigmoid) or isotonic
regression (PAV algorithm) on historical prediction-outcome pairs. After fitting, a
confidence of 0.85 means "85% of predictions at this confidence level were correct."
Reports Brier score, ECE, and MCE metrics. Generates reliability diagram data for
frontend visualization.

### #2 Prediction Outcome Tracker
Automatically compares past predictions against actual maintenance events. For each
prediction whose window has passed, checks work orders and alerts to determine if
failure actually occurred. Computes precision/recall/F1 per model. Triggers retraining
via scheduler event bus when accuracy drops below threshold (default 70%).

### #3 Anomaly Correlation
Groups anomalies by temporal proximity + equipment into diagnosis clusters. Matches
against known failure signatures (bearing failure, overheating, cavitation, etc.) to
generate root cause suggestions and recommended actions. Transforms 47 individual
alerts into "Pump #3 developing bearing failure — schedule inspection within 48 hours."

### #4 Telemetry Aggregation
Pre-computes 1-minute, 1-hour, and 1-day rollups from raw telemetry using PostgreSQL
aggregation functions (min, max, avg, stddev, p50, p95, p99). Queries automatically
select the optimal bucket for the requested time range. Idempotent (safe to re-run).
Includes cleanup job that removes old 1-minute data after 7 days and 1-hour after 90.

### #5 Model Evaluation Gate
Prevents deploying a model that's worse than the current production model. Computes
accuracy, precision, recall, F1, AUROC, and Brier score on held-out test data. Requires
both absolute thresholds (recall ≥ 65%, precision ≥ 60%) and relative improvement
over the current model. Records evaluations in the model_performance_validations table.

### #6 ML Training Job Queue
Routes training requests through pg-boss so they don't block the API event loop.
Supports LSTM, Random Forest, XGBoost, and "all" training types. Single-concurrency
worker prevents memory exhaustion. Returns job ID immediately for status polling.
Sends WebSocket notification on completion.
