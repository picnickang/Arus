# PdM Decision-Support Test Update — 2026-05-08

This update adds a focused Jest unit test for the new hexagonal PdM decision-support module.

## Added files

- `tests/unit/pdm-decision-support.test.ts`
- `jest.config.cjs`

## What the test covers

1. The decision-support service returns the standardized PdM contract.
2. A worsening equipment condition raises `alertNeeded` and recommends work-order creation.
3. Low-data/short-window cases are handled safely and recommend more telemetry instead of irreversible maintenance.
4. Unsafe AI/PdM recommendations are blocked by the safety adapter.
5. Synthetic telemetry generation works for the bearing-wear scenario.
6. Missing equipment context fails clearly with `Equipment not found`.

## Run only this test

```bash
node --experimental-vm-modules node_modules/jest/bin/jest.js tests/unit/pdm-decision-support.test.ts --runInBand
```

## Run the normal unit test suite

```bash
npm run test:unit
```

## Recommended full validation after upload

```bash
npm install
npm run typecheck
npm run lint
node --experimental-vm-modules node_modules/jest/bin/jest.js tests/unit/pdm-decision-support.test.ts --runInBand
npm run test:pdm
npm run build
```
