# ARUS Bug Fix Package — Wave 3

**Targets the 3 UI-consumer files from the top-10 list** plus documents
what's auto-resolved by applying wave 2.

Wave 3 is small because — as expected — most of the remaining top-10 file
errors cascade-resolve after wave 2's schema patch lands.

---

## What this wave delivers

### ✅ File rewrites

| File | Errors | Fix type |
|---|---|---|
| `client/src/features/analytics/hooks/useFinanceModeData.ts` | 33 | TanStack Query v5 generics + explicit callback types |

### 🔧 Patch (manual edit)

| File | Errors | Fix |
|---|---|---|
| `client/src/pages/vessel-dashboard.tsx` | 35 | Add return type to `useVesselDetail()` hook OR cast at destructure site |

### ⏭ Auto-resolved by wave 2 (no work needed here)

| File | Why no fix needed |
|---|---|
| `client/src/features/telemetry/hooks/useOperatingParametersData.ts` (43 errors) | All errors trace to `optimalMin/Max`, `criticalMin/Max`, `equipmentType`, `manufacturer`, `parameterType`, `lifeImpactDescription`, `recommendedAction` missing from `OperatingParameter` type. Wave 2's schema patch adds these columns to PG; `createInsertSchema` auto-propagates them through `InsertOperatingParameter`/`OperatingParameter` types; errors disappear. |

---

## Package contents

```
client/src/
  features/analytics/hooks/useFinanceModeData.ts   ← DROP-IN REPLACEMENT (33 errors)
  pages/vessel-dashboard.patch.ts                  ← PATCH instructions (35 errors)

README.md                                          ← This file
```

---

## Application order

### Step 1: Confirm wave 2 is fully applied

Before applying wave 3, ensure wave 2's schema patch is applied (code + SQL
migration). If it's not, `useOperatingParametersData.ts` will still have its
43 errors when you run the type check. That's fine — just don't confuse
wave 3's work with wave 2's.

### Step 2: Drop in the finance hook

```bash
cp fix3/client/src/features/analytics/hooks/useFinanceModeData.ts \
   ../arus/client/src/features/analytics/hooks/useFinanceModeData.ts

npm run check 2>&1 | grep -c "error TS"
# Expect: drop of ~33 errors from this file alone
```

### Step 3: Apply vessel-dashboard patch

Open `client/src/pages/vessel-dashboard.patch.ts` for instructions.

**Preferred fix:** open the actual `useVesselDetail.ts` hook (not in bug
bundle — find it by running `grep -rn "export function useVesselDetail"
client/src/`) and add an explicit return type. Then the call site in
vessel-dashboard.tsx needs no changes.

**Fallback fix:** in vessel-dashboard.tsx ~line 362, cast the destructure:

```ts
const {
  match, vesselId, vessel, vesselLoading, equipment, equipmentLoading,
  vesselWorkOrders, vesselCrew, vesselMaintenanceSchedules,
  activeWorkOrders, completedWorkOrders, powerSTWDateRange,
  workOrdersLoading, crewLoading, schedulesLoading,
} = useVesselDetail() as UseVesselDetailReturn;
```

Where `UseVesselDetailReturn` is the interface from the patch file.

### Step 4: Verify

```bash
npm run check 2>&1 | grep -c "error TS"
# Expect: ~3,560 (down ~140 from wave 2's expected 3,700)
# 33 from useFinanceModeData + 35 from vessel-dashboard + 43 cascading
#   from useOperatingParametersData = ~111 direct + cascades

npm run test:unit
# Must stay 337/337
```

---

## Cumulative progress

| Wave | Start | End | Delta |
|---|---|---|---|
| Baseline | — | 4,554 | — |
| Wave 1 | 4,554 | 3,897 | -657 |
| Wave 2 (expected) | 3,897 | ~3,700 | -197 |
| Wave 3 (expected) | ~3,700 | ~3,560 | -140 |
| **Cumulative** | **4,554** | **~3,560** | **-994 (-22%)** |

---

## What's left after wave 3

**~3,560 errors remaining.** Three buckets:

1. **Two deferred files** (~73 errors) — `settings-service.ts` and
   `ml-governance-routes.ts`. Waiting on your product decisions in
   `fix2/docs/deferred-fixes.md`.

2. **Missing source file** (~34 errors) — `db-maintenance-templates.ts`
   wasn't in the bug bundle. Send it and I'll fix it next wave.

3. **The long tail** (~3,450 errors) — distributed across many files
   with no single dominant pattern. Typical file has 5-20 errors. Next
   wave's strategy depends entirely on the new top-10 after waves 1-3
   apply. Send me that list and I'll pick the highest-leverage cluster.

---

## Send me after applying

1. New `npm run check 2>&1 | grep -c "error TS"` count
2. New top-10 offenders
3. Your decisions on the 2 deferred files
4. `db-maintenance-templates.ts` source
