/**
 * ============================================================================
 * PATCH to client/src/pages/vessel-dashboard.tsx
 * ============================================================================
 *
 * 35 errors all trace to `equipment` and `vessel` being typed as `unknown`/`{}`
 * because `useVesselDetail()` has an untyped return shape. The real fix is to
 * type the hook in its own file (client/src/features/vessel/hooks/useVesselDetail.ts
 * or similar), but this patch resolves the call-site errors with a type
 * assertion pending the proper hook fix.
 *
 * Apply: in vessel-dashboard.tsx, around line 362 where `useVesselDetail()` is
 * destructured, REPLACE the destructure block with the version below.
 * ============================================================================
 */

import type { Vessel, Equipment, WorkOrder, Crew, MaintenanceSchedule } from "@shared/schema-runtime";

// Type for the return of useVesselDetail(). If the hook already has a return
// type, import it instead of declaring locally and delete this interface.
interface UseVesselDetailReturn {
  match: boolean;
  vesselId: string;
  vessel: Vessel;
  vesselLoading: boolean;
  equipment: Equipment[];
  equipmentLoading: boolean;
  vesselWorkOrders: WorkOrder[];
  vesselCrew: Crew[];
  vesselMaintenanceSchedules: MaintenanceSchedule[];
  activeWorkOrders: WorkOrder[];
  completedWorkOrders: WorkOrder[];
  powerSTWDateRange: { start: Date; end: Date } | null;
  workOrdersLoading: boolean;
  crewLoading: boolean;
  schedulesLoading: boolean;
}

// REPLACE the destructure at ~line 362 with this:
//
// Instead of:
//   const {
//     match, vesselId, vessel, vesselLoading, equipment, equipmentLoading,
//     vesselWorkOrders, vesselCrew, vesselMaintenanceSchedules,
//     activeWorkOrders, completedWorkOrders, powerSTWDateRange,
//     workOrdersLoading, crewLoading, schedulesLoading,
//   } = useVesselDetail();
//
// Write:
//
//   const {
//     match, vesselId, vessel, vesselLoading, equipment, equipmentLoading,
//     vesselWorkOrders, vesselCrew, vesselMaintenanceSchedules,
//     activeWorkOrders, completedWorkOrders, powerSTWDateRange,
//     workOrdersLoading, crewLoading, schedulesLoading,
//   } = useVesselDetail() as UseVesselDetailReturn;

/* ============================================================================
 * Proper fix (recommended): open `useVesselDetail.ts` and add an explicit
 * return type on the hook:
 *
 *   export function useVesselDetail(): UseVesselDetailReturn {
 *     // ... existing body ...
 *   }
 *
 * Then the cast here becomes unnecessary — delete the `as UseVesselDetailReturn`
 * and let inference do its work.
 * ============================================================================ */
