# ARUS Bug Fix Package — Wave 4

**Baseline going in:** 3,575 TypeScript errors, 337/337 tests passing,
app boots clean, drift validator passes (115 known, 0 new).

**Expected going out:** ~3,475 errors (drop of ~100).

Decisions resolved, deferred files unblocked, plus the missing
maintenance-templates source now fixed.

---

## What this wave delivers

### ✅ Decision 1 — `settings-service.ts` split (~35 errors)

Option A (split tables). New `email_settings` table holds SMTP
infrastructure config per-org. `alert_settings` keeps routing/policy
(enabled, cooldown, category toggles). Service composes the public
DTO from both sources.

### ✅ Decision 2 — `engineer_overrides` ML fields (~0 errors — but fixes
the deferred cluster)

Option B continued. Adds `engineerId`, `engineerName`, `justification`
columns. Relaxes `reason` to nullable. Wave 2 did most of the work; these
three are the leftover so `ml-governance-routes.ts` stops breaking.

Note on the error count: `ml-governance-routes.ts` is NOT in the current
top-15, which means wave 2's columns already suppressed most of the
compile errors there. This wave's additions are belt-and-suspenders to
match exactly what the code references.

### ✅ `db-maintenance-templates.ts` (~34 errors)

Column renames, EntityType fix, removed references to columns that never
existed. Per-item checklist operations removed from this file (delegated
to `db-checklists.ts` from wave 1 — one source of truth per table).

---

## Package contents

```
shared/schema/
  email-settings.ts                         ← NEW: emailSettings table + Zod schemas
  engineer-overrides.patch.ts               ← Patch instructions for telemetry.ts

shared/
  schema-runtime.patch.ts                   ← Patch instructions for cloud-only export

server/db/maintenance-templates/
  db-maintenance-templates.ts               ← DROP-IN REPLACEMENT (34 errors)

server/domains/alerts/
  settings-service.ts                       ← DROP-IN REPLACEMENT (35 errors)
  email-settings-repository.ts              ← NEW: repository for email_settings

migrations/
  0013_email_settings.sql                   ← CREATE TABLE email_settings
  0014_engineer_overrides_ml_fields.sql     ← ADD COLUMN engineer_id, engineer_name, justification

README.md                                   ← This file
```

---

## Critical finding — Decision 1 reality check

The decisions.md premise mentioned `notification_settings`, but the
actually-conflated table in production is `alert_settings`. Both tables
exist, with different purposes:

- `alert_settings` — per-org routing (enabled, cooldown, per-category
  toggles, admin/technical/operations email)
- `notification_settings` — per-org × notification_type delivery rules
  (recipientEmails, recipientRoles, digestMode) — unchanged

The code in `settings-service.ts` was calling `alertSettingsRepository`
expecting it to hold SMTP fields. None of those fields existed on
`alert_settings`. The split — new `email_settings` table + existing
`alert_settings` — still matches Decision 1's architectural intent
(Option A). Field renames in the service code:

- `emailEnabled` → `enabled` (on alert_settings)
- `alertCooldownMinutes` → `defaultCooldownMinutes` (on alert_settings)
- everything SMTP-side moves to new `email_settings` table

The public DTO `AlertSettingsPublic` keeps its existing field names
(`emailEnabled`, `alertCooldownMinutes`, etc.) so frontend needs zero
changes.

---

## Application order

### Step 1: Add the new Drizzle schema file

```bash
cp fix4/shared/schema/email-settings.ts \
   shared/schema/email-settings.ts
```

Re-export from your schema barrel (`shared/schema/index.ts`):

```ts
export * from "./email-settings";
```

### Step 2: Apply the schema-runtime patch

Open `fix4/shared/schema-runtime.patch.ts` and follow the 3 changes:

1. Add `export const emailSettings = (IS_POSTGRES ? ...) as typeof ...` in
   the POSTGRESQL-ONLY TABLES section
2. Add `insertEmailSettingsSchema`, `updateEmailSettingsSchema`,
   `emailSettingsTestResultSchema` to the Zod re-export block
3. (Optional) Add `email_settings` to `scripts/drift-baseline.json`
   cloud-only list

### Step 3: Apply the engineer_overrides schema patch

Open `fix4/shared/schema/engineer-overrides.patch.ts`. Replace the
existing `engineerOverrides = pgTable(...)` definition in
`shared/schema/telemetry.ts` with the version in the patch.

Key changes: +3 new columns (`engineerId`, `engineerName`, `justification`),
`reason` relaxed to nullable, +2 new indexes.

### Step 4: Run migrations

```bash
# Apply in order:
psql "$DATABASE_URL" -f fix4/migrations/0013_email_settings.sql
psql "$DATABASE_URL" -f fix4/migrations/0014_engineer_overrides_ml_fields.sql

# Or via your migration tool:
npm run db:migrate
```

Both migrations use `ADD COLUMN IF NOT EXISTS` / `CREATE TABLE IF NOT EXISTS`
and are idempotent.

### Step 5: Drop in the new repository and service rewrite

```bash
cp fix4/server/domains/alerts/email-settings-repository.ts \
   server/domains/alerts/email-settings-repository.ts

cp fix4/server/domains/alerts/settings-service.ts \
   server/domains/alerts/settings-service.ts
```

### Step 6: Drop in the maintenance-templates rewrite

```bash
cp fix4/server/db/maintenance-templates/db-maintenance-templates.ts \
   server/db/maintenance-templates/db-maintenance-templates.ts
```

### Step 7: Find and update callers of removed methods

The following methods were REMOVED from `db-maintenance-templates.ts`:

- `getWorkOrderChecklists`
- `getWorkOrderChecklist`
- `createWorkOrderChecklist`
- `updateWorkOrderChecklist`
- `deleteWorkOrderChecklist`
- `completeChecklistItem`
- `uncompleteChecklistItem`
- `getChecklistProgress`
- `applyTemplateToWorkOrder`

Run this to find callers (if any):

```bash
grep -rn "maintenanceTemplatesStorage\.\(getWorkOrderChecklists\|createWorkOrderChecklist\|completeChecklistItem\|applyTemplateToWorkOrder\|getChecklistProgress\)" server/ client/
```

Each caller should migrate to `dbChecklistsStorage` from
`server/db/checklists/db-checklists.ts`. Mapping in the file's header
comment. If the migration requires method-level changes I don't have
visibility into, flag and send me the usage site.

### Step 8: Verify

```bash
npm run check 2>&1 | grep -c "error TS"
# Expect: ~3,475 (down ~100 from 3,575)

npm run test:unit
# Must stay 337/337

npm run check:guards
# Must stay 5/5 green

# Drift validator:
npm run drift:check
# Should show 116 known (existing 115 + email_settings), 0 new
# Or 118 if you also register the 3 engineer_overrides columns
```

### Step 9: Smoke test the API

```bash
# New endpoints (or existing endpoints backed by new schema):
curl -H "x-org-id: <id>" http://localhost:5000/api/alerts/settings | jq
curl -X PUT -H "x-org-id: <id>" -H "Content-Type: application/json" \
  -d '{"smtpHost":"smtp.example.com","smtpPort":587,"smtpUseTls":true}' \
  http://localhost:5000/api/alerts/settings | jq

# Verify engineer_overrides query returns the new columns:
curl -H "x-org-id: <id>" http://localhost:5000/api/compliance/ml-governance/overrides | jq '.[0] | keys'
# Should include: engineerId, engineerName, justification
```

---

## Cumulative progress

| Wave | Start | End | Delta | Tests |
|------|------:|----:|------:|------:|
| Baseline  | — | 4,554 | — | 337/337 |
| Wave 1    | 4,554 | 3,897 | -657 | 337/337 |
| Wave 2    | 3,897 | 3,612 | -285 | 337/337 |
| Wave 3    | 3,612 | 3,575 | -37  | 337/337 |
| Wave 4 (expected) | 3,575 | ~3,475 | -100 | 337/337 |
| **Cumulative** | **4,554** | **~3,475** | **-1,079 (-24%)** | |

---

## What's left after wave 4

~3,475 errors. The remaining work is the long tail:

From the wave 4 top-15 that are still untouched (~183 errors):
- `model-routes.ts` (31)
- `vibration-routes.ts` (29)
- `useOperatingParametersData.ts` (28) — didn't auto-resolve; has
  TanStack v5 / narrowing issues beyond the schema additions
- `useMaintenanceModeData.ts` (28)
- `degradation-analysis.ts` (27)
- `pdm-equipment-detail.tsx` (27)
- `features/index.ts` (26)
- `EquipmentFormDialog.tsx` (26)
- `condition-monitoring-log.tsx` (25)
- `sensor-mappings.ts` (24)
- `work-order-service.ts` (24)
- `telemetry-ingestion-routes.ts` (24)
- `sensorTemplates.ts` (24)

Strategy going into wave 5: we're at the point where further bug-fix work
has diminishing returns vs. domain leak repair. Recommend pausing waves
and letting the domain work drive error reductions as it goes. When you
hit a checkpoint, send a fresh top-10 with error-code breakdown and
I'll cut another targeted wave if the dominant patterns still have
structural fixes.

---

## Send me after applying

1. New `npm run check 2>&1 | grep -c "error TS"` count
2. `npm run test:unit` (must stay 337/337)
3. Drift validator output
4. Any caller-site issues from Step 7 (the removed workOrderChecklists
   methods) that weren't obvious
