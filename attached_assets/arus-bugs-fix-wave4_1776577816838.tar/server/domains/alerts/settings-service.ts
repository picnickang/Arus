/**
 * Alert Settings Service
 * Business logic for email and alert configuration.
 *
 * WAVE 4 REFACTOR — Decision 1, Option A:
 * - SMTP infrastructure config moved to a new `email_settings` table
 *   (one row per org, referenced by new `emailSettingsRepository`)
 * - Routing/policy config (enabled, cooldown, category toggles) stays in
 *   `alert_settings` via the existing `alertSettingsRepository`
 * - Field renames in the code to match the actual `alertSettings` schema:
 *     `emailEnabled` → `enabled`
 *     `alertCooldownMinutes` → `defaultCooldownMinutes`
 * - `AlertSettingsPublic` now composed from both sources; its shape is
 *   preserved for API/UI compatibility (no frontend changes required)
 *
 * DEPENDS ON:
 * - shared/schema/email-settings.ts (new table — see wave 4 package)
 * - migrations/0013_email_settings.sql (new migration)
 * - server/domains/alerts/email-settings-repository.ts (new — see below)
 * - dailyDigestEnabled / dailyDigestTime are NOT currently backed by schema;
 *   preserved in the DTO as constants for now. Add to alert_settings if
 *   digest scheduling is actually implemented.
 */

import { alertSettingsRepository } from "./settings-repository";
import { emailSettingsRepository } from "./email-settings-repository";
import {
  emailProviderService,
  type EmailConfig,
  type EmailPayload,
} from "../../services/email-provider-service";
import { encryptSecret } from "../../lib/crypto-service";
import { logger } from "../../utils/logger.js";
import type {
  AlertSettings,
  InsertAlertSettings,
  AlertSettingsVessel,
  InsertAlertSettingsVessel,
  AlertThreshold,
  InsertAlertThreshold,
  AlertEmailLog,
  CrewAlertSettings,
  InsertCrewAlertSettings,
  EmailSettings,
  InsertEmailSettings,
  UpdateEmailSettings,
} from "@shared/schema-runtime";

/**
 * Public-facing shape for `GET /api/alerts/settings` and similar endpoints.
 * Shape unchanged from pre-wave-4 to preserve API compatibility — the
 * service now composes it from two tables.
 */
export interface AlertSettingsPublic {
  id: string;
  orgId: string;
  // --- Routing / policy (from alert_settings) ---
  emailEnabled: boolean;
  alertCooldownMinutes: number;
  dailyDigestEnabled: boolean;
  dailyDigestTime: string | null;
  // --- SMTP infrastructure (from email_settings) ---
  defaultToEmail: string | null;
  ccEmails: string[] | null;
  bccEmails: string[] | null;
  timezone: string;
  provider: string;
  smtpHost: string | null;
  smtpPort: number | null;
  smtpUser: string | null;
  smtpUseTls: boolean;
  fromEmail: string;
  fromName: string;
  lastTestStatus: string | null;
  lastTestAt: Date | null;
  lastTestError: string | null;
  hasApiKey: boolean;
  hasSmtpPassword: boolean;
  // --- Timestamps ---
  createdAt: Date | null;
  updatedAt: Date | null;
}

type LogLevel = "info" | "warn" | "error";

const logHandlers: Record<
  LogLevel,
  (ctx: string, msg: string, data?: string) => void
> = {
  error: (ctx, msg, data) => logger.error(ctx, msg, data),
  warn: (ctx, msg, data) => logger.warn(ctx, msg, data),
  info: (ctx, msg, data) => logger.info(ctx, msg, data),
};

function log(
  level: LogLevel,
  message: string,
  context: Record<string, unknown> = {}
) {
  const contextStr = Object.entries(context)
    .filter(([_, v]) => v !== undefined)
    .map(([k, v]) => `${k}=${typeof v === "object" ? JSON.stringify(v) : v}`)
    .join(" ");

  logHandlers[level]("AlertSettings", message, contextStr || undefined);
}

export class AlertSettingsService {
  // ──────────────────────────────────────────────────────────────────
  // Combined settings (main API for the settings UI)
  // ──────────────────────────────────────────────────────────────────

  async getSettings(orgId: string): Promise<AlertSettingsPublic> {
    const [alertSettings, emailSettings] = await Promise.all([
      alertSettingsRepository.getOrgSettings(orgId),
      emailSettingsRepository.getOrgSettings(orgId),
    ]);

    if (!alertSettings && !emailSettings) {
      return this.getDefaultSettings(orgId);
    }

    return this.toPublicSettings(alertSettings, emailSettings);
  }

  async updateSettings(
    orgId: string,
    data: Partial<InsertAlertSettings> &
      Partial<UpdateEmailSettings> & {
        apiKey?: string;
        smtpPassword?: string;
        // Routing-side aliases that frontend may still send:
        emailEnabled?: boolean;
        alertCooldownMinutes?: number;
      }
  ): Promise<AlertSettingsPublic> {
    const { apiKey, smtpPassword, ...rest } = data;

    // Split the combined payload into the two stores.
    const alertUpdate: Partial<InsertAlertSettings> = {};
    const emailUpdate: Partial<InsertEmailSettings> = { orgId };

    // Routing-side fields go to alert_settings
    if (rest.emailEnabled !== undefined) alertUpdate.enabled = rest.emailEnabled;
    if (rest.enabled !== undefined) alertUpdate.enabled = rest.enabled;
    if (rest.alertCooldownMinutes !== undefined)
      alertUpdate.defaultCooldownMinutes = rest.alertCooldownMinutes;
    if (rest.defaultCooldownMinutes !== undefined)
      alertUpdate.defaultCooldownMinutes = rest.defaultCooldownMinutes;
    if (rest.adminEmail !== undefined) alertUpdate.adminEmail = rest.adminEmail;
    if (rest.technicalEmail !== undefined)
      alertUpdate.technicalEmail = rest.technicalEmail;
    if (rest.operationsEmail !== undefined)
      alertUpdate.operationsEmail = rest.operationsEmail;
    if (rest.machineryAlertsEnabled !== undefined)
      alertUpdate.machineryAlertsEnabled = rest.machineryAlertsEnabled;
    if (rest.telemetryAlertsEnabled !== undefined)
      alertUpdate.telemetryAlertsEnabled = rest.telemetryAlertsEnabled;
    if (rest.complianceAlertsEnabled !== undefined)
      alertUpdate.complianceAlertsEnabled = rest.complianceAlertsEnabled;
    if (rest.crewAlertsEnabled !== undefined)
      alertUpdate.crewAlertsEnabled = rest.crewAlertsEnabled;
    if (rest.logbookAlertsEnabled !== undefined)
      alertUpdate.logbookAlertsEnabled = rest.logbookAlertsEnabled;
    if (rest.maintenanceAlertsEnabled !== undefined)
      alertUpdate.maintenanceAlertsEnabled = rest.maintenanceAlertsEnabled;
    if (rest.useVesselSpecificSettings !== undefined)
      alertUpdate.useVesselSpecificSettings = rest.useVesselSpecificSettings;

    // SMTP-side fields go to email_settings
    if (rest.provider !== undefined) emailUpdate.provider = rest.provider;
    if (rest.timezone !== undefined) emailUpdate.timezone = rest.timezone;
    if (rest.smtpHost !== undefined) emailUpdate.smtpHost = rest.smtpHost;
    if (rest.smtpPort !== undefined) emailUpdate.smtpPort = rest.smtpPort;
    if (rest.smtpUser !== undefined) emailUpdate.smtpUser = rest.smtpUser;
    if (rest.smtpUseTls !== undefined) emailUpdate.smtpUseTls = rest.smtpUseTls;
    if (rest.fromEmail !== undefined) emailUpdate.fromEmail = rest.fromEmail;
    if (rest.fromName !== undefined) emailUpdate.fromName = rest.fromName;
    if (rest.defaultToEmail !== undefined)
      emailUpdate.defaultToEmail = rest.defaultToEmail;
    if (rest.ccEmails !== undefined) emailUpdate.ccEmails = rest.ccEmails;
    if (rest.bccEmails !== undefined) emailUpdate.bccEmails = rest.bccEmails;
    if (apiKey) emailUpdate.smtpPasswordEncrypted = encryptSecret(apiKey);
    if (smtpPassword)
      emailUpdate.smtpPasswordEncrypted = encryptSecret(smtpPassword);

    // Only write each side if there's something to update for it.
    const [alertResult, emailResult] = await Promise.all([
      Object.keys(alertUpdate).length > 0
        ? alertSettingsRepository.upsertOrgSettings(orgId, alertUpdate)
        : alertSettingsRepository.getOrgSettings(orgId),
      Object.keys(emailUpdate).length > 1 // > 1 because orgId is always set
        ? emailSettingsRepository.upsertOrgSettings(orgId, emailUpdate)
        : emailSettingsRepository.getOrgSettings(orgId),
    ]);

    log("info", "Alert settings updated", { orgId });

    return this.toPublicSettings(alertResult, emailResult);
  }

  // ──────────────────────────────────────────────────────────────────
  // Composition helpers
  // ──────────────────────────────────────────────────────────────────

  private getDefaultSettings(orgId: string): AlertSettingsPublic {
    return {
      id: "",
      orgId,
      emailEnabled: false,
      defaultToEmail: null,
      ccEmails: null,
      bccEmails: null,
      timezone: "Asia/Singapore",
      provider: "sendgrid",
      smtpHost: null,
      smtpPort: 587,
      smtpUser: null,
      smtpUseTls: true,
      fromEmail: "noreply@arus-marine.com",
      fromName: "ARUS Marine",
      alertCooldownMinutes: 30,
      dailyDigestEnabled: false,
      dailyDigestTime: "08:00",
      lastTestStatus: null,
      lastTestAt: null,
      lastTestError: null,
      hasApiKey: false,
      hasSmtpPassword: false,
      createdAt: null,
      updatedAt: null,
    };
  }

  private toPublicSettings(
    alert: AlertSettings | undefined | null,
    email: EmailSettings | undefined | null
  ): AlertSettingsPublic {
    const defaults = this.getDefaultSettings(alert?.orgId ?? email?.orgId ?? "");

    return {
      id: alert?.id ?? "",
      orgId: alert?.orgId ?? email?.orgId ?? "",

      // Routing (from alert_settings)
      emailEnabled: alert?.enabled ?? defaults.emailEnabled,
      alertCooldownMinutes:
        alert?.defaultCooldownMinutes ?? defaults.alertCooldownMinutes,
      // dailyDigest* are not backed by schema yet — constants for now.
      dailyDigestEnabled: defaults.dailyDigestEnabled,
      dailyDigestTime: defaults.dailyDigestTime,

      // SMTP (from email_settings)
      defaultToEmail: email?.defaultToEmail ?? null,
      ccEmails: email?.ccEmails ?? null,
      bccEmails: email?.bccEmails ?? null,
      timezone: email?.timezone ?? defaults.timezone,
      provider: email?.provider ?? defaults.provider,
      smtpHost: email?.smtpHost ?? null,
      smtpPort: email?.smtpPort ?? defaults.smtpPort,
      smtpUser: email?.smtpUser ?? null,
      smtpUseTls: email?.smtpUseTls ?? defaults.smtpUseTls,
      fromEmail: email?.fromEmail ?? defaults.fromEmail,
      fromName: email?.fromName ?? defaults.fromName,
      lastTestStatus: email?.lastTestStatus ?? null,
      lastTestAt: email?.lastTestAt ?? null,
      lastTestError: email?.lastTestError ?? null,
      hasApiKey: !!email?.smtpPasswordEncrypted,
      hasSmtpPassword: !!email?.smtpPasswordEncrypted,

      // Timestamps: prefer alert.updatedAt, fall back to email.updatedAt
      createdAt: alert?.createdAt ?? email?.createdAt ?? null,
      updatedAt: alert?.updatedAt ?? email?.updatedAt ?? null,
    };
  }

  // ──────────────────────────────────────────────────────────────────
  // SMTP connection testing (hits email_settings only)
  // ──────────────────────────────────────────────────────────────────

  async testEmailConnection(
    orgId: string
  ): Promise<{ success: boolean; error?: string }> {
    const settings = await emailSettingsRepository.getOrgSettings(orgId);

    if (!settings) {
      return { success: false, error: "Email settings not configured" };
    }

    const config = this.buildEmailConfig(settings);
    const result = await emailProviderService.testConnection(config);

    await emailSettingsRepository.recordTestResult(orgId, {
      lastTestStatus: result.success ? "success" : "failed",
      lastTestAt: new Date(),
      lastTestError: result.error ?? null,
    });

    log(result.success ? "info" : "warn", "Email connection test", {
      orgId,
      success: result.success,
      error: result.error,
    });

    return result;
  }

  async sendTestEmail(
    orgId: string,
    recipientEmail: string
  ): Promise<{ success: boolean; error?: string; messageId?: string }> {
    const settings = await emailSettingsRepository.getOrgSettings(orgId);

    if (!settings) {
      return { success: false, error: "Email settings not configured" };
    }

    const config = this.buildEmailConfig(settings);

    const payload: EmailPayload = {
      to: [recipientEmail],
      subject: "ARUS Marine - Test Email",
      text:
        "This is a test email from ARUS Marine alert system. If you received this, your email configuration is working correctly.",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #2563eb;">ARUS Marine - Test Email</h1>
          <p>This is a test email from the ARUS Marine alert system.</p>
          <p>If you received this, your email configuration is working correctly.</p>
          <hr style="border: 1px solid #e5e7eb; margin: 20px 0;" />
          <p style="color: #6b7280; font-size: 12px;">
            Sent at: ${new Date().toISOString()}<br/>
            Provider: ${config.provider}
          </p>
        </div>
      `,
    };

    const result = await emailProviderService.sendEmail(config, payload);

    await alertSettingsRepository.logEmail({
      orgId,
      alertType: "test",
      severity: "info",
      recipients: [recipientEmail],
      subject: payload.subject,
      status: result.success ? "sent" : "failed",
      messageId: result.messageId,
      errorMessage: result.error,
    });

    await emailSettingsRepository.recordTestResult(orgId, {
      lastTestStatus: result.success ? "success" : "failed",
      lastTestAt: new Date(),
      lastTestError: result.error ?? null,
    });

    log(result.success ? "info" : "warn", "Test email sent", {
      orgId,
      recipient: recipientEmail,
      success: result.success,
    });

    return result;
  }

  private buildEmailConfig(settings: EmailSettings): EmailConfig {
    return {
      provider: (settings.provider || "sendgrid") as "sendgrid" | "smtp" | "ses",
      sendgridApiKey: settings.smtpPasswordEncrypted || undefined, // for sendgrid provider, store API key in smtpPasswordEncrypted
      smtpHost: settings.smtpHost || undefined,
      smtpPort: settings.smtpPort || 587,
      smtpUser: settings.smtpUser || undefined,
      smtpPassword: settings.smtpPasswordEncrypted || undefined,
      smtpUseTls: settings.smtpUseTls ?? true,
      fromEmail: settings.fromEmail || "noreply@arus-marine.com",
      fromName: settings.fromName || "ARUS Marine",
    };
  }

  // ──────────────────────────────────────────────────────────────────
  // Vessel-level alert settings (unchanged — already in its own table)
  // ──────────────────────────────────────────────────────────────────

  async getVesselSettings(
    orgId: string,
    vesselId: string
  ): Promise<AlertSettingsVessel | null> {
    const settings = await alertSettingsRepository.getVesselSettings(
      orgId,
      vesselId
    );
    return settings || null;
  }

  async getAllVesselSettings(orgId: string): Promise<AlertSettingsVessel[]> {
    return alertSettingsRepository.getAllVesselSettings(orgId);
  }

  async updateVesselSettings(
    orgId: string,
    vesselId: string,
    data: Partial<InsertAlertSettingsVessel>
  ): Promise<AlertSettingsVessel> {
    const settings = await alertSettingsRepository.upsertVesselSettings(
      orgId,
      vesselId,
      data
    );
    log("info", "Vessel alert settings updated", { orgId, vesselId });
    return settings;
  }

  async deleteVesselSettings(orgId: string, vesselId: string): Promise<void> {
    await alertSettingsRepository.deleteVesselSettings(orgId, vesselId);
    log("info", "Vessel alert settings deleted", { orgId, vesselId });
  }

  // ──────────────────────────────────────────────────────────────────
  // Thresholds (unchanged)
  // ──────────────────────────────────────────────────────────────────

  async getThresholds(
    orgId: string,
    category?: string
  ): Promise<AlertThreshold[]> {
    return alertSettingsRepository.getThresholds(orgId, category);
  }

  async updateThreshold(
    orgId: string,
    key: string,
    data: Partial<InsertAlertThreshold>
  ): Promise<AlertThreshold> {
    const threshold = await alertSettingsRepository.upsertThreshold(
      orgId,
      key,
      data
    );
    log("info", "Alert threshold updated", { orgId, key });
    return threshold;
  }

  async deleteThreshold(orgId: string, key: string): Promise<void> {
    await alertSettingsRepository.deleteThreshold(orgId, key);
    log("info", "Alert threshold deleted", { orgId, key });
  }

  // ──────────────────────────────────────────────────────────────────
  // Email log queries (unchanged)
  // ──────────────────────────────────────────────────────────────────

  async getEmailLogs(
    orgId: string,
    options?: {
      vesselId?: string;
      alertType?: string;
      status?: string;
      limit?: number;
      offset?: number;
      startDate?: Date;
      endDate?: Date;
    }
  ): Promise<AlertEmailLog[]> {
    return alertSettingsRepository.getEmailLogs(orgId, options);
  }

  // ──────────────────────────────────────────────────────────────────
  // Crew alert settings (unchanged)
  // ──────────────────────────────────────────────────────────────────

  async getCrewAlertSettings(
    orgId: string,
    vesselId?: string
  ): Promise<CrewAlertSettings | null> {
    const settings = await alertSettingsRepository.getCrewAlertSettings(
      orgId,
      vesselId
    );
    return settings || null;
  }

  async getAllCrewAlertSettings(orgId: string): Promise<CrewAlertSettings[]> {
    return alertSettingsRepository.getAllCrewAlertSettings(orgId);
  }

  async updateCrewAlertSettings(
    orgId: string,
    vesselId: string | null,
    data: Partial<InsertCrewAlertSettings>
  ): Promise<CrewAlertSettings> {
    const settings = await alertSettingsRepository.upsertCrewAlertSettings(
      orgId,
      vesselId,
      data
    );
    log("info", "Crew alert settings updated", {
      orgId,
      vesselId: vesselId || "global",
    });
    return settings;
  }

  // ──────────────────────────────────────────────────────────────────
  // Cooldown / rate limiting
  // Reads `defaultCooldownMinutes` from alert_settings (routing side).
  // ──────────────────────────────────────────────────────────────────

  async shouldSendAlert(
    orgId: string,
    alertType: string,
    alertKey: string,
    vesselId?: string,
    entityId?: string
  ): Promise<{
    shouldSend: boolean;
    cooldownId?: string;
    minutesRemaining?: number;
  }> {
    const settings = await alertSettingsRepository.getOrgSettings(orgId);
    const cooldownMinutes = settings?.defaultCooldownMinutes ?? 30;

    const existing = await alertSettingsRepository.checkCooldown(
      orgId,
      alertType,
      alertKey,
      vesselId,
      entityId
    );

    if (!existing) {
      return { shouldSend: true };
    }

    const now = new Date();
    const lastAlert = new Date(existing.lastAlertAt);
    const elapsedMinutes = (now.getTime() - lastAlert.getTime()) / (1000 * 60);

    if (elapsedMinutes >= cooldownMinutes) {
      return { shouldSend: true, cooldownId: existing.id };
    }

    return {
      shouldSend: false,
      cooldownId: existing.id,
      minutesRemaining: Math.ceil(cooldownMinutes - elapsedMinutes),
    };
  }

  async recordAlertSent(
    orgId: string,
    alertType: string,
    alertKey: string,
    vesselId?: string,
    entityId?: string,
    emailSent: boolean = false
  ): Promise<void> {
    const cooldown = await alertSettingsRepository.upsertCooldown(
      orgId,
      alertType,
      alertKey,
      vesselId,
      entityId
    );

    if (emailSent) {
      await alertSettingsRepository.recordEmailSent(cooldown.id);
    }
  }

  async cleanupCooldowns(hoursOld: number = 24): Promise<number> {
    return alertSettingsRepository.cleanupExpiredCooldowns(hoursOld);
  }
}

export const alertSettingsService = new AlertSettingsService();
