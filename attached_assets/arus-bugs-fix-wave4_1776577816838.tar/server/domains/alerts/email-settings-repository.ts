/**
 * Email Settings Repository
 *
 * Data access for the `email_settings` table (Wave 4 Decision 1).
 * Holds per-org SMTP infrastructure config — separated from the
 * `alert_settings` table which holds routing/policy config.
 *
 * Place at: server/domains/alerts/email-settings-repository.ts
 */

import { eq } from "drizzle-orm";
import { db } from "../../db-config";
import {
  emailSettings,
  type EmailSettings,
  type InsertEmailSettings,
  type UpdateEmailSettings,
} from "@shared/schema-runtime";

export interface EmailTestResult {
  lastTestStatus: "success" | "failed";
  lastTestAt: Date;
  lastTestError?: string | null;
}

export class EmailSettingsRepository {
  /**
   * Fetch email settings for an org. Returns `undefined` if the org has
   * never configured email — caller should fall back to defaults.
   */
  async getOrgSettings(orgId: string): Promise<EmailSettings | undefined> {
    const [row] = await db
      .select()
      .from(emailSettings)
      .where(eq(emailSettings.orgId, orgId))
      .limit(1);
    return row;
  }

  /**
   * Upsert email settings for an org. The primary key is orgId, so this
   * functions as create-or-update on every call.
   *
   * The `data` parameter accepts a Partial<InsertEmailSettings> but the
   * `orgId` is required — either passed in `data` or as the first arg.
   */
  async upsertOrgSettings(
    orgId: string,
    data: Partial<InsertEmailSettings>
  ): Promise<EmailSettings> {
    const payload = { ...data, orgId } as InsertEmailSettings;

    const [row] = await db
      .insert(emailSettings)
      .values(payload)
      .onConflictDoUpdate({
        target: emailSettings.orgId,
        set: {
          ...data,
          updatedAt: new Date(),
        },
      })
      .returning();
    return row;
  }

  /**
   * Partial update — only writes the provided fields. Fails cleanly if
   * the row doesn't exist (caller should upsert instead if that's intended).
   */
  async updateOrgSettings(
    orgId: string,
    data: UpdateEmailSettings
  ): Promise<EmailSettings | undefined> {
    const [row] = await db
      .update(emailSettings)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(emailSettings.orgId, orgId))
      .returning();
    return row;
  }

  /**
   * Record SMTP connection test results. Separated from the main update
   * method so the main update endpoint's validator can exclude these
   * fields (they're written by a different endpoint).
   */
  async recordTestResult(
    orgId: string,
    result: EmailTestResult
  ): Promise<void> {
    await db
      .update(emailSettings)
      .set({
        lastTestStatus: result.lastTestStatus,
        lastTestAt: result.lastTestAt,
        lastTestError: result.lastTestError ?? null,
        updatedAt: new Date(),
      })
      .where(eq(emailSettings.orgId, orgId));
  }

  /**
   * Delete an org's email settings. Called when an org is deleted
   * (though the FK already has ON DELETE CASCADE, so this is rarely needed).
   */
  async deleteOrgSettings(orgId: string): Promise<void> {
    await db.delete(emailSettings).where(eq(emailSettings.orgId, orgId));
  }
}

export const emailSettingsRepository = new EmailSettingsRepository();
