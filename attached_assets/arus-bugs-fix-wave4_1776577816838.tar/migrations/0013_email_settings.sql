-- ============================================================================
-- Wave 4 Migration: Split email/SMTP config from notification routing
--
-- Creates email_settings table (SMTP infrastructure, per-org).
-- notification_settings remains unchanged (routing, per-org × notification_type).
--
-- Rationale: conflating SMTP config with routing creates a permissions and
-- cache-invalidation problem. Multi-tenant marine PdM with per-org SMTP
-- relays requires the split.
-- ============================================================================

CREATE TABLE IF NOT EXISTS email_settings (
  org_id VARCHAR PRIMARY KEY REFERENCES organizations(id) ON DELETE CASCADE,

  -- Provider identity
  provider TEXT,                         -- "smtp" | "sendgrid" | "ses" | "postmark"
  timezone TEXT,                         -- IANA timezone, e.g. "Asia/Brunei"

  -- SMTP connection
  smtp_host TEXT,
  smtp_port INTEGER,
  smtp_user TEXT,
  smtp_password_encrypted TEXT,
  smtp_use_tls BOOLEAN DEFAULT TRUE,

  -- Sender identity
  from_email TEXT,
  from_name TEXT,

  -- Default recipients
  default_to_email TEXT,
  cc_emails TEXT[],
  bcc_emails TEXT[],

  -- Test/diagnostic state
  last_test_status TEXT,                 -- "success" | "failed"
  last_test_at TIMESTAMP,
  last_test_error TEXT,

  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_settings_provider ON email_settings (provider);

-- ============================================================================
-- Optional: data migration from notification_settings
-- ============================================================================
-- If notification_settings previously had SMTP columns populated for some orgs,
-- copy those values into email_settings before dropping them.
--
-- IMPORTANT: check whether the current deployed notification_settings schema
-- actually has these columns. In the current shared/schema/admin.ts, the
-- notification_settings table does NOT have smtp_host/port/user/from_email/etc.
-- — the code was referencing columns that never existed in this deployment.
-- So the backfill below is a no-op for the current environment.
--
-- Left here as documentation for environments that may have drifted.
-- ============================================================================

-- DO $$
-- BEGIN
--   IF EXISTS (
--     SELECT 1 FROM information_schema.columns
--     WHERE table_name = 'notification_settings' AND column_name = 'smtp_host'
--   ) THEN
--     INSERT INTO email_settings (
--       org_id, provider, smtp_host, smtp_port, smtp_user,
--       smtp_use_tls, from_email, from_name,
--       default_to_email, timezone
--     )
--     SELECT
--       org_id, provider, smtp_host, smtp_port, smtp_user,
--       smtp_use_tls, from_email, from_name,
--       default_to_email, timezone
--     FROM notification_settings
--     WHERE smtp_host IS NOT NULL
--     ON CONFLICT (org_id) DO NOTHING;
--
--     -- Then drop the SMTP columns from notification_settings.
--     -- List each column explicitly rather than cascading.
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS smtp_host;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS smtp_port;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS smtp_user;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS smtp_password_encrypted;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS smtp_use_tls;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS from_email;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS from_name;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS default_to_email;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS cc_emails;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS bcc_emails;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS provider;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS timezone;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS last_test_status;
--     ALTER TABLE notification_settings DROP COLUMN IF EXISTS last_test_at;
--   END IF;
-- END $$;
