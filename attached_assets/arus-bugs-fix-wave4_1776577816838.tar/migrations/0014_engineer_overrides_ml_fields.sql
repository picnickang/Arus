-- ============================================================================
-- Wave 4 Migration: engineer_overrides — add ML-specific audit fields
--
-- Per Wave 4 Decision 2 (Option B continued): add the remaining ML-specific
-- columns that ml-governance-routes.ts references. Wave 2 added most of them;
-- these three are the leftover.
--
-- - engineer_id    — the engineer who authorized the override (distinct from
--                    generic createdBy audit field)
-- - engineer_name  — denormalized display name (avoids join-per-render)
-- - justification  — ML-specific rationale (distinct from generic reason)
--
-- Also relaxes `reason` from NOT NULL to nullable, since `justification` is
-- now the primary rationale field for ML overrides. Existing rows' `reason`
-- values are preserved.
-- ============================================================================

ALTER TABLE engineer_overrides
  ADD COLUMN IF NOT EXISTS engineer_id VARCHAR,
  ADD COLUMN IF NOT EXISTS engineer_name TEXT,
  ADD COLUMN IF NOT EXISTS justification TEXT;

-- Relax reason to nullable. Safe because:
--   1. Any existing value is preserved (no data loss)
--   2. New ML override rows will use `justification` instead
--   3. Non-ML override rows can still use `reason` as before
ALTER TABLE engineer_overrides
  ALTER COLUMN reason DROP NOT NULL;

-- Indexes to support common audit queries:
CREATE INDEX IF NOT EXISTS idx_engineer_overrides_engineer
  ON engineer_overrides (engineer_id);

CREATE INDEX IF NOT EXISTS idx_engineer_overrides_prediction
  ON engineer_overrides (prediction_id);

-- ============================================================================
-- Optional: backfill engineer_id from createdBy for existing ML overrides
-- ============================================================================
-- If you have existing engineer_overrides rows where the createdBy column
-- already holds the engineer's user ID (and not some other actor), uncomment
-- the backfill below. Inspect one row first to confirm the semantics before
-- running it on production data.
--
-- UPDATE engineer_overrides
-- SET engineer_id = created_by
-- WHERE engineer_id IS NULL
--   AND override_type = 'ml_prediction'
--   AND created_by IS NOT NULL;
--
-- Same for justification ← reason, if the existing data in `reason` is known
-- to be engineering rationale rather than a generic system note:
--
-- UPDATE engineer_overrides
-- SET justification = reason
-- WHERE justification IS NULL
--   AND override_type = 'ml_prediction'
--   AND reason IS NOT NULL;
-- ============================================================================
