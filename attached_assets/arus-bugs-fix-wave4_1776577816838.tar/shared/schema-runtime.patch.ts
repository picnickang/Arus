/**
 * ============================================================================
 * PATCH to shared/schema-runtime.ts
 * ============================================================================
 *
 * Add the new `emailSettings` table (Wave 4 Decision 1, Option A) as a
 * cloud-only export. SMTP configuration shouldn't sync to vessels —
 * vessel-side code should never call SMTP endpoints directly.
 *
 * TWO CHANGES NEEDED:
 * ============================================================================
 */

// ============================================================================
// CHANGE 1: Add the mode-aware table export
// ============================================================================
//
// In the "POSTGRESQL-ONLY TABLES" section of schema-runtime.ts (near the
// other cloud-only table exports like `softwarePatches`, `auditRuns`,
// `weatherCache`, etc.), ADD this line:

export const emailSettings = (IS_POSTGRES
  ? pgSchema.emailSettings
  : (undefined as any)) as typeof pgSchema.emailSettings;

// ============================================================================
// CHANGE 2: Add the Zod schema re-exports
// ============================================================================
//
// In the "ZOD SCHEMA EXPORTS" block near the bottom of schema-runtime.ts,
// where other insert schemas are re-exported from "./schema", add:

/*
  insertEmailSettingsSchema,
  updateEmailSettingsSchema,
  emailSettingsTestResultSchema,
*/

// These are already exported from shared/schema/email-settings.ts.
// You'll need to make sure shared/schema/index.ts (the barrel) re-exports
// from that new file:
//
//   export * from "./email-settings";
//
// Then the re-export block will work.

// ============================================================================
// CHANGE 3 (optional but recommended): Drift baseline
// ============================================================================
//
// If you maintain scripts/drift-baseline.json to track known divergences
// between PG and SQLite schemas, add `email_settings` to the cloud-only
// list so the drift validator doesn't flag it as missing from SQLite:
//
//   {
//     "cloud_only_tables": [
//       ...existing entries...
//       "email_settings"
//     ]
//   }
//
// No SQLite shadow table is needed — vessel-side code should never read
// or write to email_settings.
