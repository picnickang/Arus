/**
 * ============================================================================
 * Wave 4 — Engineer Overrides Schema Additions
 * ============================================================================
 *
 * Per Decision 2 (Option B continued): add the remaining ML-specific fields
 * that `ml-governance-routes.ts` references but aren't yet in the schema.
 *
 * Audit result (from decisions.md):
 *
 * Columns wave 2 added:
 *   predictionId, workOrderId, originalPrediction (jsonb NOT NULL),
 *   originalRiskLevel, originalConfidence, newRiskLevel, newScheduleDate,
 *   engineerCertifications (text[])
 *
 * Columns code references that are NOT yet in schema:
 *   - engineerId    — distinct from `createdBy` (audit field).
 *                     `engineerId` specifically = "which engineer authorized
 *                     this ML override". Kept separate for traceability.
 *   - engineerName  — denormalized display name (avoids a join to users
 *                     for every override list render).
 *   - justification — distinct from generic `reason`. The ML-specific
 *                     engineering rationale. `reason` was a generic field
 *                     shared across override types.
 *
 * Columns wave 2 kept as generic (unused but not removed):
 *   - originalValue (jsonb), overrideValue (jsonb), overrideType
 *   - These stay for future override types beyond ML predictions.
 *   - `reason` stays for backward compat with any non-ML override rows.
 *
 * APPLY:
 * 1. Merge the column additions below into shared/schema/telemetry.ts
 * 2. Run migrations/0014_engineer_overrides_ml_fields.sql
 * 3. Drift baseline — add the three columns to `scripts/drift-baseline.json`
 * ============================================================================
 */

// The engineer_overrides table currently lives in shared/schema/telemetry.ts.
// REPLACE the existing `engineerOverrides` definition with the block below.
// Changes vs current: add `engineerId`, `engineerName`, `justification`.
// Everything else is preserved — including the wave 2 ML columns and the
// original generic columns.

import {
  pgTable,
  varchar,
  text,
  boolean,
  timestamp,
  jsonb,
  real,
  index,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
// NOTE: `organizations`, `equipment`, `users` imports come from the
// surrounding module's existing imports. Do not duplicate them here.

export const engineerOverrides = pgTable(
  "engineer_overrides",
  {
    id: varchar("id")
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    orgId: varchar("org_id")
      .notNull()
      .references(() => organizations.id),
    equipmentId: varchar("equipment_id")
      .notNull()
      .references(() => equipment.id),

    // ========================================================================
    // Generic override pattern — kept for non-ML override types.
    // ========================================================================
    overrideType: text("override_type").notNull(),
    originalValue: jsonb("original_value"),
    overrideValue: jsonb("override_value"),
    reason: text("reason"), // WAS: `.notNull()` — relaxed because `justification`
    //                         is now the primary rationale field for ML
    //                         overrides. Keep nullable for backward compat;
    //                         a future cleanup can drop this column once no
    //                         non-ML overrides are active in production.

    // ========================================================================
    // ML-specific fields (added by wave 2)
    // ========================================================================
    predictionId: varchar("prediction_id"),
    workOrderId: varchar("work_order_id"),
    originalPrediction: jsonb("original_prediction"),
    originalRiskLevel: text("original_risk_level"),
    originalConfidence: real("original_confidence"),
    newRiskLevel: text("new_risk_level"),
    newScheduleDate: timestamp("new_schedule_date", { mode: "date" }),
    engineerCertifications: text("engineer_certifications").array(),

    // ========================================================================
    // ML-specific fields (NEW in wave 4)
    // ========================================================================
    engineerId: varchar("engineer_id"), // the engineer who authorized
    //                                     the override — FK not added yet
    //                                     because the existing data may
    //                                     have values pointing to users
    //                                     that have since been deleted.
    //                                     Add FK in a later migration after
    //                                     data cleanup.
    engineerName: text("engineer_name"), // denormalized for list render
    justification: text("justification"), // ML-specific rationale;
    //                                      distinct from generic `reason`

    // ========================================================================
    // Lifecycle / audit
    // ========================================================================
    expiresAt: timestamp("expires_at", { mode: "date" }),
    isActive: boolean("is_active").default(true),
    approvedBy: varchar("approved_by"),
    createdBy: varchar("created_by").notNull(),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
    updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    equipmentIdx: index("idx_engineer_overrides_equipment").on(table.equipmentId),
    activeIdx: index("idx_engineer_overrides_active").on(table.isActive),
    // NEW in wave 4: query by engineer for audit views
    engineerIdx: index("idx_engineer_overrides_engineer").on(table.engineerId),
    // NEW in wave 4: query by prediction for ML workflow
    predictionIdx: index("idx_engineer_overrides_prediction").on(table.predictionId),
  })
);

// Note: insertEngineerOverrideSchema and types should be regenerated
// automatically via createInsertSchema — no changes needed to the zod
// schema block below its table definition, but verify your omit() calls
// don't accidentally exclude the new fields.
