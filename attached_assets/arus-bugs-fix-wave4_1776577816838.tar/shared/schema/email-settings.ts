/**
 * ============================================================================
 * Email Settings - SMTP infrastructure config (per-org)
 * ============================================================================
 *
 * Per Wave 4 Decision 1 (Option A): split SMTP infrastructure from
 * notification routing. This table holds the per-org SMTP server config
 * and default sender/recipient policy. Notification routing rules
 * (who gets notified about which alert types) stays in notificationSettings.
 *
 * Place this file at: shared/schema/email-settings.ts
 * Re-export from shared/schema/index.ts (or wherever your barrel is):
 *   export * from "./email-settings";
 * ============================================================================
 */

import {
  pgTable,
  varchar,
  text,
  integer,
  boolean,
  timestamp,
  index,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
// NOTE: import `organizations` from the surrounding module's core/admin schema:
// import { organizations } from "./core";
// The concrete import path depends on your schema barrel layout. Adjust as needed.

/**
 * Email / SMTP infrastructure settings.
 * One row per organization. Holds the "how to send email" config
 * (SMTP server, credentials, from identity, default CC/BCC).
 *
 * Separated from `notification_settings` which holds "who gets notified
 * about what" (one row per org × notification type).
 */
export const emailSettings = pgTable(
  "email_settings",
  {
    orgId: varchar("org_id")
      .primaryKey()
      .references(() => organizations.id, { onDelete: "cascade" }),

    // Provider identity
    provider: text("provider"), // "smtp" | "sendgrid" | "ses" | "postmark" | custom label
    timezone: text("timezone"), // IANA TZ for digest scheduling, e.g. "Asia/Brunei"

    // SMTP connection
    smtpHost: text("smtp_host"),
    smtpPort: integer("smtp_port"),
    smtpUser: text("smtp_user"),
    smtpPasswordEncrypted: text("smtp_password_encrypted"),
    smtpUseTls: boolean("smtp_use_tls").default(true),

    // Sender identity
    fromEmail: text("from_email"),
    fromName: text("from_name"),

    // Default recipients — applied when a notification has no explicit target
    defaultToEmail: text("default_to_email"),
    ccEmails: text("cc_emails").array(),
    bccEmails: text("bcc_emails").array(),

    // Test/diagnostic state
    lastTestStatus: text("last_test_status"), // "success" | "failed" | null
    lastTestAt: timestamp("last_test_at", { mode: "date" }),
    lastTestError: text("last_test_error"),

    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
    updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    providerIdx: index("idx_email_settings_provider").on(table.provider),
  })
);

/**
 * Insert schema for validation.
 * Omits server-controlled fields (createdAt, updatedAt, test result fields).
 * Test-result fields are updated by a different endpoint, not by user input.
 */
export const insertEmailSettingsSchema = createInsertSchema(emailSettings, {
  smtpPort: z.number().int().min(1).max(65535).optional().nullable(),
  fromEmail: z.string().email().optional().nullable(),
  defaultToEmail: z.string().email().optional().nullable(),
  ccEmails: z.array(z.string().email()).optional().nullable(),
  bccEmails: z.array(z.string().email()).optional().nullable(),
  timezone: z.string().optional().nullable(),
  provider: z.enum(["smtp", "sendgrid", "ses", "postmark"]).optional().nullable(),
}).omit({
  createdAt: true,
  updatedAt: true,
  lastTestStatus: true,
  lastTestAt: true,
  lastTestError: true,
});

export type EmailSettings = typeof emailSettings.$inferSelect;
export type InsertEmailSettings = z.infer<typeof insertEmailSettingsSchema>;

/**
 * Update schema — separate from insert so orgId can't be changed.
 * orgId is the primary key and immutable.
 */
export const updateEmailSettingsSchema = insertEmailSettingsSchema.omit({ orgId: true }).partial();
export type UpdateEmailSettings = z.infer<typeof updateEmailSettingsSchema>;

/**
 * Test-result update schema — for the "test SMTP connection" endpoint.
 * Separated so the main update endpoint can't write to these fields directly.
 */
export const emailSettingsTestResultSchema = z.object({
  lastTestStatus: z.enum(["success", "failed"]),
  lastTestAt: z.date(),
  lastTestError: z.string().nullable().optional(),
});
export type EmailSettingsTestResult = z.infer<typeof emailSettingsTestResultSchema>;

// ============================================================================
// NOTE on shared/schema-runtime.ts
// ============================================================================
// Since this table is cloud-only (SMTP config doesn't sync to vessels),
// add the following to schema-runtime.ts:
//
//   export const emailSettings = (IS_POSTGRES ? pgSchema.emailSettings : undefined as any) as typeof pgSchema.emailSettings;
//
// And add the types to the re-export block:
//   insertEmailSettingsSchema,
//   updateEmailSettingsSchema,
//   emailSettingsTestResultSchema,
//   type EmailSettings, type InsertEmailSettings, type UpdateEmailSettings,
//
// NO SQLite shadow table needed — vessel-side code should never see this.
// Add "email_settings" to the drift baseline's known-cloud-only list.
// ============================================================================
