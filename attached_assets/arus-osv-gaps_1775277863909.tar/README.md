# ARUS — OSV-Specific Gap Fills

Transforms the platform from "generic maritime" to "offshore supply vessel AI analytics for Brunei O&G operations."

## What's Included

| Gap | Files | What It Does |
|-----|-------|-------------|
| DP Monitoring | `007-osv-specific.sql`, `dp/routes.ts` | DP system config, thruster/reference tracking, IMCA incident reporting, daily checks, fleet DP summary |
| Charter Compliance | `007-osv-specific.sql`, `charter/routes.ts` | Charter KPI tracking (availability, fuel, response time, DP uptime), performance dashboard, fleet overview |
| OVID/SIRE Vetting | `007-osv-specific.sql`, `vetting/routes.ts` | Inspection records, findings with remediation workflow, fleet vetting readiness score |
| Offshore Ops Logging | `007-osv-specific.sql`, `offshore-ops/routes.ts` | Cargo transfer, anchor handling, SPM, DP watchkeeping logs with weather, safety, client sign-off |
| EFMS Integration | `007-osv-specific.sql`, `efms/poller.ts` | Modbus TCP reader for fuel monitoring systems, feeds telemetry pipeline |
| OSV Roles | `osv-roles/definitions.ts` | Replaces generic roles with OSV personas: Chief Engineer, DPO, Deck Officer, Shore Superintendent |
| Vessel Extensions | `007-osv-specific.sql` | dp_class, vetting_status, charter_status on vessels; AMOD flag on certificates |

## Integration Steps

### 1. Run migration

```bash
psql $DATABASE_URL -f server/migrations/007-osv-specific.sql
```

### 2. Register all routes

```typescript
import { dpRouter } from "./domains/dp/routes.js";
import { charterRouter } from "./domains/charter/routes.js";
import { vettingRouter } from "./domains/vetting/routes.js";
import { offshoreOpsRouter } from "./domains/offshore-ops/routes.js";

app.use("/api/dp", dpRouter);
app.use("/api/charter", charterRouter);
app.use("/api/vetting", vettingRouter);
app.use("/api/offshore-ops", offshoreOpsRouter);
```

### 3. Start EFMS poller (on vessel server)

```typescript
import { efmsPollerService } from "./services/efms/poller.js";

// Wire EFMS readings to the telemetry pipeline
efmsPollerService.onReading((reading) => {
  telemetryBatchWriter.add({
    equipmentId: reading.equipmentId,
    vesselId: reading.vesselId,
    timestamp: reading.timestamp,
    data: reading.values,
    source: "efms",
  });
});

// Start all configured EFMS connections
await efmsPollerService.startAll(orgId);
```

### 4. Apply OSV role definitions

Patch `client/src/pages/home.tsx` ROLES constant with OSV_ROLES from
`osv-roles/definitions.ts`. Add the OSV_NAV_ITEMS to `navigationConfig.ts`.

### 5. Configure EFMS for a vessel

```bash
curl -X POST http://localhost:5000/api/sensors/calibration \
  -H "Content-Type: application/json" \
  -H "x-org-id: default-org-id" \
  -d '{
    "vesselId": "green-belait-id",
    "sensorTag": "ME-EFMS-001",
    "sensorType": "fuel_flow",
    "manufacturer": "Your EFMS manufacturer",
    "calibrationIntervalDays": 365,
    "measurementUnit": "l/h"
  }'
```

Then configure the EFMS connection via SQL or a future admin UI:

```sql
INSERT INTO efms_connections (org_id, vessel_id, equipment_id, protocol, host, port, slave_id, register_map, poll_interval_ms)
VALUES (
  'default-org-id',
  'green-belait-id',
  'main-engine-id',
  'modbus_tcp',
  '192.168.1.50',
  502,
  1,
  '{
    "fuel_flow_rate": {"register": 40001, "type": "float32", "unit": "l/h", "scaling": 1.0},
    "fuel_consumed":  {"register": 40003, "type": "float32", "unit": "litres", "scaling": 1.0},
    "engine_rpm":     {"register": 40009, "type": "uint16", "unit": "rpm", "scaling": 1.0}
  }',
  5000
);
```

## API Endpoints Summary

### DP System (12 endpoints)
- `GET/POST /api/dp/systems` — DP system configuration
- `GET/POST /api/dp/incidents` — DP incident reporting (IMCA format)
- `GET/POST /api/dp/daily-checks` — Pre-operations checklist
- `GET /api/dp/summary` — Fleet DP status dashboard

### Charter Compliance (6 endpoints)
- `GET/POST /api/charter` — Charter party CRUD
- `POST /api/charter/kpi` — Log daily/weekly KPI actuals
- `GET /api/charter/:id/performance` — Performance dashboard (actuals vs targets)
- `GET /api/charter/fleet-overview` — All active charters with compliance status

### Vetting (7 endpoints)
- `GET/POST /api/vetting` — Inspection CRUD
- `GET/POST /api/vetting/:id/findings` — Individual findings
- `PATCH /api/vetting/:id/findings/:fId/close` — Close finding with evidence
- `GET /api/vetting/fleet-readiness` — Fleet-wide vetting status

### Offshore Operations (4 endpoints)
- `GET/POST /api/offshore-ops` — Operation logs
- `PATCH /api/offshore-ops/:id/complete` — Complete an in-progress operation
- `GET /api/offshore-ops/summary` — Operations summary for charter reporting
