# ARUS Logistics UX Improvements + Bug Fixes

## What's Included

### New Components (drop into your project)

| # | File | What it does |
|---|------|--------------|
| 1 | `client/src/components/inventory/QuickReorderButton.tsx` | One-tap reorder from last PO for critical/low-stock parts |
| 2 | `client/src/components/inventory/InventoryBatchActions.tsx` | Floating action bar for multi-select: Create PR, Export CSV |
| 3 | `client/src/features/serviceOrders/pages/ServiceOrdersPage.tsx` | **Replacement** — adds Cards/Calendar toggle + supplier performance in filter dropdown |
| 4 | `client/src/features/purchaseRequests/components/PRStatusPipeline.tsx` | Visual pipeline: Draft→Sent→PO Issued→Received→Fulfilled→Closed |
| 5 | `client/src/components/work-orders/QuickServiceRequestDialog.tsx` | Simplified 4-field form with "Show advanced" toggle |
| 6 | `client/src/features/suppliers/components/SupplierPerformanceSelect.tsx` | Reusable dropdown showing ★rating, SLA hours, preferred badge |

### Bug Fixes (patch instructions in BUG-FIXES.ts)

| # | Severity | File | Bug |
|---|----------|------|-----|
| 1 | **Critical** | `server/services/telemetry-processing.ts` | `_error` declared but `error` referenced — ReferenceError at runtime |
| 2 | **Critical** | `server/sync-jobs/purchase-orders.ts` | Same `_error`/`error` typo |
| 3 | **High** | `server/service-orders/repository.ts` | `generateSoNumber` uses MAX(SUBSTRING) not a real sequence — race condition |
| 4 | **High** | `server/sync-jobs/purchase-orders.ts` | Missing orgId filter on reservations/purchaseOrders join — cross-tenant leak |

## Integration Guide

### 1. QuickReorderButton — wire into VirtualizedInventoryTable

In your inventory table's action column, add the reorder button for low/critical stock rows:

```tsx
import { QuickReorderButton } from "@/components/inventory/QuickReorderButton";

// In your row action column:
{getStockStatus(part) === "critical" || getStockStatus(part) === "low_stock" ? (
  <QuickReorderButton part={part} variant="icon" />
) : null}
```

### 2. InventoryBatchActions — wire into inventory-management.tsx

Add selection state and render the batch bar:

```tsx
import { InventoryBatchActions } from "@/components/inventory/InventoryBatchActions";

// In InventoryManagement component, add state:
const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());

// Pass to VirtualizedInventoryTable:
<VirtualizedInventoryTable
  items={filteredParts}
  selectedItems={selectedItems}
  onSelectionChange={setSelectedItems}
  // ... existing props
/>

// After the table card, before drawers:
<InventoryBatchActions
  selectedItems={selectedItems}
  parts={filteredParts}
  onClearSelection={() => setSelectedItems(new Set())}
/>
```

### 3. ServiceOrdersPage — drop-in replacement

This file replaces `client/src/features/serviceOrders/pages/ServiceOrdersPage.tsx`.
It imports `ServiceOrderCalendar` which is already in your codebase at
`client/src/features/serviceOrders/components/ServiceOrderCalendar.tsx`.

No wiring needed — just replace the file.

### 4. PRStatusPipeline — add to PR detail page header

```tsx
import { PRStatusPipeline } from "@/features/purchaseRequests/components/PRStatusPipeline";

// In your PR detail page, above the content:
<PRStatusPipeline
  status={purchaseRequest.status}
  events={prEvents}
  linkedPO={linkedPO}
  sentAt={purchaseRequest.sentAt}
  closedAt={purchaseRequest.closedAt}
  className="mb-6"
/>
```

### 5. QuickServiceRequestDialog — use in WorkOrderRequestsTab

Replace the `EnhancedServiceRequestDialog` import for new service orders
(keep the enhanced dialog for editing):

```tsx
import { QuickServiceRequestDialog } from "@/components/work-orders/QuickServiceRequestDialog";

// In WorkOrderRequestsTab, replace the create dialog:
<QuickServiceRequestDialog
  open={soDialogOpen && !editingSO}
  onOpenChange={handleSoDialogClose}
  onSubmit={handleCreateServiceOrder}
  isPending={isCreatingServiceOrder}
  workOrderId={workOrderId}
/>

// Keep EnhancedServiceRequestDialog for editing existing SOs:
{editingSO && (
  <EnhancedServiceRequestDialog
    open={soDialogOpen && !!editingSO}
    onOpenChange={handleSoDialogClose}
    onSubmit={handleCreateServiceOrder}
    isPending={isUpdatingServiceOrder}
    initialData={...}
    isEditing
  />
)}
```

### 6. SupplierPerformanceSelect — replace plain Select components

Anywhere you have a supplier dropdown, swap it:

```tsx
// Before:
<Select value={providerId} onValueChange={setProviderId}>
  <SelectTrigger><SelectValue placeholder="Select provider" /></SelectTrigger>
  <SelectContent>
    {suppliers?.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
  </SelectContent>
</Select>

// After:
import { SupplierPerformanceSelect } from "@/features/suppliers/components/SupplierPerformanceSelect";

<SupplierPerformanceSelect
  value={providerId}
  onValueChange={setProviderId}
  filterType="service_provider"
  data-testid="select-provider"
/>
```

Add the export to `client/src/features/suppliers/index.ts`:
```tsx
export * from "./components/SupplierPerformanceSelect";
```

## Bug Fix Application

See `BUG-FIXES.ts` for exact find/replace patches. Priority order:

1. Fix `_error`/`error` typos (both files) — prevents runtime crashes
2. Add orgId to sync-jobs join — prevents cross-tenant data leak
3. Replace SO number generation with PostgreSQL sequence — prevents duplicate SO numbers

For bug #3 (SO number sequence), run this migration:
```sql
CREATE SEQUENCE IF NOT EXISTS so_number_seq START 1;
```

Then replace `generateSoNumber` in `server/service-orders/repository.ts`:
```typescript
export async function generateSoNumber(_orgId: string): Promise<string> {
  const result = await db.execute(
    sql`SELECT nextval('so_number_seq') as next_val`
  );
  const nextNum = Number((result as any).rows?.[0]?.next_val ?? 1);
  return `SO-${String(nextNum).padStart(3, "0")}`;
}
```
