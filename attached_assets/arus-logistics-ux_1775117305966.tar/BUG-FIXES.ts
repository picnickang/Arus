/**
 * Bug Fixes — Logistics Domain
 *
 * Apply these patches to the existing files.
 */

// ============================================================================
// BUG FIX 1: server/services/telemetry-processing.ts
// ============================================================================
// The catch block declares `_error` but references `error` (undeclared).
// This will throw a ReferenceError at runtime.
//
// FIND (in applySensorConfiguration, around the catch block):
//   } catch (_error) {
//     console.error(`Failed to apply sensor configuration for ${equipmentId}/${sensorType}:`, error);
//
// REPLACE WITH:
//   } catch (_error) {
//     console.error(`Failed to apply sensor configuration for ${equipmentId}/${sensorType}:`, _error);


// ============================================================================
// BUG FIX 2: server/sync-jobs/purchase-orders.ts
// ============================================================================
// Same bug: catch declares `_error` but body references `error`.
//
// FIND (in checkWorkOrdersPendingOnPO, around the catch block):
//   } catch (_error) {
//     console.error("Work orders pending on PO check failed:", error);
//     ...
//     message: `Failed to check work order PO dependencies: ${error instanceof Error ? error.message : "Unknown error"}`,
//
// REPLACE WITH:
//   } catch (_error) {
//     console.error("Work orders pending on PO check failed:", _error);
//     ...
//     message: `Failed to check work order PO dependencies: ${_error instanceof Error ? _error.message : "Unknown error"}`,


// ============================================================================
// BUG FIX 3: server/service-orders/repository.ts — SO number race condition
// ============================================================================
// generateSoNumber uses MAX(SUBSTRING(...)) which is not concurrency-safe.
// Two concurrent requests can get the same SO number.
//
// Option A (recommended): Create a PostgreSQL sequence and use it:
//
//   -- Run once as a migration:
//   CREATE SEQUENCE IF NOT EXISTS so_number_seq START 1;
//
//   -- Then in repository.ts:
//   export async function generateSoNumber(orgId: string): Promise<string> {
//     const result = await db.execute(
//       sql`SELECT nextval('so_number_seq') as next_val`
//     );
//     const nextNum = Number(result.rows?.[0]?.next_val ?? 1);
//     return `SO-${String(nextNum).padStart(3, "0")}`;
//   }
//
// Option B (if you can't run a migration): Use INSERT ... RETURNING with
// a retry loop on unique constraint violation. Less clean but no migration needed.


// ============================================================================
// BUG FIX 4: server/sync-jobs/purchase-orders.ts — Missing org filter in join
// ============================================================================
// The join doesn't filter by orgId on reservations or purchaseOrders,
// causing potential cross-tenant data leakage.
//
// FIND (in checkWorkOrdersPendingOnPO):
//   .where(
//     and(
//       eq(parts.orgId, orgId),
//       eq(reservations.status, "active"),
//       sql`${purchaseOrders.status} IN ('draft', 'sent', 'acknowledged', 'shipped')`
//     )
//   );
//
// REPLACE WITH:
//   .where(
//     and(
//       eq(parts.orgId, orgId),
//       eq(reservations.orgId, orgId),
//       eq(purchaseOrders.orgId, orgId),
//       eq(reservations.status, "active"),
//       sql`${purchaseOrders.status} IN ('draft', 'sent', 'acknowledged', 'shipped')`
//     )
//   );

export {};
