/**
 * Cost-Savings Engine — Enhanced Reporting
 *
 * TASK #56: Savings Claim Integrity
 *
 * Changes from existing reporting.ts:
 *   1. getSavingsSummary only counts 'valid' records in totals
 *   2. Returns disputed/voided counts and amounts separately
 *   3. Returns aggregate confidence range (low/high)
 *   4. getMonthlySavingsTrend includes confidence bands
 *   5. New getEquipmentSavingsRanked endpoint for superintendent view
 *
 * EXTENDS existing reporting — import these functions alongside originals.
 */

import { db } from "../../db-config.js";
import { sql } from "drizzle-orm";

// ─── Types ──────────────────────────────────────────────────────────────────

export interface EnhancedSavingsSummary {
  // Valid totals only
  totalSavings: number;
  totalSavingsLow: number;
  totalSavingsHigh: number;
  totalAvoidedCost: number;
  totalActualCost: number;
  validCount: number;

  // Breakdown
  laborSavings: number;
  partsSavings: number;
  downtimeSavings: number;

  // By maintenance type
  predictiveSavings: number;
  preventiveSavings: number;

  // Integrity metrics
  estimatedCount: number;
  disputedCount: number;
  voidedCount: number;
  disputedAmount: number;
  voidedAmount: number;

  // Confidence
  avgConfidence: number;
  dataSourceBreakdown: {
    measured: number;
    estimated: number;
    mixed: number;
  };

  // Currency
  currency: string;
}

export interface MonthlyTrendPoint {
  month: string;
  totalSavings: number;
  savingsLow: number;
  savingsHigh: number;
  count: number;
  avgConfidence: number;
  predictiveSavings: number;
  preventiveSavings: number;
}

export interface EquipmentSavingsRanking {
  equipmentId: string;
  equipmentName: string;
  vesselName: string;
  totalSavings: number;
  savingsLow: number;
  savingsHigh: number;
  workOrderCount: number;
  avgConfidence: number;
  latestMaintenanceType: string;
}

// ─── Enhanced Summary ───────────────────────────────────────────────────────

export async function getEnhancedSavingsSummary(
  orgId: string,
  dateFrom?: string,
  dateTo?: string,
): Promise<EnhancedSavingsSummary> {
  const dateFilter = dateFrom && dateTo
    ? sql`AND cs.calculated_at BETWEEN ${dateFrom}::timestamp AND ${dateTo}::timestamp`
    : dateFrom
      ? sql`AND cs.calculated_at >= ${dateFrom}::timestamp`
      : sql``;

  const [result] = await db.execute(sql`
    SELECT
      -- Valid totals
      COALESCE(SUM(total_savings) FILTER (WHERE validation_status = 'valid'), 0) AS total_savings,
      COALESCE(SUM(confidence_low) FILTER (WHERE validation_status = 'valid'), 0) AS total_savings_low,
      COALESCE(SUM(confidence_high) FILTER (WHERE validation_status = 'valid'), 0) AS total_savings_high,
      COALESCE(SUM(avoided_cost) FILTER (WHERE validation_status = 'valid'), 0) AS total_avoided_cost,
      COALESCE(SUM(actual_cost) FILTER (WHERE validation_status = 'valid'), 0) AS total_actual_cost,
      COUNT(*) FILTER (WHERE validation_status = 'valid') AS valid_count,

      -- Breakdown
      COALESCE(SUM(labor_savings) FILTER (WHERE validation_status = 'valid'), 0) AS labor_savings,
      COALESCE(SUM(parts_savings) FILTER (WHERE validation_status = 'valid'), 0) AS parts_savings,
      COALESCE(SUM(downtime_savings) FILTER (WHERE validation_status = 'valid'), 0) AS downtime_savings,

      -- By type
      COALESCE(SUM(total_savings) FILTER (WHERE validation_status = 'valid' AND maintenance_type = 'predictive'), 0) AS predictive_savings,
      COALESCE(SUM(total_savings) FILTER (WHERE validation_status = 'valid' AND maintenance_type = 'preventive'), 0) AS preventive_savings,

      -- Integrity
      COUNT(*) FILTER (WHERE validation_status = 'estimated') AS estimated_count,
      COUNT(*) FILTER (WHERE validation_status = 'disputed') AS disputed_count,
      COUNT(*) FILTER (WHERE validation_status = 'voided') AS voided_count,
      COALESCE(SUM(total_savings) FILTER (WHERE validation_status = 'disputed'), 0) AS disputed_amount,
      COALESCE(SUM(total_savings) FILTER (WHERE validation_status = 'voided'), 0) AS voided_amount,

      -- Confidence
      COALESCE(AVG(confidence_score) FILTER (WHERE validation_status = 'valid'), 0) AS avg_confidence,

      -- Data source breakdown
      COUNT(*) FILTER (WHERE validation_status = 'valid' AND data_source = 'measured') AS measured_count,
      COUNT(*) FILTER (WHERE validation_status = 'valid' AND data_source = 'estimated') AS estimated_source_count,
      COUNT(*) FILTER (WHERE validation_status = 'valid' AND data_source = 'mixed') AS mixed_count

    FROM cost_savings cs
    WHERE cs.org_id = ${orgId}
    ${dateFilter}
  `).then((r) => r.rows || r);

  return {
    totalSavings: Number(result.total_savings) || 0,
    totalSavingsLow: Number(result.total_savings_low) || 0,
    totalSavingsHigh: Number(result.total_savings_high) || 0,
    totalAvoidedCost: Number(result.total_avoided_cost) || 0,
    totalActualCost: Number(result.total_actual_cost) || 0,
    validCount: Number(result.valid_count) || 0,
    laborSavings: Number(result.labor_savings) || 0,
    partsSavings: Number(result.parts_savings) || 0,
    downtimeSavings: Number(result.downtime_savings) || 0,
    predictiveSavings: Number(result.predictive_savings) || 0,
    preventiveSavings: Number(result.preventive_savings) || 0,
    estimatedCount: Number(result.estimated_count) || 0,
    disputedCount: Number(result.disputed_count) || 0,
    voidedCount: Number(result.voided_count) || 0,
    disputedAmount: Number(result.disputed_amount) || 0,
    voidedAmount: Number(result.voided_amount) || 0,
    avgConfidence: Number(result.avg_confidence) || 0,
    dataSourceBreakdown: {
      measured: Number(result.measured_count) || 0,
      estimated: Number(result.estimated_source_count) || 0,
      mixed: Number(result.mixed_count) || 0,
    },
    currency: "BND",
  };
}

// ─── Monthly Trend with Confidence Bands ────────────────────────────────────

export async function getEnhancedMonthlySavingsTrend(
  orgId: string,
  months: number = 12,
): Promise<MonthlyTrendPoint[]> {
  const rows = await db.execute(sql`
    SELECT
      TO_CHAR(calculated_at, 'YYYY-MM') AS month,
      COALESCE(SUM(total_savings) FILTER (WHERE validation_status = 'valid'), 0) AS total_savings,
      COALESCE(SUM(confidence_low) FILTER (WHERE validation_status = 'valid'), 0) AS savings_low,
      COALESCE(SUM(confidence_high) FILTER (WHERE validation_status = 'valid'), 0) AS savings_high,
      COUNT(*) FILTER (WHERE validation_status = 'valid') AS count,
      COALESCE(AVG(confidence_score) FILTER (WHERE validation_status = 'valid'), 0) AS avg_confidence,
      COALESCE(SUM(total_savings) FILTER (WHERE validation_status = 'valid' AND maintenance_type = 'predictive'), 0) AS predictive_savings,
      COALESCE(SUM(total_savings) FILTER (WHERE validation_status = 'valid' AND maintenance_type = 'preventive'), 0) AS preventive_savings
    FROM cost_savings
    WHERE org_id = ${orgId}
      AND calculated_at >= NOW() - (${months} || ' months')::interval
    GROUP BY TO_CHAR(calculated_at, 'YYYY-MM')
    ORDER BY month ASC
  `).then((r) => r.rows || r);

  return (rows as any[]).map((r) => ({
    month: r.month,
    totalSavings: Number(r.total_savings) || 0,
    savingsLow: Number(r.savings_low) || 0,
    savingsHigh: Number(r.savings_high) || 0,
    count: Number(r.count) || 0,
    avgConfidence: Number(r.avg_confidence) || 0,
    predictiveSavings: Number(r.predictive_savings) || 0,
    preventiveSavings: Number(r.preventive_savings) || 0,
  }));
}

// ─── Equipment Savings Ranking (Task #55 cross-cutting: superintendent view) ─

export async function getEquipmentSavingsRanked(
  orgId: string,
  limit: number = 20,
): Promise<EquipmentSavingsRanking[]> {
  const rows = await db.execute(sql`
    SELECT
      cs.equipment_id,
      eq.name AS equipment_name,
      v.name AS vessel_name,
      SUM(cs.total_savings) AS total_savings,
      SUM(cs.confidence_low) AS savings_low,
      SUM(cs.confidence_high) AS savings_high,
      COUNT(cs.id) AS work_order_count,
      AVG(cs.confidence_score) AS avg_confidence,
      (ARRAY_AGG(cs.maintenance_type ORDER BY cs.calculated_at DESC))[1] AS latest_maintenance_type
    FROM cost_savings cs
    LEFT JOIN equipment eq ON eq.id = cs.equipment_id
    LEFT JOIN vessels v ON v.id = cs.vessel_id
    WHERE cs.org_id = ${orgId}
      AND cs.validation_status = 'valid'
    GROUP BY cs.equipment_id, eq.name, v.name
    ORDER BY SUM(cs.total_savings) DESC
    LIMIT ${limit}
  `).then((r) => r.rows || r);

  return (rows as any[]).map((r) => ({
    equipmentId: r.equipment_id,
    equipmentName: r.equipment_name || r.equipment_id,
    vesselName: r.vessel_name || "",
    totalSavings: Number(r.total_savings) || 0,
    savingsLow: Number(r.savings_low) || 0,
    savingsHigh: Number(r.savings_high) || 0,
    workOrderCount: Number(r.work_order_count) || 0,
    avgConfidence: Number(r.avg_confidence) || 0,
    latestMaintenanceType: r.latest_maintenance_type || "preventive",
  }));
}
