/**
 * Cost-Savings Engine — Enhanced Calculator
 *
 * TASK #56: Savings Claim Integrity
 *
 * Changes from existing calculator.ts:
 *   1. Savings records created with validation_status='estimated' (not 'valid')
 *   2. Confidence ranges derived from prediction confidence
 *   3. data_source field tracks whether costs are measured or estimated
 *   4. Auto-void when WO is cancelled
 *   5. Downtime cost resolution: equipment multiplier × vessel rate → global default
 *
 * TASK #54: Cost Flow Integration (cross-cutting)
 *   6. Reads from work_order_cost_breakdown view for unified totals
 *   7. Equipment-level downtime criticality multiplier
 *   8. Vessel-level charter rate for downtime cost
 *
 * This file EXTENDS the existing calculator — import and use
 * `calculateWorkOrderSavingsEnhanced` instead of `calculateWorkOrderSavings`.
 */

import { db } from "../../db-config.js";
import { eq, sql, and } from "drizzle-orm";
import { logger } from "../../utils/logger.js";

// ─── Types ──────────────────────────────────────────────────────────────────

export interface EnhancedSavingsInput {
  workOrderId: string;
  orgId: string;
  // Optional overrides (fall back to DB lookups)
  laborRatePerHour?: number;
  downtimeCostPerHour?: number;
  emergencyLaborMultiplier?: number;
  emergencyPartsMultiplier?: number;
  emergencyDowntimeMultiplier?: number;
}

export interface EnhancedSavingsResult {
  // Core savings
  actualCost: number;
  avoidedCost: number;
  totalSavings: number;
  laborSavings: number;
  partsSavings: number;
  downtimeSavings: number;

  // Confidence ranges
  confidenceScore: number;
  confidenceLow: number;
  confidenceHigh: number;

  // Metadata
  maintenanceType: "preventive" | "predictive" | "corrective" | "emergency";
  validationStatus: "estimated";
  dataSource: "measured" | "estimated" | "mixed";
  currency: string;

  // Assumptions (visible to user)
  assumptions: {
    laborMultiplier: number;
    partsMultiplier: number;
    downtimeMultiplier: number;
    downtimeCostPerHour: number;
    downtimeCostSource: "vessel_charter" | "equipment_override" | "global_default";
    costDataSource: string;
    predictionConfidence: number | null;
  };

  // Traceability
  equipmentId: string | null;
  vesselId: string | null;
  predictionId: string | null;
  estimatedDowntimePrevented: number;
}

interface CostBreakdown {
  internalLaborCost: number;
  internalPartsCost: number;
  externalServiceCost: number;
  externalPartsCost: number;
  totalProcurementCost: number;
  computedTotalCost: number;
  currencyStatus: string;
  costDataSource: string;
}

interface DowntimeResolution {
  costPerHour: number;
  source: "vessel_charter" | "equipment_override" | "global_default";
}

// ─── Downtime Cost Resolution ───────────────────────────────────────────────

/**
 * Resolves downtime cost per hour using the precedence:
 *   1. Function argument override
 *   2. Equipment.downtimeCriticalityMultiplier × Vessel.downtimeCostPerHour
 *   3. Vessel.downtimeCostPerHour (derived from charter rate)
 *   4. Global cost_model.downtime_per_hour
 */
async function resolveDowntimeCost(
  orgId: string,
  equipmentId: string | null,
  vesselId: string | null,
  override?: number,
): Promise<DowntimeResolution> {
  if (override) {
    return { costPerHour: override, source: "equipment_override" };
  }

  // Try vessel charter rate
  if (vesselId) {
    const [vessel] = await db.execute(sql`
      SELECT
        downtime_cost_per_hour,
        charter_day_rate
      FROM vessels
      WHERE id = ${vesselId} AND org_id = ${orgId}
    `).then((r) => r.rows || r);

    if (vessel) {
      const vesselRate = vessel.downtime_cost_per_hour
        || (vessel.charter_day_rate ? vessel.charter_day_rate / 24 : null);

      if (vesselRate) {
        // Apply equipment criticality multiplier if available
        if (equipmentId) {
          const [eq] = await db.execute(sql`
            SELECT downtime_criticality_multiplier
            FROM equipment
            WHERE id = ${equipmentId} AND org_id = ${orgId}
          `).then((r) => r.rows || r);

          const multiplier = eq?.downtime_criticality_multiplier ?? 1.0;
          return {
            costPerHour: vesselRate * multiplier,
            source: "vessel_charter",
          };
        }

        return { costPerHour: vesselRate, source: "vessel_charter" };
      }
    }
  }

  // Fall back to global cost model
  const [costModel] = await db.execute(sql`
    SELECT downtime_per_hour
    FROM cost_model
    WHERE org_id = ${orgId}
    LIMIT 1
  `).then((r) => r.rows || r);

  return {
    costPerHour: costModel?.downtime_per_hour ?? 500, // absolute last fallback
    source: "global_default",
  };
}

// ─── Unified Cost Breakdown ─────────────────────────────────────────────────

/**
 * Gets the unified cost breakdown from the work_order_cost_breakdown view.
 * This includes internal labor, internal parts, external service, and external parts.
 * Falls back to WO summary fields if the view isn't populated.
 */
async function getUnifiedCostBreakdown(workOrderId: string): Promise<CostBreakdown> {
  const [breakdown] = await db.execute(sql`
    SELECT
      internal_labor_cost,
      internal_parts_cost,
      external_service_cost,
      external_parts_cost,
      total_procurement_cost,
      computed_total_cost,
      currency_status,
      cost_data_source
    FROM work_order_cost_breakdown
    WHERE work_order_id = ${workOrderId}
  `).then((r) => r.rows || r);

  if (breakdown && breakdown.computed_total_cost > 0) {
    return {
      internalLaborCost: Number(breakdown.internal_labor_cost) || 0,
      internalPartsCost: Number(breakdown.internal_parts_cost) || 0,
      externalServiceCost: Number(breakdown.external_service_cost) || 0,
      externalPartsCost: Number(breakdown.external_parts_cost) || 0,
      totalProcurementCost: Number(breakdown.total_procurement_cost) || 0,
      computedTotalCost: Number(breakdown.computed_total_cost) || 0,
      currencyStatus: breakdown.currency_status || "ok",
      costDataSource: breakdown.cost_data_source || "estimated",
    };
  }

  // Fallback: read WO summary fields directly (SHIPMATE import path)
  const [wo] = await db.execute(sql`
    SELECT
      total_labor_cost,
      total_parts_cost,
      total_cost,
      total_procurement_cost,
      cost_data_source
    FROM work_orders
    WHERE id = ${workOrderId}
  `).then((r) => r.rows || r);

  return {
    internalLaborCost: Number(wo?.total_labor_cost) || 0,
    internalPartsCost: Number(wo?.total_parts_cost) || 0,
    externalServiceCost: 0,
    externalPartsCost: 0,
    totalProcurementCost: Number(wo?.total_procurement_cost) || 0,
    computedTotalCost: Number(wo?.total_cost) || 0,
    currencyStatus: "ok",
    costDataSource: wo?.cost_data_source || "estimated",
  };
}

// ─── Enhanced Savings Calculator ────────────────────────────────────────────

export async function calculateWorkOrderSavingsEnhanced(
  input: EnhancedSavingsInput,
): Promise<EnhancedSavingsResult | null> {
  const { workOrderId, orgId } = input;

  // 1. Fetch work order with prediction link
  const [wo] = await db.execute(sql`
    SELECT
      id, equipment_id, vessel_id, prediction_id,
      maintenance_type, status,
      estimated_downtime_hours, actual_downtime_hours,
      downtime_cost_per_hour,
      estimated_failure_cost, estimated_repair_cost,
      cost_data_source
    FROM work_orders
    WHERE id = ${workOrderId} AND org_id = ${orgId}
  `).then((r) => r.rows || r);

  if (!wo) {
    logger.warn(`[savings] Work order ${workOrderId} not found`);
    return null;
  }

  // 2. Determine maintenance type
  const maintenanceType = wo.maintenance_type || "preventive";

  // Corrective and emergency WOs don't claim avoided-failure savings
  if (maintenanceType === "corrective" || maintenanceType === "emergency") {
    logger.info(`[savings] Skipping ${maintenanceType} WO ${workOrderId} — no counterfactual savings`);
    return null;
  }

  // 3. Get prediction confidence (if triggered by AI)
  let predictionConfidence: number | null = null;
  if (wo.prediction_id) {
    const [pred] = await db.execute(sql`
      SELECT probability, confidence, cost_impact
      FROM failure_predictions
      WHERE id = ${wo.prediction_id}
    `).then((r) => r.rows || r);

    predictionConfidence = pred?.confidence ?? pred?.probability ?? null;
  }

  // 4. Resolve multipliers: function args → equipment-level → org-level → defaults
  let laborMult = input.emergencyLaborMultiplier ?? 3.0;
  let partsMult = input.emergencyPartsMultiplier ?? 1.5;
  let downtimeMult = input.emergencyDowntimeMultiplier ?? 3.0;

  if (wo.equipment_id && !input.emergencyLaborMultiplier) {
    const [eq] = await db.execute(sql`
      SELECT
        emergency_labor_multiplier,
        emergency_parts_multiplier,
        emergency_downtime_multiplier
      FROM equipment
      WHERE id = ${wo.equipment_id} AND org_id = ${orgId}
    `).then((r) => r.rows || r);

    if (eq) {
      laborMult = eq.emergency_labor_multiplier ?? laborMult;
      partsMult = eq.emergency_parts_multiplier ?? partsMult;
      downtimeMult = eq.emergency_downtime_multiplier ?? downtimeMult;
    }
  }

  // 5. Get unified cost breakdown (includes procurement costs)
  const costs = await getUnifiedCostBreakdown(workOrderId);
  const totalLaborCost = costs.internalLaborCost;
  const totalPartsCost = costs.internalPartsCost + costs.totalProcurementCost;
  const actualCost = costs.computedTotalCost;

  // 6. Resolve downtime cost
  const downtime = await resolveDowntimeCost(
    orgId,
    wo.equipment_id,
    wo.vessel_id,
    input.downtimeCostPerHour || wo.downtime_cost_per_hour,
  );
  const downtimeHours = wo.actual_downtime_hours || wo.estimated_downtime_hours || 0;

  // 7. Calculate avoided costs (counterfactual: what if this was an emergency?)
  const avoidedLaborCost = totalLaborCost * laborMult;
  const avoidedPartsCost = totalPartsCost * partsMult;
  const avoidedDowntimeCost = downtimeHours * downtime.costPerHour * downtimeMult;
  const avoidedCost = avoidedLaborCost + avoidedPartsCost + avoidedDowntimeCost;

  // 8. Calculate savings
  const laborSavings = avoidedLaborCost - totalLaborCost;
  const partsSavings = avoidedPartsCost - totalPartsCost;
  const downtimeSavings = avoidedDowntimeCost - (downtimeHours * downtime.costPerHour);
  const totalSavings = avoidedCost - actualCost;

  // 9. Calculate confidence ranges
  //    Higher prediction confidence → tighter range
  //    Lower confidence or no prediction → wider range
  const confidenceScore = predictionConfidence ?? 0.7; // 0.7 default for non-AI WOs
  const rangeFactor = (1 - confidenceScore) * 1.5; // e.g., 0.85 confidence → ±22.5% range
  const confidenceLow = Math.max(0, totalSavings * (1 - rangeFactor));
  const confidenceHigh = totalSavings * (1 + rangeFactor);

  // 10. Determine data source
  const dataSource = costs.costDataSource === "shipmate_import"
    ? "measured" as const
    : costs.totalProcurementCost > 0
      ? "mixed" as const
      : "estimated" as const;

  // 11. Get currency from vessel or org
  const [vessel] = wo.vessel_id
    ? await db.execute(sql`
        SELECT charter_currency FROM vessels WHERE id = ${wo.vessel_id}
      `).then((r) => r.rows || r)
    : [null];

  const currency = vessel?.charter_currency || "BND";

  return {
    actualCost,
    avoidedCost,
    totalSavings,
    laborSavings,
    partsSavings,
    downtimeSavings,
    confidenceScore,
    confidenceLow,
    confidenceHigh,
    maintenanceType: maintenanceType as any,
    validationStatus: "estimated",
    dataSource,
    currency,
    assumptions: {
      laborMultiplier: laborMult,
      partsMultiplier: partsMult,
      downtimeMultiplier: downtimeMult,
      downtimeCostPerHour: downtime.costPerHour,
      downtimeCostSource: downtime.source,
      costDataSource: costs.costDataSource,
      predictionConfidence,
    },
    equipmentId: wo.equipment_id,
    vesselId: wo.vessel_id,
    predictionId: wo.prediction_id,
    estimatedDowntimePrevented: downtimeHours,
  };
}

// ─── Persist Enhanced Savings ───────────────────────────────────────────────

export async function persistEnhancedSavings(
  result: EnhancedSavingsResult,
  workOrderId: string,
  orgId: string,
): Promise<string> {
  const [row] = await db.execute(sql`
    INSERT INTO cost_savings (
      id, org_id, work_order_id, equipment_id, vessel_id, prediction_id,
      maintenance_type,
      actual_cost, avoided_cost, total_savings,
      labor_savings, parts_savings, downtime_savings,
      estimated_downtime_prevented, downtime_cost_per_hour,
      confidence_score, confidence_low, confidence_high,
      emergency_labor_multiplier, emergency_parts_multiplier,
      validation_status, data_source, currency,
      triggered_by, notes, calculated_at
    ) VALUES (
      gen_random_uuid()::text, ${orgId}, ${workOrderId},
      ${result.equipmentId}, ${result.vesselId}, ${result.predictionId},
      ${result.maintenanceType},
      ${result.actualCost}, ${result.avoidedCost}, ${result.totalSavings},
      ${result.laborSavings}, ${result.partsSavings}, ${result.downtimeSavings},
      ${result.estimatedDowntimePrevented}, ${result.assumptions.downtimeCostPerHour},
      ${result.confidenceScore}, ${result.confidenceLow}, ${result.confidenceHigh},
      ${result.assumptions.laborMultiplier}, ${result.assumptions.partsMultiplier},
      ${result.validationStatus}, ${result.dataSource}, ${result.currency},
      ${result.predictionId ? "ai_prediction" : "manual"},
      ${`Assumptions: labor ${result.assumptions.laborMultiplier}x, parts ${result.assumptions.partsMultiplier}x, downtime ${result.assumptions.downtimeMultiplier}x @ $${result.assumptions.downtimeCostPerHour}/hr (${result.assumptions.downtimeCostSource}). Cost data: ${result.assumptions.costDataSource}.`},
      NOW()
    )
    ON CONFLICT (work_order_id) WHERE work_order_id IS NOT NULL
    DO UPDATE SET
      actual_cost = EXCLUDED.actual_cost,
      avoided_cost = EXCLUDED.avoided_cost,
      total_savings = EXCLUDED.total_savings,
      labor_savings = EXCLUDED.labor_savings,
      parts_savings = EXCLUDED.parts_savings,
      downtime_savings = EXCLUDED.downtime_savings,
      confidence_score = EXCLUDED.confidence_score,
      confidence_low = EXCLUDED.confidence_low,
      confidence_high = EXCLUDED.confidence_high,
      data_source = EXCLUDED.data_source,
      notes = EXCLUDED.notes,
      calculated_at = NOW()
    RETURNING id
  `).then((r) => r.rows || r);

  logger.info(
    `[savings] Persisted savings for WO ${workOrderId}: $${result.totalSavings.toFixed(0)} ` +
    `(${result.dataSource}, ${result.validationStatus}, confidence ${(result.confidenceScore * 100).toFixed(0)}%)`
  );

  return row?.id;
}

// ─── Auto-Void on WO Cancellation ──────────────────────────────────────────

export async function voidSavingsOnWorkOrderCancellation(
  workOrderId: string,
  orgId: string,
  userId?: string,
): Promise<boolean> {
  const result = await db.execute(sql`
    UPDATE cost_savings
    SET
      validation_status = 'voided',
      validation_changed_by = ${userId || "system"},
      validation_changed_at = NOW(),
      validation_reason = 'Work order cancelled'
    WHERE work_order_id = ${workOrderId}
      AND org_id = ${orgId}
      AND validation_status != 'voided'
  `);

  const count = (result as any).rowCount ?? 0;
  if (count > 0) {
    logger.info(`[savings] Voided ${count} savings record(s) for cancelled WO ${workOrderId}`);
  }
  return count > 0;
}

// ─── Dispute / Validate ─────────────────────────────────────────────────────

export async function updateSavingsValidation(
  savingsId: string,
  orgId: string,
  status: "valid" | "disputed" | "voided",
  reason: string,
  userId: string,
): Promise<boolean> {
  const result = await db.execute(sql`
    UPDATE cost_savings
    SET
      validation_status = ${status},
      validation_changed_by = ${userId},
      validation_changed_at = NOW(),
      validation_reason = ${reason}
    WHERE id = ${savingsId} AND org_id = ${orgId}
  `);

  const count = (result as any).rowCount ?? 0;
  logger.info(`[savings] Updated savings ${savingsId} to ${status}: ${reason}`);
  return count > 0;
}
