/**
 * Financial Layer Tightening — Schema Migration
 *
 * Covers all three tasks:
 *   #56: Savings claim integrity (validationStatus, audit trail)
 *   #55: Decision-point cost context (costJustification on work_orders)
 *   #54: Cost flow integration (downtimeCostPerHour override, charterDayRate on vessels)
 *
 * Run after existing tables are in place.
 * All operations are idempotent (IF NOT EXISTS guards).
 */

import { sql } from "drizzle-orm";
import type { PostgresJsDatabase } from "drizzle-orm/postgres-js";

export async function migrateFinancialLayerTightening(db: PostgresJsDatabase) {
  // ═══════════════════════════════════════════════════════════════════════════
  // TASK #56: SAVINGS CLAIM INTEGRITY
  // ═══════════════════════════════════════════════════════════════════════════

  // 1. Add validationStatus lifecycle to cost_savings
  await db.execute(sql`
    DO $$
    BEGIN
      -- validationStatus: estimated → valid → disputed → voided
      -- Default is 'estimated' (not 'valid') — claims require validation
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'cost_savings' AND column_name = 'validation_status'
      ) THEN
        ALTER TABLE cost_savings
          ADD COLUMN validation_status TEXT NOT NULL DEFAULT 'estimated',
          ADD COLUMN validation_changed_by TEXT,
          ADD COLUMN validation_changed_at TIMESTAMP WITH TIME ZONE,
          ADD COLUMN validation_reason TEXT;

        -- Migrate existing records: mark them 'valid' since they predate this feature
        UPDATE cost_savings SET validation_status = 'valid' WHERE validation_status = 'estimated';

        CREATE INDEX idx_cost_savings_validation_status
          ON cost_savings(validation_status);

        COMMENT ON COLUMN cost_savings.validation_status IS
          'Lifecycle: estimated (default on creation) → valid (reviewed) → disputed → voided. Only valid records count in savings totals.';
      END IF;

      -- Add confidence_level as a derived range field
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'cost_savings' AND column_name = 'confidence_low'
      ) THEN
        ALTER TABLE cost_savings
          ADD COLUMN confidence_low REAL,
          ADD COLUMN confidence_high REAL;

        -- Backfill: derive ranges from existing confidenceScore
        -- ±(1 - confidenceScore) as percentage range
        UPDATE cost_savings
        SET
          confidence_low = total_savings * GREATEST(0, 1 - (1 - COALESCE(confidence_score, 0.7)) * 1.5),
          confidence_high = total_savings * (1 + (1 - COALESCE(confidence_score, 0.7)) * 1.5)
        WHERE confidence_low IS NULL;

        COMMENT ON COLUMN cost_savings.confidence_low IS
          'Low bound of savings estimate. Derived from prediction confidence.';
        COMMENT ON COLUMN cost_savings.confidence_high IS
          'High bound of savings estimate. Derived from prediction confidence.';
      END IF;

      -- Add currency field (Task #54 cross-cutting concern)
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'cost_savings' AND column_name = 'currency'
      ) THEN
        ALTER TABLE cost_savings ADD COLUMN currency TEXT DEFAULT 'BND';
      END IF;

      -- Add data_source field: 'measured' vs 'estimated'
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'cost_savings' AND column_name = 'data_source'
      ) THEN
        ALTER TABLE cost_savings ADD COLUMN data_source TEXT DEFAULT 'estimated';

        COMMENT ON COLUMN cost_savings.data_source IS
          'Whether costs are from SHIPMATE actuals (measured) or ARUS estimates (estimated). Affects confidence display.';
      END IF;
    END $$;
  `);

  // ═══════════════════════════════════════════════════════════════════════════
  // TASK #55: DECISION-POINT COST CONTEXT
  // ═══════════════════════════════════════════════════════════════════════════

  // 2. Add costJustification to work_orders
  await db.execute(sql`
    DO $$
    BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'work_orders' AND column_name = 'cost_justification'
      ) THEN
        ALTER TABLE work_orders ADD COLUMN cost_justification TEXT;

        COMMENT ON COLUMN work_orders.cost_justification IS
          'Auto-populated when WO originates from AI prediction. Captures prediction confidence, estimated failure cost, repair cost rationale. Shows WHY this WO was created.';
      END IF;

      -- Add estimated_failure_cost: what would happen if we don't act
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'work_orders' AND column_name = 'estimated_failure_cost'
      ) THEN
        ALTER TABLE work_orders ADD COLUMN estimated_failure_cost REAL;

        COMMENT ON COLUMN work_orders.estimated_failure_cost IS
          'Estimated cost if equipment fails without intervention. Used in cost comparison at decision point.';
      END IF;

      -- Add estimated_repair_cost: what it costs to act now
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'work_orders' AND column_name = 'estimated_repair_cost'
      ) THEN
        ALTER TABLE work_orders ADD COLUMN estimated_repair_cost REAL;

        COMMENT ON COLUMN work_orders.estimated_repair_cost IS
          'Estimated total repair cost (labor + parts + procurement). Used in cost comparison at decision point.';
      END IF;

      -- Add prediction_id FK for traceability
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'work_orders' AND column_name = 'prediction_id'
      ) THEN
        ALTER TABLE work_orders ADD COLUMN prediction_id TEXT;

        COMMENT ON COLUMN work_orders.prediction_id IS
          'FK to failure_predictions. Links WO to the AI prediction that triggered it.';
      END IF;
    END $$;
  `);

  // ═══════════════════════════════════════════════════════════════════════════
  // TASK #54: COST FLOW INTEGRATION
  // ═══════════════════════════════════════════════════════════════════════════

  // 3. Add vessel-level charter rate (the actual source of downtime cost)
  await db.execute(sql`
    DO $$
    BEGIN
      -- Vessel charter rate → this is what downtime actually costs
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'vessels' AND column_name = 'charter_day_rate'
      ) THEN
        ALTER TABLE vessels
          ADD COLUMN charter_day_rate REAL,
          ADD COLUMN charter_currency TEXT DEFAULT 'BND',
          ADD COLUMN downtime_cost_per_hour REAL;

        COMMENT ON COLUMN vessels.charter_day_rate IS
          'Daily charter rate. Primary source for downtime cost calculation. downtimeCostPerHour = charterDayRate / 24.';
        COMMENT ON COLUMN vessels.downtime_cost_per_hour IS
          'Derived from charter_day_rate / 24, or manually set. Falls back to global cost_model.downtime_per_hour.';
      END IF;

      -- Equipment-level criticality multiplier for downtime
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'equipment' AND column_name = 'downtime_criticality_multiplier'
      ) THEN
        ALTER TABLE equipment
          ADD COLUMN downtime_criticality_multiplier REAL DEFAULT 1.0;

        COMMENT ON COLUMN equipment.downtime_criticality_multiplier IS
          'Multiplier applied to vessel downtime cost for this equipment. 1.0 = full off-hire (main engine). 0.1 = degraded ops (FW generator). Used with vessel.downtimeCostPerHour.';
      END IF;

      -- Add procurement_cost tracking on work_orders (aggregated from linked SOs/POs)
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'work_orders' AND column_name = 'total_procurement_cost'
      ) THEN
        ALTER TABLE work_orders
          ADD COLUMN total_procurement_cost REAL DEFAULT 0,
          ADD COLUMN procurement_currency TEXT;

        COMMENT ON COLUMN work_orders.total_procurement_cost IS
          'Sum of linked service_orders.actualAmount + purchase_order_items.totalPrice. Auto-updated when SOs/POs complete.';
      END IF;

      -- Add cost_data_source to work_orders: tracks where cost figures came from
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'work_orders' AND column_name = 'cost_data_source'
      ) THEN
        ALTER TABLE work_orders ADD COLUMN cost_data_source TEXT DEFAULT 'estimated';

        COMMENT ON COLUMN work_orders.cost_data_source IS
          'Where cost data originates: shipmate_import, manual_entry, estimated, or procurement_linked.';
      END IF;
    END $$;
  `);

  // 4. Create the aggregated cost view for work orders
  await db.execute(sql`
    CREATE OR REPLACE VIEW work_order_cost_breakdown AS
    SELECT
      wo.id AS work_order_id,
      wo.work_order_number,
      wo.org_id,

      -- Internal labor (from worklogs)
      COALESCE(wl.total_labor, 0) AS internal_labor_cost,

      -- Internal parts (from WO parts)
      COALESCE(wp.total_parts, 0) AS internal_parts_cost,

      -- External procurement (from linked SOs + POs)
      COALESCE(so_cost.total_so, 0) AS external_service_cost,
      COALESCE(po_cost.total_po, 0) AS external_parts_cost,
      COALESCE(so_cost.total_so, 0) + COALESCE(po_cost.total_po, 0) AS total_procurement_cost,

      -- Grand total
      COALESCE(wl.total_labor, 0) +
      COALESCE(wp.total_parts, 0) +
      COALESCE(so_cost.total_so, 0) +
      COALESCE(po_cost.total_po, 0) AS computed_total_cost,

      -- Currency warnings
      CASE
        WHEN so_cost.has_mixed_currency THEN 'mixed_currency'
        ELSE 'ok'
      END AS currency_status,

      -- Data source
      wo.cost_data_source

    FROM work_orders wo

    LEFT JOIN LATERAL (
      SELECT COALESCE(SUM(total_labor_cost), 0) AS total_labor
      FROM work_order_worklogs
      WHERE work_order_id = wo.id
    ) wl ON TRUE

    LEFT JOIN LATERAL (
      SELECT COALESCE(SUM(COALESCE(actual_cost, total_cost)), 0) AS total_parts
      FROM work_order_parts
      WHERE work_order_id = wo.id
    ) wp ON TRUE

    LEFT JOIN LATERAL (
      SELECT
        COALESCE(SUM(actual_amount), 0) AS total_so,
        COUNT(DISTINCT currency) > 1 AS has_mixed_currency
      FROM service_orders
      WHERE work_order_id = wo.id
        AND status NOT IN ('cancelled', 'draft')
        AND actual_amount IS NOT NULL
    ) so_cost ON TRUE

    LEFT JOIN LATERAL (
      SELECT COALESCE(SUM(poi.total_price), 0) AS total_po
      FROM purchase_order_items poi
      JOIN purchase_orders po ON po.id = poi.purchase_order_id
      WHERE po.work_order_id = wo.id
        AND po.status NOT IN ('cancelled', 'draft')
    ) po_cost ON TRUE;
  `);
}
