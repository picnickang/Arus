/**
 * Procurement → Work Order Cost Flow
 *
 * TASK #54: Cost Flow Integration
 *
 * When a service order or purchase order completes (or its cost is updated),
 * this service recalculates the linked work order's totalProcurementCost
 * and updates the WO's cost summary fields.
 *
 * Call `syncProcurementCostsToWorkOrder()` from:
 *   - Service order status change handlers (when status → completed/invoiced)
 *   - Purchase order receive/fulfill handlers
 *   - Manual cost update endpoints
 *
 * The WO's totalCost becomes: internalLabor + internalParts + procurementCost.
 * This unified total is what the cost-savings engine reads.
 *
 * Currency handling: if SOs/POs have mixed currencies, the function flags
 * the WO with currency_status='mixed_currency' and does NOT sum them.
 * The user must resolve the currency mismatch before costs aggregate.
 */

import { db } from "../../db-config.js";
import { sql } from "drizzle-orm";
import { logger } from "../../utils/logger.js";

// ─── Types ──────────────────────────────────────────────────────────────────

export interface CostSyncResult {
  workOrderId: string;
  internalLaborCost: number;
  internalPartsCost: number;
  externalServiceCost: number;
  externalPartsCost: number;
  totalProcurementCost: number;
  computedTotalCost: number;
  currencyStatus: "ok" | "mixed_currency";
  updated: boolean;
}

// ─── Main Sync Function ─────────────────────────────────────────────────────

/**
 * Recalculates and updates the work order's cost fields from linked
 * service orders and purchase orders.
 *
 * Returns the new cost breakdown, or null if the WO doesn't exist.
 */
export async function syncProcurementCostsToWorkOrder(
  workOrderId: string,
  orgId: string,
): Promise<CostSyncResult | null> {
  // 1. Verify WO exists
  const [wo] = await db.execute(sql`
    SELECT id, total_labor_cost, total_parts_cost, total_cost
    FROM work_orders
    WHERE id = ${workOrderId} AND org_id = ${orgId}
  `).then((r) => r.rows || r);

  if (!wo) {
    logger.warn(`[cost-sync] Work order ${workOrderId} not found`);
    return null;
  }

  // 2. Sum linked service order costs (completed/in-progress only)
  const [soCosts] = await db.execute(sql`
    SELECT
      COALESCE(SUM(actual_amount), 0) AS total_so_cost,
      COUNT(DISTINCT currency) AS currency_count,
      (ARRAY_AGG(DISTINCT currency))[1] AS primary_currency
    FROM service_orders
    WHERE work_order_id = ${workOrderId}
      AND org_id = ${orgId}
      AND status NOT IN ('cancelled', 'draft')
      AND actual_amount IS NOT NULL
  `).then((r) => r.rows || r);

  // 3. Sum linked purchase order item costs
  const [poCosts] = await db.execute(sql`
    SELECT
      COALESCE(SUM(poi.total_price), 0) AS total_po_cost
    FROM purchase_order_items poi
    JOIN purchase_orders po ON po.id = poi.purchase_order_id
    WHERE po.work_order_id = ${workOrderId}
      AND po.org_id = ${orgId}
      AND po.status NOT IN ('cancelled', 'draft')
  `).then((r) => r.rows || r);

  // 4. Check for currency mismatch
  const currencyCount = Number(soCosts?.currency_count) || 0;
  const currencyStatus = currencyCount > 1 ? "mixed_currency" as const : "ok" as const;

  // 5. Calculate totals
  const externalServiceCost = Number(soCosts?.total_so_cost) || 0;
  const externalPartsCost = Number(poCosts?.total_po_cost) || 0;
  const totalProcurementCost = externalServiceCost + externalPartsCost;

  const internalLaborCost = Number(wo.total_labor_cost) || 0;
  const internalPartsCost = Number(wo.total_parts_cost) || 0;

  // 6. Don't sum if currencies are mixed — flag and keep existing total
  if (currencyStatus === "mixed_currency") {
    logger.warn(
      `[cost-sync] WO ${workOrderId} has mixed-currency service orders — ` +
      `procurement cost not aggregated. Resolve currency mismatch.`
    );

    await db.execute(sql`
      UPDATE work_orders
      SET
        total_procurement_cost = ${totalProcurementCost},
        procurement_currency = ${soCosts?.primary_currency || null},
        cost_data_source = 'procurement_linked',
        updated_at = NOW()
      WHERE id = ${workOrderId} AND org_id = ${orgId}
    `);

    return {
      workOrderId,
      internalLaborCost,
      internalPartsCost,
      externalServiceCost,
      externalPartsCost,
      totalProcurementCost,
      computedTotalCost: internalLaborCost + internalPartsCost, // Don't include mixed-currency procurement
      currencyStatus,
      updated: true,
    };
  }

  // 7. Update WO with unified totals
  const computedTotalCost = internalLaborCost + internalPartsCost + totalProcurementCost;

  await db.execute(sql`
    UPDATE work_orders
    SET
      total_procurement_cost = ${totalProcurementCost},
      procurement_currency = ${soCosts?.primary_currency || null},
      total_cost = ${computedTotalCost},
      cost_data_source = CASE
        WHEN cost_data_source = 'shipmate_import' THEN 'shipmate_import'
        WHEN ${totalProcurementCost} > 0 THEN 'procurement_linked'
        ELSE COALESCE(cost_data_source, 'estimated')
      END,
      updated_at = NOW()
    WHERE id = ${workOrderId} AND org_id = ${orgId}
  `);

  logger.info(
    `[cost-sync] Updated WO ${workOrderId}: ` +
    `labor=$${internalLaborCost} + parts=$${internalPartsCost} + ` +
    `procurement=$${totalProcurementCost} = total=$${computedTotalCost}` +
    (currencyStatus !== "ok" ? ` [${currencyStatus}]` : "")
  );

  return {
    workOrderId,
    internalLaborCost,
    internalPartsCost,
    externalServiceCost,
    externalPartsCost,
    totalProcurementCost,
    computedTotalCost,
    currencyStatus,
    updated: true,
  };
}

/**
 * Batch sync: recalculates procurement costs for ALL work orders in an org.
 * Use during initial setup or after a bulk SHIPMATE import.
 */
export async function syncAllProcurementCosts(orgId: string): Promise<number> {
  const rows = await db.execute(sql`
    SELECT DISTINCT wo.id
    FROM work_orders wo
    LEFT JOIN service_orders so ON so.work_order_id = wo.id
    LEFT JOIN purchase_orders po ON po.work_order_id = wo.id
    WHERE wo.org_id = ${orgId}
      AND (so.id IS NOT NULL OR po.id IS NOT NULL)
  `).then((r) => r.rows || r);

  let synced = 0;
  for (const row of rows as any[]) {
    await syncProcurementCostsToWorkOrder(row.id, orgId);
    synced++;
  }

  logger.info(`[cost-sync] Batch synced ${synced} work orders for org ${orgId}`);
  return synced;
}
