/**
 * Suggestion Engine — Cost Context Enrichment
 *
 * TASK #55: Decision-Point Cost Context
 *
 * This module provides a function to enrich AI suggestions with financial context.
 * Call `enrichSuggestionWithCost()` in the SuggestionEngine when generating
 * suggestions from high_risk_prediction triggers.
 *
 * The enrichment adds:
 *   - Estimated repair cost (from labor rates × estimated hours + parts)
 *   - Estimated failure cost (from downtime × vessel rate × emergency multipliers)
 *   - Net potential savings
 *   - Cost comparison text for display in suggestion cards
 *   - Cost justification text for the work order
 *
 * All numbers are estimates and labeled as such. When assumptions use defaults
 * rather than vessel/equipment-specific data, the output flags it.
 */

import { db } from "../../db-config.js";
import { sql } from "drizzle-orm";
import { logger } from "../../utils/logger.js";

// ─── Types ──────────────────────────────────────────────────────────────────

export interface PredictionCostContext {
  predictionId: string;
  equipmentId: string;
  vesselId?: string;
  probability: number;
  confidence?: number;
  costImpact?: {
    estimatedRepairCost?: number;
    estimatedDowntime?: number;
    revenueImpact?: number;
  };
}

export interface CostEnrichment {
  /** Estimated cost to repair now (planned maintenance) */
  estimatedRepairCost: number;
  /** Estimated cost if equipment fails (emergency scenario) */
  estimatedFailureCost: number;
  /** Net potential savings (failure - repair) */
  potentialSavings: number;
  /** One-line summary for suggestion card */
  costComparisonText: string;
  /** Full justification for work order costJustification field */
  costJustification: string;
  /** Whether any assumptions used fleet-average defaults */
  usesDefaults: boolean;
  /** Currency */
  currency: string;
  /** Assumptions breakdown for transparency */
  assumptions: string[];
}

// ─── Enrichment Function ────────────────────────────────────────────────────

export async function enrichSuggestionWithCost(
  orgId: string,
  prediction: PredictionCostContext,
): Promise<CostEnrichment | null> {
  try {
    const assumptions: string[] = [];
    let usesDefaults = false;

    // 1. Get equipment financial metadata
    const [equipment] = await db.execute(sql`
      SELECT
        name,
        criticality_level,
        emergency_labor_multiplier,
        emergency_parts_multiplier,
        emergency_downtime_multiplier,
        downtime_criticality_multiplier
      FROM equipment
      WHERE id = ${prediction.equipmentId} AND org_id = ${orgId}
    `).then((r) => r.rows || r);

    const laborMult = equipment?.emergency_labor_multiplier ?? 3.0;
    const partsMult = equipment?.emergency_parts_multiplier ?? 1.5;
    const downtimeMult = equipment?.emergency_downtime_multiplier ?? 3.0;
    const criticalityMult = equipment?.downtime_criticality_multiplier ?? 1.0;

    if (!equipment?.emergency_labor_multiplier) {
      assumptions.push(`Emergency multipliers: fleet defaults (labor ${laborMult}x, parts ${partsMult}x, downtime ${downtimeMult}x)`);
      usesDefaults = true;
    }

    // 2. Get vessel charter rate for downtime cost
    let downtimeCostPerHour = 0;
    let downtimeSource = "global_default";
    let currency = "BND";

    if (prediction.vesselId) {
      const [vessel] = await db.execute(sql`
        SELECT
          name,
          charter_day_rate,
          downtime_cost_per_hour,
          charter_currency
        FROM vessels
        WHERE id = ${prediction.vesselId} AND org_id = ${orgId}
      `).then((r) => r.rows || r);

      currency = vessel?.charter_currency || "BND";

      if (vessel?.downtime_cost_per_hour) {
        downtimeCostPerHour = vessel.downtime_cost_per_hour * criticalityMult;
        downtimeSource = "vessel_charter";
        assumptions.push(`Downtime: ${currency} ${vessel.downtime_cost_per_hour}/hr × ${criticalityMult} criticality (from ${vessel.name} charter rate)`);
      } else if (vessel?.charter_day_rate) {
        downtimeCostPerHour = (vessel.charter_day_rate / 24) * criticalityMult;
        downtimeSource = "vessel_charter";
        assumptions.push(`Downtime: ${currency} ${(vessel.charter_day_rate / 24).toFixed(0)}/hr × ${criticalityMult} criticality (derived from ${currency} ${vessel.charter_day_rate}/day charter)`);
      }
    }

    if (downtimeCostPerHour === 0) {
      // Global fallback
      const [costModel] = await db.execute(sql`
        SELECT downtime_per_hour FROM cost_model WHERE org_id = ${orgId} LIMIT 1
      `).then((r) => r.rows || r);
      downtimeCostPerHour = (costModel?.downtime_per_hour ?? 500) * criticalityMult;
      usesDefaults = true;
      assumptions.push(`Downtime: fleet-average ${currency} ${downtimeCostPerHour.toFixed(0)}/hr (configure vessel charter rate for accuracy)`);
    }

    // 3. Get labor rate
    const [laborRate] = await db.execute(sql`
      SELECT labor_rate_per_hour FROM cost_model WHERE org_id = ${orgId} LIMIT 1
    `).then((r) => r.rows || r);
    const hourlyRate = laborRate?.labor_rate_per_hour ?? 75;

    // 4. Calculate repair cost (planned maintenance)
    const estimatedHours = prediction.costImpact?.estimatedDowntime ?? 8; // default 8hr job
    const estimatedLaborCost = hourlyRate * estimatedHours;
    const estimatedPartsCost = prediction.costImpact?.estimatedRepairCost
      ? prediction.costImpact.estimatedRepairCost - estimatedLaborCost
      : estimatedLaborCost * 0.5; // parts roughly 50% of labor if no data
    const estimatedRepairCost = prediction.costImpact?.estimatedRepairCost
      ?? (estimatedLaborCost + Math.max(0, estimatedPartsCost));

    if (!prediction.costImpact?.estimatedRepairCost) {
      assumptions.push(`Repair cost: estimated from ${estimatedHours}hr × ${currency} ${hourlyRate}/hr + parts`);
      usesDefaults = true;
    }

    // 5. Calculate failure cost (emergency scenario)
    const emergencyLaborCost = estimatedLaborCost * laborMult;
    const emergencyPartsCost = Math.max(0, estimatedPartsCost) * partsMult;
    const emergencyDowntimeCost = estimatedHours * downtimeCostPerHour * downtimeMult;
    const estimatedFailureCost = emergencyLaborCost + emergencyPartsCost + emergencyDowntimeCost;

    // 6. Potential savings
    const potentialSavings = estimatedFailureCost - estimatedRepairCost;

    // 7. Build cost comparison text (for suggestion card)
    const repairK = (estimatedRepairCost / 1000).toFixed(0);
    const failureK = (estimatedFailureCost / 1000).toFixed(0);
    const savingsK = (potentialSavings / 1000).toFixed(0);
    const confidencePct = ((prediction.confidence ?? prediction.probability) * 100).toFixed(0);

    const costComparisonText =
      `Repair now: ~${currency} ${repairK}K. ` +
      `If this fails: ~${currency} ${failureK}K. ` +
      `Potential savings: ~${currency} ${savingsK}K.` +
      (usesDefaults ? " ⚠ Uses fleet-average estimates." : "");

    // 8. Build cost justification (for work order)
    const costJustification =
      `AI predicted ${confidencePct}% failure probability. ` +
      `Estimated repair cost: ~${currency} ${estimatedRepairCost.toLocaleString()}. ` +
      `Estimated failure impact: ~${currency} ${estimatedFailureCost.toLocaleString()} ` +
      `(labor ${laborMult}x + parts ${partsMult}x + downtime ${downtimeMult}x at ${currency} ${downtimeCostPerHour.toFixed(0)}/hr). ` +
      `Potential savings: ~${currency} ${potentialSavings.toLocaleString()}. ` +
      `${usesDefaults ? "Note: Some values use fleet-average defaults. " : ""}` +
      `Data: ${downtimeSource === "vessel_charter" ? "vessel charter rate" : "global defaults"}.`;

    return {
      estimatedRepairCost,
      estimatedFailureCost,
      potentialSavings,
      costComparisonText,
      costJustification,
      usesDefaults,
      currency,
      assumptions,
    };
  } catch (err) {
    logger.error(`[cost-enrichment] Failed for prediction ${prediction.predictionId}:`, err);
    return null;
  }
}

// ─── Draft Work Order Cost Population ───────────────────────────────────────

/**
 * Returns the fields to populate on a draft work order created from an AI prediction.
 * Call this from the draftWorkOrder tool to auto-fill cost context.
 */
export function buildDraftWorkOrderCostFields(enrichment: CostEnrichment, prediction: PredictionCostContext) {
  return {
    costJustification: enrichment.costJustification,
    estimatedRepairCost: enrichment.estimatedRepairCost,
    estimatedFailureCost: enrichment.estimatedFailureCost,
    predictionId: prediction.predictionId,
    // These feed into the WO form's estimated cost fields
    estimatedCostPerHour: 0, // Let the form calculate from labor rates
    estimatedHours: prediction.costImpact?.estimatedDowntime ?? 8,
  };
}
