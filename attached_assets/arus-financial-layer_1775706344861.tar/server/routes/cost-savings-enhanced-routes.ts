/**
 * Cost-Savings Routes — Enhanced
 *
 * TASK #56: Savings Claim Integrity
 *
 * New endpoints:
 *   PATCH /api/cost-savings/:id/validation — dispute or validate a savings claim
 *   GET   /api/cost-savings/summary-enhanced — summary with confidence ranges + integrity metrics
 *   GET   /api/cost-savings/trend-enhanced — monthly trend with confidence bands
 *   GET   /api/cost-savings/equipment-ranked — equipment savings ranking for superintendents
 *
 * Register these alongside existing cost-savings routes.
 */

import type { Express, Request, Response } from "express";
import { requireOrgId, requireOrgIdAndValidateBody } from "../../middleware/auth.js";
import { withErrorHandling } from "../../lib/route-utils.js";
import {
  updateSavingsValidation,
} from "../cost-savings-engine/calculator-enhanced.js";
import {
  getEnhancedSavingsSummary,
  getEnhancedMonthlySavingsTrend,
  getEquipmentSavingsRanked,
} from "../cost-savings-engine/reporting-enhanced.js";

function getOrgId(req: any): string {
  return req.orgId || req.headers["x-org-id"] || "";
}

export function registerEnhancedCostSavingsRoutes(
  app: Express,
  rateLimiters: { writeOperationRateLimit: any; generalApiRateLimit: any },
) {
  const { writeOperationRateLimit, generalApiRateLimit } = rateLimiters;

  // ── PATCH /api/cost-savings/:id/validation ─────────────────────────────
  // Dispute, validate, or void a savings claim
  app.patch(
    "/api/cost-savings/:id/validation",
    requireOrgIdAndValidateBody,
    writeOperationRateLimit,
    withErrorHandling("update savings validation", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const savingsId = req.params.id;
      const { status, reason } = req.body;

      if (!["valid", "disputed", "voided"].includes(status)) {
        return res.status(400).json({ error: "status must be valid, disputed, or voided" });
      }
      if (!reason || reason.trim().length === 0) {
        return res.status(400).json({ error: "reason is required" });
      }

      const userId = (req as any).userId || (req as any).user?.id || "unknown";
      const updated = await updateSavingsValidation(savingsId, orgId, status, reason, userId);

      if (!updated) {
        return res.status(404).json({ error: "Savings record not found" });
      }

      res.json({ id: savingsId, validationStatus: status, reason });
    }),
  );

  // ── GET /api/cost-savings/summary-enhanced ─────────────────────────────
  // Summary with confidence ranges, integrity metrics, data source breakdown
  app.get(
    "/api/cost-savings/summary-enhanced",
    requireOrgId,
    generalApiRateLimit,
    withErrorHandling("get enhanced savings summary", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const { dateFrom, dateTo } = req.query as { dateFrom?: string; dateTo?: string };

      const summary = await getEnhancedSavingsSummary(orgId, dateFrom, dateTo);
      res.json(summary);
    }),
  );

  // ── GET /api/cost-savings/trend-enhanced ───────────────────────────────
  // Monthly trend with confidence bands
  app.get(
    "/api/cost-savings/trend-enhanced",
    requireOrgId,
    generalApiRateLimit,
    withErrorHandling("get enhanced savings trend", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const months = parseInt(req.query.months as string) || 12;

      const trend = await getEnhancedMonthlySavingsTrend(orgId, months);
      res.json(trend);
    }),
  );

  // ── GET /api/cost-savings/equipment-ranked ─────────────────────────────
  // Equipment savings ranking (superintendent/technical manager view)
  app.get(
    "/api/cost-savings/equipment-ranked",
    requireOrgId,
    generalApiRateLimit,
    withErrorHandling("get equipment savings ranking", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const limit = parseInt(req.query.limit as string) || 20;

      const ranking = await getEquipmentSavingsRanked(orgId, limit);
      res.json(ranking);
    }),
  );
}
