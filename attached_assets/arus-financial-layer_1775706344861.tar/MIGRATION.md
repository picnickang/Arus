# Financial Layer Tightening — Migration Guide

## Overview

Three tasks from the financial evaluation, built for the reality of vessel operations:
costs come from SHIPMATE, not from engineers typing numbers.

**Build order: #56 → #55 → #54** (credibility first, then context, then plumbing)

## Files

### Database Migration
| File | Purpose |
|------|---------|
| `server/migrations/financial-layer-tightening.ts` | Adds all schema changes across 3 tasks. Idempotent. Run once. |

### Task #56: Savings Claim Integrity
| File | Purpose |
|------|---------|
| `server/cost-savings-engine/calculator-enhanced.ts` | Enhanced calculator with confidence ranges, data source tracking, auto-void. Replaces or extends existing `calculator.ts`. |
| `server/cost-savings-engine/reporting-enhanced.ts` | Summary with validation filtering, confidence bands, equipment ranking. Extends `reporting.ts`. |
| `server/routes/cost-savings-enhanced-routes.ts` | API: PATCH validation, GET summary-enhanced, GET trend-enhanced, GET equipment-ranked. |

### Task #55: Decision-Point Cost Context
| File | Purpose |
|------|---------|
| `server/domains/agent/application/cost-enrichment.ts` | Enriches AI suggestions with cost comparison. Call from SuggestionEngine. |
| `client/src/components/work-orders/CostContextComponents.tsx` | CostComparisonBadge (for cards), CostJustificationPanel (for WO detail), SavingsValidationBadge. |

### Task #54: Cost Flow Integration
| File | Purpose |
|------|---------|
| `server/domains/cost-savings/procurement-cost-sync.ts` | Syncs SO/PO costs into WO totals. Call on SO/PO completion. |
| `client/src/components/work-orders/WOCostBreakdownPanel.tsx` | WO detail panel showing internal labor + parts + procurement + savings. |

## Integration Steps

### 1. Run migration
```typescript
import { migrateFinancialLayerTightening } from "./migrations/financial-layer-tightening";
await migrateFinancialLayerTightening(db);
```

### 2. Register routes
```typescript
import { registerEnhancedCostSavingsRoutes } from "./routes/cost-savings-enhanced-routes";
registerEnhancedCostSavingsRoutes(app, { writeOperationRateLimit, generalApiRateLimit });
```

### 3. Wire savings calculation to use enhanced calculator
In `server/cost-savings-engine/persistence.ts`, replace or augment `processWorkOrderCompletion`:

```typescript
import { calculateWorkOrderSavingsEnhanced, persistEnhancedSavings } from "./calculator-enhanced";

export async function processWorkOrderCompletion(workOrderId: string, orgId: string) {
  const result = await calculateWorkOrderSavingsEnhanced({ workOrderId, orgId });
  if (result) {
    await persistEnhancedSavings(result, workOrderId, orgId);
  }
}
```

### 4. Wire auto-void on WO cancellation
In your work order status transition handler:

```typescript
import { voidSavingsOnWorkOrderCancellation } from "./cost-savings-engine/calculator-enhanced";

// When WO transitions to "cancelled":
if (newStatus === "cancelled") {
  await voidSavingsOnWorkOrderCancellation(workOrderId, orgId, userId);
}
```

### 5. Wire cost enrichment to suggestion engine
In `server/domains/agent/application/suggestion-engine.ts`:

```typescript
import { enrichSuggestionWithCost, buildDraftWorkOrderCostFields } from "./cost-enrichment";

// When generating a suggestion from a high_risk_prediction:
const costContext = await enrichSuggestionWithCost(orgId, {
  predictionId: prediction.id,
  equipmentId: prediction.equipmentId,
  vesselId: prediction.vesselId,
  probability: prediction.probability,
  confidence: prediction.confidence,
  costImpact: prediction.costImpact,
});

if (costContext) {
  suggestion.summary += "\n" + costContext.costComparisonText;
  suggestion.metadata.costContext = costContext;
}
```

### 6. Wire cost fields to draft work order tool
In `server/domains/agent/tools/work-order-tools.ts`, extend the draftWorkOrder tool:

```typescript
import { buildDraftWorkOrderCostFields } from "../application/cost-enrichment";

// When creating draft from prediction:
if (costContext) {
  const costFields = buildDraftWorkOrderCostFields(costContext, prediction);
  Object.assign(draftData, costFields);
}
```

### 7. Wire procurement cost sync
In your service order status transition handlers:

```typescript
import { syncProcurementCostsToWorkOrder } from "./domains/cost-savings/procurement-cost-sync";

// When SO transitions to completed/invoiced and has a workOrderId:
if (serviceOrder.workOrderId && ["completed", "invoiced"].includes(newStatus)) {
  await syncProcurementCostsToWorkOrder(serviceOrder.workOrderId, orgId);
}
```

Same for purchase order receive/fulfill handlers.

### 8. Add UI components

**WO Detail Drawer** — add cost breakdown:
```tsx
import { WOCostBreakdownPanel } from "@/components/work-orders/WOCostBreakdownPanel";
import { CostJustificationPanel } from "@/components/work-orders/CostContextComponents";

// In WO detail, after description/assignment sections:
{workOrder.costJustification && (
  <CostJustificationPanel costData={{
    estimatedRepairCost: workOrder.estimatedRepairCost,
    estimatedFailureCost: workOrder.estimatedFailureCost,
    costJustification: workOrder.costJustification,
    usesDefaults: workOrder.costJustification?.includes("fleet-average"),
  }} />
)}
<WOCostBreakdownPanel
  workOrderId={workOrder.id}
  workOrderStatus={workOrder.status}
/>
```

**Suggestion Cards / Finding Cards** — add cost badge:
```tsx
import { CostComparisonBadge } from "@/components/work-orders/CostContextComponents";

// In suggestion/finding card, near severity badge:
{suggestion.metadata?.costContext && (
  <CostComparisonBadge costData={{
    estimatedRepairCost: suggestion.metadata.costContext.estimatedRepairCost,
    estimatedFailureCost: suggestion.metadata.costContext.estimatedFailureCost,
    potentialSavings: suggestion.metadata.costContext.potentialSavings,
    currency: suggestion.metadata.costContext.currency,
    usesDefaults: suggestion.metadata.costContext.usesDefaults,
  }} />
)}
```

**Draft Approval Card** — show cost before approve:
```tsx
import { CostJustificationPanel } from "@/components/work-orders/CostContextComponents";

// In AgentChatPanel draft approval card:
{draft.costJustification && (
  <CostJustificationPanel costData={{
    estimatedRepairCost: draft.estimatedRepairCost,
    estimatedFailureCost: draft.estimatedFailureCost,
    costJustification: draft.costJustification,
    usesDefaults: draft.costJustification?.includes("fleet-average"),
  }} />
)}
```

## Design Decisions

1. **Savings default to "estimated", not "valid."** Maritime management is skeptical
   of AI claims. Starting honest builds more trust than starting optimistic.

2. **Downtime cost lives on the vessel (charter rate), not equipment.** Equipment
   gets a criticality multiplier (1.0 = full off-hire, 0.1 = degraded ops).
   `vessel.charterDayRate / 24 × equipment.downtimeCriticalityMultiplier` = downtime cost.

3. **Currency is stored, never converted.** Mixed-currency service orders are flagged,
   not auto-summed. The user resolves the mismatch.

4. **Assumptions are always visible.** Every cost comparison shows what multipliers
   were used, where the downtime rate came from, and whether defaults were involved.
   The "⚠ Uses fleet-average estimates" flag trains users to configure vessel data.

5. **SHIPMATE is the expected cost data source.** The system works with estimated
   costs when SHIPMATE data isn't available, but labels them clearly. The
   `cost_data_source` field on work orders tracks provenance.
