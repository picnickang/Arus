/**
 * Work Order Cost Breakdown Panel
 *
 * TASK #54: Cost Flow Integration — UI side
 *
 * Shows in the WO detail drawer/page. Displays the cost breakdown:
 *   - Internal labor (from worklogs)
 *   - Internal parts (from WO parts)
 *   - External service (from linked service orders)
 *   - External parts (from linked purchase orders)
 *   - Total
 *
 * Shows data source indicator (SHIPMATE import vs estimated vs procurement-linked).
 * Shows currency warning if mixed currencies detected.
 *
 * Post-completion: also shows avoided cost and savings record with validation status.
 */

import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DollarSign, Wrench, Package, Building2, AlertTriangle, CheckCircle, Clock,
} from "lucide-react";
import { SavingsValidationBadge } from "./CostContextComponents";

// ─── Types ──────────────────────────────────────────────────────────────────

interface CostBreakdown {
  workOrderId: string;
  internalLaborCost: number;
  internalPartsCost: number;
  externalServiceCost: number;
  externalPartsCost: number;
  totalProcurementCost: number;
  computedTotalCost: number;
  currencyStatus: string;
  costDataSource: string;
}

interface SavingsRecord {
  id: string;
  totalSavings: number;
  confidenceLow: number;
  confidenceHigh: number;
  avoidedCost: number;
  validationStatus: string;
  confidenceScore: number;
  dataSource: string;
  currency: string;
  notes: string;
}

interface WOCostBreakdownPanelProps {
  workOrderId: string;
  workOrderStatus: string;
  currency?: string;
  className?: string;
}

// ─── Format ─────────────────────────────────────────────────────────────────

function fmt(val: number, currency: string = "BND"): string {
  return `${currency} ${val.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}

// ─── Data Source Label ──────────────────────────────────────────────────────

function DataSourceBadge({ source }: { source: string }) {
  const config: Record<string, { label: string; variant: "default" | "outline" | "secondary" }> = {
    shipmate_import: { label: "SHIPMATE", variant: "default" },
    procurement_linked: { label: "Procurement-linked", variant: "secondary" },
    manual_entry: { label: "Manual", variant: "outline" },
    estimated: { label: "Estimated", variant: "outline" },
  };
  const c = config[source] || config.estimated;
  return <Badge variant={c.variant} className="text-[9px]">{c.label}</Badge>;
}

// ─── Cost Line Item ─────────────────────────────────────────────────────────

function CostLineItem({
  icon: Icon, label, amount, currency, isSubtotal = false,
}: {
  icon: React.ElementType;
  label: string;
  amount: number;
  currency: string;
  isSubtotal?: boolean;
}) {
  if (amount === 0 && !isSubtotal) return null;

  return (
    <div className={`flex items-center justify-between py-1.5 ${isSubtotal ? "border-t pt-2 mt-1" : ""}`}>
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Icon className="h-3.5 w-3.5" />
        <span className={isSubtotal ? "font-semibold text-foreground" : ""}>{label}</span>
      </div>
      <span className={`text-xs font-mono ${isSubtotal ? "font-bold text-foreground" : ""}`}>
        {fmt(amount, currency)}
      </span>
    </div>
  );
}

// ─── Main Panel ─────────────────────────────────────────────────────────────

export function WOCostBreakdownPanel({
  workOrderId,
  workOrderStatus,
  currency = "BND",
  className = "",
}: WOCostBreakdownPanelProps) {
  // Fetch cost breakdown from view
  const { data: breakdown, isLoading: breakdownLoading } = useQuery<CostBreakdown>({
    queryKey: ["/api/work-orders", workOrderId, "cost-breakdown"],
    enabled: !!workOrderId,
    staleTime: 30000,
  });

  // Fetch savings record if WO is completed
  const isCompleted = workOrderStatus === "completed";
  const { data: savings } = useQuery<SavingsRecord>({
    queryKey: ["/api/cost-savings/by-work-order", workOrderId],
    enabled: isCompleted && !!workOrderId,
    staleTime: 60000,
  });

  if (breakdownLoading) {
    return <Skeleton className="h-32" />;
  }

  const b = breakdown || {
    internalLaborCost: 0,
    internalPartsCost: 0,
    externalServiceCost: 0,
    externalPartsCost: 0,
    totalProcurementCost: 0,
    computedTotalCost: 0,
    currencyStatus: "ok",
    costDataSource: "estimated",
  };

  const hasCostData = b.computedTotalCost > 0;

  return (
    <div className={className} data-testid="wo-cost-breakdown">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <DollarSign className="h-4 w-4 text-muted-foreground" />
          <h3 className="text-sm font-semibold">Cost Breakdown</h3>
        </div>
        <DataSourceBadge source={b.costDataSource} />
      </div>

      {/* Currency warning */}
      {b.currencyStatus === "mixed_currency" && (
        <div className="p-2 rounded-md bg-amber-500/10 border border-amber-500/20 text-xs text-amber-600 dark:text-amber-400 mb-3 flex items-start gap-2" data-testid="currency-warning">
          <AlertTriangle className="h-3 w-3 mt-0.5 shrink-0" />
          <span>Mixed currencies detected in linked service orders. Procurement costs shown separately until currencies are resolved.</span>
        </div>
      )}

      {!hasCostData ? (
        <div className="text-center py-4 text-muted-foreground text-xs border rounded-lg" data-testid="no-cost-data">
          <Clock className="h-4 w-4 mx-auto mb-1 opacity-50" />
          No cost data recorded yet.
          {b.costDataSource === "estimated" && (
            <div className="mt-1">Costs will populate from SHIPMATE import or manual entry.</div>
          )}
        </div>
      ) : (
        <div className="border rounded-lg p-3">
          <CostLineItem icon={Wrench} label="Internal labor" amount={b.internalLaborCost} currency={currency} />
          <CostLineItem icon={Package} label="Internal parts" amount={b.internalPartsCost} currency={currency} />
          <CostLineItem icon={Building2} label="External service" amount={b.externalServiceCost} currency={currency} />
          <CostLineItem icon={Package} label="External parts (PO)" amount={b.externalPartsCost} currency={currency} />
          <CostLineItem icon={DollarSign} label="Total" amount={b.computedTotalCost} currency={currency} isSubtotal />
        </div>
      )}

      {/* Savings record (post-completion) */}
      {isCompleted && savings && (
        <div className="mt-4" data-testid="savings-record">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-xs font-semibold text-muted-foreground">Avoided-Failure Savings</h4>
            <SavingsValidationBadge
              validationStatus={savings.validationStatus}
              confidenceScore={savings.confidenceScore}
            />
          </div>
          <Card className="bg-green-500/5 border-green-500/15">
            <CardContent className="p-3">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-muted-foreground">Avoided cost</span>
                <span className="text-xs font-mono">{fmt(savings.avoidedCost, savings.currency || currency)}</span>
              </div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-muted-foreground">Actual cost</span>
                <span className="text-xs font-mono">{fmt(b.computedTotalCost, currency)}</span>
              </div>
              <div className="flex justify-between items-center pt-1.5 border-t">
                <span className="text-xs font-semibold">Savings</span>
                <div className="text-right">
                  <div className="text-sm font-bold text-green-600 dark:text-green-400">
                    {fmt(savings.totalSavings, savings.currency || currency)}
                  </div>
                  {savings.confidenceLow != null && savings.confidenceHigh != null && (
                    <div className="text-[10px] text-muted-foreground">
                      Range: {fmt(savings.confidenceLow, savings.currency || currency)} – {fmt(savings.confidenceHigh, savings.currency || currency)}
                    </div>
                  )}
                </div>
              </div>
              {savings.dataSource && savings.dataSource !== "measured" && (
                <div className="text-[10px] text-muted-foreground mt-2 pt-1 border-t border-border/40">
                  {savings.dataSource === "estimated" ? "Based on estimated costs" : "Based on mixed data sources"}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
