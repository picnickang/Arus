/**
 * Cost Context UI Components
 *
 * TASK #55: Decision-Point Cost Context
 *
 * Two components:
 *
 * 1. CostComparisonBadge — compact badge for suggestion cards and finding cards
 *    Shows "~$42K at risk" or "Repair ~$6K vs Failure ~$42K"
 *
 * 2. CostJustificationPanel — full panel for work order detail and draft approval
 *    Shows the complete cost comparison with assumptions visible
 *
 * Both handle the "uses defaults" flag by showing a warning that vessel-specific
 * data would improve accuracy.
 */

import { DollarSign, AlertTriangle, TrendingDown, Info } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from "@/components/ui/tooltip";

// ─── Types ──────────────────────────────────────────────────────────────────

interface CostData {
  estimatedRepairCost?: number | null;
  estimatedFailureCost?: number | null;
  potentialSavings?: number | null;
  costJustification?: string | null;
  currency?: string;
  usesDefaults?: boolean;
}

// ─── Format helpers ─────────────────────────────────────────────────────────

function formatCost(value: number, currency: string = "BND"): string {
  if (value >= 1_000_000) return `${currency} ${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${currency} ${(value / 1_000).toFixed(0)}K`;
  return `${currency} ${value.toFixed(0)}`;
}

// ─── CostComparisonBadge (compact, for cards) ───────────────────────────────

interface CostComparisonBadgeProps {
  costData: CostData;
  variant?: "compact" | "expanded";
  className?: string;
}

export function CostComparisonBadge({
  costData,
  variant = "compact",
  className = "",
}: CostComparisonBadgeProps) {
  const { estimatedRepairCost, estimatedFailureCost, potentialSavings, currency = "BND", usesDefaults } = costData;

  // Need at least failure cost to show anything useful
  if (!estimatedFailureCost || estimatedFailureCost <= 0) return null;

  if (variant === "compact") {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Badge
              variant="outline"
              className={`text-[10px] gap-1 border-amber-500/30 text-amber-600 dark:text-amber-400 ${className}`}
              data-testid="cost-badge"
            >
              <DollarSign className="h-2.5 w-2.5" />
              ~{formatCost(estimatedFailureCost, currency)} at risk
              {usesDefaults && <AlertTriangle className="h-2.5 w-2.5 ml-0.5 opacity-60" />}
            </Badge>
          </TooltipTrigger>
          <TooltipContent className="max-w-xs text-xs">
            <div className="space-y-1">
              {estimatedRepairCost != null && (
                <div>Repair now: ~{formatCost(estimatedRepairCost, currency)}</div>
              )}
              <div>If this fails: ~{formatCost(estimatedFailureCost, currency)}</div>
              {potentialSavings != null && potentialSavings > 0 && (
                <div className="font-semibold text-green-500">
                  Potential savings: ~{formatCost(potentialSavings, currency)}
                </div>
              )}
              {usesDefaults && (
                <div className="text-amber-500 pt-1 border-t border-border/40">
                  ⚠ Uses fleet-average estimates
                </div>
              )}
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // Expanded variant: inline comparison
  return (
    <div className={`flex items-center gap-3 text-xs ${className}`} data-testid="cost-comparison-expanded">
      {estimatedRepairCost != null && (
        <span className="text-green-600 dark:text-green-400 font-medium">
          Repair: ~{formatCost(estimatedRepairCost, currency)}
        </span>
      )}
      <span className="text-muted-foreground">vs</span>
      <span className="text-red-600 dark:text-red-400 font-medium">
        Failure: ~{formatCost(estimatedFailureCost, currency)}
      </span>
      {potentialSavings != null && potentialSavings > 0 && (
        <>
          <span className="text-muted-foreground">=</span>
          <span className="font-bold text-green-600 dark:text-green-400">
            Save ~{formatCost(potentialSavings, currency)}
          </span>
        </>
      )}
      {usesDefaults && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger>
              <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
            </TooltipTrigger>
            <TooltipContent className="text-xs max-w-[200px]">
              Uses fleet-average estimates. Configure vessel charter rate for accurate projections.
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
    </div>
  );
}

// ─── CostJustificationPanel (full, for WO detail and draft approval) ────────

interface CostJustificationPanelProps {
  costData: CostData;
  className?: string;
}

export function CostJustificationPanel({
  costData,
  className = "",
}: CostJustificationPanelProps) {
  const {
    estimatedRepairCost,
    estimatedFailureCost,
    potentialSavings,
    costJustification,
    currency = "BND",
    usesDefaults,
  } = costData;

  // Show nothing if there's no cost data at all
  if (!costJustification && !estimatedFailureCost) return null;

  return (
    <div className={className} data-testid="cost-justification-panel">
      <div className="flex items-center gap-2 mb-2">
        <TrendingDown className="h-4 w-4 text-muted-foreground" />
        <h3 className="text-sm font-semibold">Cost Analysis</h3>
        {usesDefaults && (
          <Badge variant="outline" className="text-[9px] border-amber-500/30 text-amber-500">
            Fleet estimates
          </Badge>
        )}
      </div>

      {/* Cost comparison cards */}
      {(estimatedRepairCost != null || estimatedFailureCost != null) && (
        <div className="grid grid-cols-3 gap-2 mb-3">
          {estimatedRepairCost != null && (
            <Card className="bg-green-500/5 border-green-500/15">
              <CardContent className="p-2.5 text-center">
                <div className="text-[9px] text-muted-foreground uppercase">Repair Now</div>
                <div className="text-sm font-bold text-green-600 dark:text-green-400 mt-0.5">
                  ~{formatCost(estimatedRepairCost, currency)}
                </div>
              </CardContent>
            </Card>
          )}

          {estimatedFailureCost != null && (
            <Card className="bg-red-500/5 border-red-500/15">
              <CardContent className="p-2.5 text-center">
                <div className="text-[9px] text-muted-foreground uppercase">If Fails</div>
                <div className="text-sm font-bold text-red-600 dark:text-red-400 mt-0.5">
                  ~{formatCost(estimatedFailureCost, currency)}
                </div>
              </CardContent>
            </Card>
          )}

          {potentialSavings != null && potentialSavings > 0 && (
            <Card className="bg-sky-500/5 border-sky-500/15">
              <CardContent className="p-2.5 text-center">
                <div className="text-[9px] text-muted-foreground uppercase">Savings</div>
                <div className="text-sm font-bold text-sky-600 dark:text-sky-400 mt-0.5">
                  ~{formatCost(potentialSavings, currency)}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Full justification text */}
      {costJustification && (
        <div className="p-3 rounded-lg bg-muted/50 border text-xs text-muted-foreground leading-relaxed" data-testid="cost-justification-text">
          <div className="flex items-start gap-2">
            <Info className="h-3 w-3 mt-0.5 shrink-0 text-sky-500" />
            <span>{costJustification}</span>
          </div>
        </div>
      )}

      {/* Defaults warning */}
      {usesDefaults && (
        <div className="mt-2 p-2 rounded-md bg-amber-500/5 border border-amber-500/15 text-[11px] text-amber-600 dark:text-amber-400 flex items-start gap-2" data-testid="defaults-warning">
          <AlertTriangle className="h-3 w-3 mt-0.5 shrink-0" />
          <span>
            Some figures use fleet-average estimates. Configure vessel charter rates and
            equipment emergency multipliers for more accurate projections.
          </span>
        </div>
      )}
    </div>
  );
}

// ─── SavingsValidationBadge (Task #56: for Finance Mode) ────────────────────

interface SavingsValidationBadgeProps {
  validationStatus: string;
  confidenceScore?: number;
  className?: string;
}

export function SavingsValidationBadge({
  validationStatus,
  confidenceScore,
  className = "",
}: SavingsValidationBadgeProps) {
  const statusConfig: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string }> = {
    estimated: { variant: "outline", label: "Estimated" },
    valid: { variant: "default", label: "Validated" },
    disputed: { variant: "secondary", label: "Disputed" },
    voided: { variant: "destructive", label: "Voided" },
  };

  const config = statusConfig[validationStatus] || statusConfig.estimated;

  return (
    <div className={`flex items-center gap-1.5 ${className}`} data-testid={`validation-badge-${validationStatus}`}>
      <Badge variant={config.variant} className="text-[10px]">{config.label}</Badge>
      {confidenceScore != null && confidenceScore > 0 && (
        <span className="text-[10px] text-muted-foreground">
          {(confidenceScore * 100).toFixed(0)}% confidence
        </span>
      )}
    </div>
  );
}
