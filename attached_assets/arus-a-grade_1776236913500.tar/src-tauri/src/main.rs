// ARUS Marine PdM — Tauri Desktop Main

fn main() {
    arus_marine_pdm_lib::run();
}
