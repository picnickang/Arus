// ============================================================================
// package.json PATCH — Apply these changes to the existing package.json
// ============================================================================

// 1. Add "engines" field (top level, next to "type"):
//
//   "engines": {
//     "node": ">=20.0.0"
//   },

// 2. Add/update these scripts:
//
//   "test:unit": "node --experimental-vm-modules node_modules/jest/bin/jest.js --testPathPattern='tests/unit' --forceExit",
//   "test:integration": "node --experimental-vm-modules node_modules/jest/bin/jest.js --testPathPattern='tests/integration' --forceExit",
//   "test:all": "npm run test:unit && npm run test:integration",
//   "ci": "npm run lint && npm run check && npm run test:unit && npm run build",
//   "docker:up": "docker compose up -d postgres redis",
//   "docker:down": "docker compose down",

// 3. Verify these devDependencies exist (add if missing):
//
//   "@types/jest": "^29.5.0",  (or latest)
