/**
 * Equipment Hierarchy — Drizzle Schema Patch
 *
 * Apply these changes to your existing equipment table definition
 * in shared/schema/vessels.ts (or wherever `equipment` is defined).
 *
 * FIND (in the equipment pgTable definition, after the existing columns):
 * -----------------------------------------------
 *   // ... existing columns like serialNumber, installDate, etc.
 *   createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
 *   updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
 * -----------------------------------------------
 *
 * ADD BEFORE createdAt:
 * -----------------------------------------------
 *   /** Self-referencing FK for equipment hierarchy. NULL = top-level system. * /
 *   parentEquipmentId: varchar("parent_equipment_id").references((): any => equipment.id, { onDelete: "set null" }),
 *   /** Depth in hierarchy. 0 = root (system level). Auto-computed by DB trigger. * /
 *   hierarchyLevel: integer("hierarchy_level").default(0),
 *   /** Materialized path: rootId/.../thisId. Enables fast subtree queries. * /
 *   hierarchyPath: text("hierarchy_path").default(""),
 * -----------------------------------------------
 *
 * Also add to the table's index/constraint block:
 * -----------------------------------------------
 *   parentIdx: sql`CREATE INDEX IF NOT EXISTS idx_equipment_parent ON equipment (parent_equipment_id)`,
 *   hierarchyPathIdx: sql`CREATE INDEX IF NOT EXISTS idx_equipment_hierarchy_path ON equipment (hierarchy_path)`,
 * -----------------------------------------------
 *
 * And update the insert schema to include the new fields:
 * -----------------------------------------------
 *   export const insertEquipmentSchema = createInsertSchema(equipment).omit({
 *     id: true,
 *     createdAt: true,
 *     updatedAt: true,
 *     hierarchyLevel: true,  // <-- add this (auto-computed)
 *     hierarchyPath: true,   // <-- add this (auto-computed)
 *   });
 * -----------------------------------------------
 */

export {};
