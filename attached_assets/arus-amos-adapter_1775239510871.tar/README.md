# ARUS — AMOS Import Adapter + Equipment Hierarchy

## What's Included

### Equipment Hierarchy Migration
- `server/migrations/004-equipment-hierarchy.sql` — Adds `parentEquipmentId`, hierarchy path, recursive CTE view
- `shared/schema/equipment-hierarchy-patch.ts` — Drizzle schema patch instructions

### AMOS Import Adapter (6 files)
- `server/import-adapters/amos/parser.ts` — CSV/XML parser handling AMOS export quirks (BOM, semicolons, namespaces)
- `server/import-adapters/amos/field-mapping.ts` — Maps AMOS fields to ARUS schema with value transforms
- `server/import-adapters/amos/import-service.ts` — Orchestrates parse → map → validate → upsert → RAG ingestion
- `server/import-adapters/amos/routes.ts` — REST API endpoints for import, preview, and mapping docs
- `server/import-adapters/amos/index.ts` — Barrel export

## Integration Steps

### 1. Run the equipment hierarchy migration

```bash
psql $DATABASE_URL -f server/migrations/004-equipment-hierarchy.sql
```

This adds `parent_equipment_id`, `hierarchy_level`, and `hierarchy_path` to the equipment table with a trigger that auto-computes the path on insert/update.

### 2. Apply the Drizzle schema patch

Follow instructions in `shared/schema/equipment-hierarchy-patch.ts` to add the three new columns to your equipment pgTable definition.

### 3. Copy the AMOS adapter files

```bash
cp -r server/import-adapters/amos/ your-project/server/import-adapters/amos/
```

### 4. Register the import routes

In your main route registration:

```typescript
import { amosImportRouter } from "./import-adapters/amos/index.js";

app.use(amosImportRouter);
```

### 5. Test with a dry run

```bash
# Preview what would be imported (no database writes)
curl -X POST http://localhost:5000/api/import/amos/preview \
  -H "Content-Type: application/json" \
  -H "x-org-id: default-org-id" \
  -d '{
    "type": "equipment",
    "filename": "equipment.csv",
    "content": "EQUIPMENT_NO;DESCRIPTION;SYSTEM_TYPE;PARENT_EQUIPMENT_NO;MANUFACTURER;MODEL\nME-001;Main Engine;Propulsion;;MAN;6S50ME-C\nME-001-TC;Turbocharger;Propulsion;ME-001;ABB;A175-L\nME-001-TC-BRG;TC Bearing Assembly;Propulsion;ME-001-TC;SKF;23130"
  }'
```

### 6. Full import with RAG ingestion

```bash
curl -X POST http://localhost:5000/api/import/amos \
  -H "Content-Type: application/json" \
  -H "x-org-id: default-org-id" \
  -d '{
    "type": "work_orders",
    "filename": "job-orders-2023-2025.csv",
    "feedToRag": true,
    "content": "... your AMOS export content ..."
  }'
```

## How the RAG Integration Works

When `feedToRag: true` (default), the import service generates structured text documents from the imported data and feeds them into the knowledge base:

**Equipment imports** generate per-system-type documents:
> "Equipment Register: Propulsion — Main Engine (MAN 6S50ME-C, Serial: 12345, Critical), Turbocharger (ABB A175-L)..."

**Work order imports** generate per-equipment maintenance history:
> "Maintenance History for ME-001 — 47 work orders. Latest: WO-2025-001 Turbocharger bearing replacement (corrective, 12 hours)..."

**Parts imports** generate per-category catalogs:
> "Spare Parts: Filters — P001 Oil Filter (Manufacturer: MANN, Critical), P002 Air Filter..."

This means a chief engineer can ask the AI assistant:
- "What's the failure history for the main engine turbocharger?"
- "When was the last time we replaced the TC bearing?"
- "What spare parts do we need for a turbocharger overhaul?"

And the AI will find answers from the imported AMOS data.

## AMOS Export Formats Supported

| Format | Delimiter | Notes |
|--------|-----------|-------|
| CSV (comma) | , | Standard export |
| CSV (semicolon) | ; | European AMOS installations |
| XML | N/A | AMOS XML export with namespace handling |

The parser auto-detects the format. Override with the `delimiter` option if needed.

## Field Mapping Reference

Call `GET /api/import/amos/mappings` to see all field mappings for each import type.

### Equipment Fields
| AMOS Field | ARUS Field | Required | Notes |
|-----------|-----------|----------|-------|
| EQUIPMENT_NO | id | Yes | Primary key |
| DESCRIPTION | name | Yes | |
| PARENT_EQUIPMENT_NO | parentEquipmentId | No | Builds hierarchy |
| SYSTEM_TYPE | systemType | No | |
| CRITICALITY | criticalityLevel | No | Maps A/B/C/D → critical/high/medium/low |
| MANUFACTURER | manufacturer | No | |
| MODEL | model | No | |
| SERIAL_NO | serialNumber | No | |
| RUNNING_HOURS | runningHours | No | |

### Work Order Fields
| AMOS Field | ARUS Field | Required | Notes |
|-----------|-----------|----------|-------|
| JOB_ORDER_NO | woNumber | Yes | Unique per org |
| DESCRIPTION | title | Yes | |
| EQUIPMENT_NO | equipmentId | Yes | Links to equipment |
| STATUS | status | No | Maps AMOS statuses to ARUS |
| MAINTENANCE_TYPE | maintenanceType | No | PM/CM/PD/EM mapping |
| PLANNED_HOURS | estimatedHours | No | |
| ACTUAL_HOURS | actualHours | No | |

### Parts Fields
| AMOS Field | ARUS Field | Required | Notes |
|-----------|-----------|----------|-------|
| PART_NO | partNo | Yes | Unique per org |
| DESCRIPTION | name | Yes | |
| CURRENT_STOCK | _stock_quantityOnHand | No | Creates stock record |
| LOCATION | _stock_location | No | Default: MAIN |
| CRITICALITY | criticality | No | Maps to 4-level scale |
