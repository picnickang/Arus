/**
 * AMOS Import Routes
 *
 * Exposes the AMOS import service via REST API.
 *
 * Endpoints:
 *   POST /api/import/amos          — Upload and import an AMOS file
 *   POST /api/import/amos/preview  — Dry run: parse and validate without writing
 *   GET  /api/import/amos/mappings — Get available field mappings for documentation
 *
 * Register: app.use(amosImportRouter);
 */

import { Router, Request, Response } from "express";
import { z } from "zod";
import { amosImportService, type ImportType } from "./import-service.js";
import { createLogger } from "../../lib/structured-logger.js";
import { requireOrgId, type AuthenticatedRequest } from "../../middleware/auth.js";
import { createRateLimiter } from "../../lib/rate-limit-factory.js";
import {
  EQUIPMENT_FIELD_MAP,
  WORK_ORDER_FIELD_MAP,
  PARTS_FIELD_MAP,
  MAINTENANCE_PLAN_FIELD_MAP,
} from "./field-mapping.js";

const logger = createLogger("amos-import-routes");
const router = Router();
const importLimit = createRateLimiter("write");

const VALID_TYPES: ImportType[] = ["equipment", "work_orders", "parts", "maintenance_plans"];

const importSchema = z.object({
  content: z.string().min(10, "File content is too short"),
  type: z.enum(["equipment", "work_orders", "parts", "maintenance_plans"]),
  filename: z.string().optional(),
  vesselId: z.string().optional(),
  feedToRag: z.boolean().optional().default(true),
  delimiter: z.string().optional(),
});

// ── POST /api/import/amos — Full import ────────────────────────────────────
router.post("/api/import/amos", requireOrgId, importLimit, async (req: Request, res: Response) => {
  try {
    const orgId = (req as AuthenticatedRequest).orgId as string;

    const parsed = importSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({
        error: "Validation failed",
        details: parsed.error.flatten(),
      });
    }

    const { content, type, filename, vesselId, feedToRag, delimiter } = parsed.data;

    logger.info("AMOS import request", { orgId, type, filename, feedToRag });

    const result = await amosImportService.importFile(orgId, content, {
      type,
      filename,
      dryRun: false,
      feedToRag,
      vesselId,
      delimiter,
    });

    const status = result.success ? 200 : 207; // 207 Multi-Status if partial
    res.status(status).json({
      success: result.success,
      data: result,
    });
  } catch (err) {
    logger.error("AMOS import failed", { error: err });
    res.status(500).json({
      error: "Import failed",
      message: err instanceof Error ? err.message : String(err),
    });
  }
});

// ── POST /api/import/amos/preview — Dry run ────────────────────────────────
router.post("/api/import/amos/preview", requireOrgId, importLimit, async (req: Request, res: Response) => {
  try {
    const orgId = (req as AuthenticatedRequest).orgId as string;

    const parsed = importSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({
        error: "Validation failed",
        details: parsed.error.flatten(),
      });
    }

    const { content, type, filename, delimiter } = parsed.data;

    const result = await amosImportService.importFile(orgId, content, {
      type,
      filename,
      dryRun: true,
      feedToRag: false,
      delimiter,
    });

    res.json({
      success: true,
      data: {
        ...result,
        message: `Preview: ${result.imported} rows would be imported, ${result.skipped} would be skipped.`,
      },
    });
  } catch (err) {
    logger.error("AMOS preview failed", { error: err });
    res.status(500).json({
      error: "Preview failed",
      message: err instanceof Error ? err.message : String(err),
    });
  }
});

// ── GET /api/import/amos/mappings — Field mapping reference ────────────────
router.get("/api/import/amos/mappings", requireOrgId, async (_req: Request, res: Response) => {
  const mappings = {
    equipment: {
      description: "AMOS Equipment Register export",
      fields: EQUIPMENT_FIELD_MAP.map((f) => ({
        amosField: f.amosField,
        arusField: f.arusField,
        required: f.required ?? false,
        hasTransform: !!f.transform,
      })),
    },
    work_orders: {
      description: "AMOS Job Orders / Work Orders export",
      fields: WORK_ORDER_FIELD_MAP.map((f) => ({
        amosField: f.amosField,
        arusField: f.arusField,
        required: f.required ?? false,
        hasTransform: !!f.transform,
      })),
    },
    parts: {
      description: "AMOS Spare Parts / Stock export",
      fields: PARTS_FIELD_MAP.map((f) => ({
        amosField: f.amosField,
        arusField: f.arusField,
        required: f.required ?? false,
        hasTransform: !!f.transform,
      })),
    },
    maintenance_plans: {
      description: "AMOS Maintenance Plans export",
      fields: MAINTENANCE_PLAN_FIELD_MAP.map((f) => ({
        amosField: f.amosField,
        arusField: f.arusField,
        required: f.required ?? false,
        hasTransform: !!f.transform,
      })),
    },
  };

  res.json({ success: true, data: mappings });
});

export { router as amosImportRouter };
export default router;
