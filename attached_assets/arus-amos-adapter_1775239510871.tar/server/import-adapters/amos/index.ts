/**
 * AMOS Import Adapter — Barrel Export
 *
 * Usage:
 *   import { amosImportRouter, amosImportService } from "./import-adapters/amos";
 *
 *   // Register routes
 *   app.use(amosImportRouter);
 *
 *   // Or use service directly
 *   const result = await amosImportService.importFile(orgId, content, { type: "equipment" });
 */

export { amosImportRouter } from "./routes.js";
export { amosImportService, type ImportResult, type ImportOptions, type ImportType } from "./import-service.js";
export { parseAmosFile, parseAmosCSV, parseAmosXML, type ParseResult } from "./parser.js";
export {
  applyMapping,
  EQUIPMENT_FIELD_MAP,
  WORK_ORDER_FIELD_MAP,
  PARTS_FIELD_MAP,
  MAINTENANCE_PLAN_FIELD_MAP,
  type FieldMapping,
} from "./field-mapping.js";
