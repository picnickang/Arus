# ARUS — First-Time Setup Checklist

Most gaps are now handled by scripts.  Follow these steps in order.

---

## Step 1 — Migrate bcrypt → bcryptjs  (~2 min)

```bash
npm run migrate:bcrypt          # dry run — shows what would change
npm run migrate:bcrypt:apply    # applies changes
npm uninstall bcrypt            # remove native addon
npm install                     # install bcryptjs (already in package.json)
```

`bcryptjs` is a pure-JS drop-in with an identical API.
No other code changes are needed.

---

## Step 2 — Wire desktop-init into server/index.ts  (~5 min)

Add this as the **very first line** of `server/index.ts`, before any imports
that open database connections or bind ports:

```typescript
import './desktop-init.js';
```

That's it.  The module exits the process early when `--init-db` or
`--health-check` flags are present, and does nothing otherwise.

---

## Step 3 — Register the setup route in your Express app  (~5 min)

In `server/index.ts` (or wherever you register routes), add:

```typescript
import setupRouter from './routes/setup.js';
app.use('/api/setup', setupRouter);
```

This provides:
- `POST /api/setup/complete` — called by the first-run wizard
- `GET  /api/setup/status`  — called by DesktopSetupGuard on every launch

---

## Step 4 — Wire the App.tsx guard  (~5 min)

Open `client/src/App.tsx` and apply the pattern shown in the new
`client/src/App.tsx` file:

```tsx
import DesktopSetup      from '@/pages/desktop-setup';
import DesktopSetupGuard from '@/components/DesktopSetupGuard';

// /setup must be OUTSIDE the guard to avoid redirect loops
<Route path="/setup" component={DesktopSetup} />

// All other routes go INSIDE the guard
<DesktopSetupGuard>
  <Route path="/" component={Dashboard} />
  {/* ... your other routes ... */}
</DesktopSetupGuard>
```

---

## Step 5 — Generate signing keys and set repo URL  (~5 min)

```bash
node scripts/setup-signing.mjs --repo YOUR_ORG/YOUR_REPO
```

This script:
- Generates `~/.tauri/arus.key` (private key — back it up)
- Injects the public key into `tauri.vessel.conf.json` and `tauri.cloud.conf.json`
- Sets the updater endpoint URL in both conf files
- Prints the GitHub Actions secrets you need to add

Then go to `https://github.com/YOUR_ORG/YOUR_REPO/settings/secrets/actions` and add:
- `TAURI_SIGNING_PRIVATE_KEY`           ← printed by the script
- `TAURI_SIGNING_PRIVATE_KEY_PASSWORD`  ← password you chose during generation

For macOS builds, also add:
- `APPLE_SIGNING_IDENTITY`
- `APPLE_ID`
- `APPLE_PASSWORD`
- `APPLE_TEAM_ID`

---

## Step 6 — Generate icons  (~2 min)

```bash
node scripts/generate-icons.mjs

# macOS:
iconutil -c icns src-tauri/icons/icon.iconset -o src-tauri/icons/icon.icns

# Windows (requires ImageMagick):
magick convert src-tauri/icons/32x32.png \
               src-tauri/icons/128x128.png \
               src-tauri/icons/icon.png \
               src-tauri/icons/icon.ico
```

---

## Step 7 — Test locally  (~10 min)

```bash
npm run build:sidecar     # compiles Express → binary, runs smoke test
npm run tauri:dev         # starts Tauri dev mode
```

On first launch the setup wizard should appear.
Complete it, verify the dashboard loads.

---

## Step 8 — Push a tag to trigger CI

```bash
git add -A && git commit -m "chore: wire desktop setup"
git tag v1.0.0
git push && git push --tags
```

CI produces four artifacts:
- `ARUS Vessel_1.0.0_x64-setup.exe`  (~145 MB, WebView2 bundled)
- `ARUS Cloud_1.0.0_x64-setup.exe`   (~25 MB, WebView2 downloaded)
- `ARUS_1.0.0_aarch64.dmg`
- `ARUS_1.0.0_x64.dmg`

---

## What the Windows Installer Does (Vessel variant)

1. Installs ARUS.exe to `C:\Program Files\ARUS Marine\`
2. Installs `bin\arus-server.exe` (Express + Node.js bundled)
3. Installs `bin\nssm.exe` (service wrapper)
4. Installs WebView2 runtime silently (bundled, no internet needed)
5. Creates `C:\ProgramData\ARUS Marine\logs\`
6. Creates local Windows account `ARUS_svc` (no login rights)
7. Grants `ARUS_svc` write access to `C:\ProgramData\ARUS Marine\`
8. Registers `ARUSBackend` Windows Service via NSSM, running as `ARUS_svc`
9. Runs `arus-server.exe --init-db` → bootstraps SQLite schema
10. Starts the `ARUSBackend` service
11. Customer launches ARUS → setup wizard → dashboard

On upgrade: service stops before files replaced, restarts after.
On uninstall: service removed, `ARUS_svc` account deleted, database preserved.

---

## Files Added in This Batch

| File | Purpose |
|---|---|
| `server/desktop-init.ts` | `--init-db` and `--health-check` flag handlers. Import at top of `server/index.ts`. |
| `server/routes/setup.ts` | `POST /api/setup/complete` + `GET /api/setup/status`. Register with `app.use('/api/setup', setupRouter)`. |
| `client/src/components/DesktopSetupGuard.tsx` | Wraps router, redirects to /setup on first launch. |
| `client/src/App.tsx` | Example showing where to wire the guard and the /setup route. |
| `scripts/migrate-bcrypt.mjs` | Codemod: replaces `bcrypt` with `bcryptjs` throughout server/. |
| `scripts/setup-signing.mjs` | Generates keypair, patches conf files, prints GitHub secrets. |
