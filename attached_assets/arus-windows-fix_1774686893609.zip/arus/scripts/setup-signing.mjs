#!/usr/bin/env node
/**
 * scripts/setup-signing.mjs
 *
 * One-time setup script that:
 *   1. Generates the Tauri updater signing keypair
 *   2. Injects the public key into tauri.vessel.conf.json and tauri.cloud.conf.json
 *   3. Prints the private key and password for you to add to GitHub Actions secrets
 *   4. Optionally sets the GitHub repo URL in both conf files
 *
 * Usage:
 *   node scripts/setup-signing.mjs
 *   node scripts/setup-signing.mjs --repo YOUR_ORG/YOUR_REPO
 *
 * Run this ONCE before your first production build.
 * The private key is written to ~/.tauri/arus.key — back it up.
 * If you lose it you cannot sign future updates and users will be stuck
 * on the current version until they reinstall.
 */

import { execSync }                             from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync,
         existsSync }                           from 'node:fs';
import { join, dirname, homedir }               from 'node:path';
import { fileURLToPath }                        from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root      = join(__dirname, '..');
const tauriDir  = join(root, 'src-tauri');
const keyDir    = join(homedir(), '.tauri');
const keyPath   = join(keyDir, 'arus.key');

const CONF_FILES = [
  join(tauriDir, 'tauri.vessel.conf.json'),
  join(tauriDir, 'tauri.cloud.conf.json'),
  join(tauriDir, 'tauri.conf.json'),
];

const repoArg = (() => {
  const idx = process.argv.indexOf('--repo');
  return idx >= 0 ? process.argv[idx + 1] : null;
})();

// ── Step 1: Generate keypair ─────────────────────────────────────────────────

console.log('🔑 Generating Tauri updater signing keypair…\n');

if (existsSync(keyPath)) {
  console.log(`ℹ️  Key file already exists at ${keyPath}`);
  console.log('   Delete it first if you want to regenerate.\n');
} else {
  mkdirSync(keyDir, { recursive: true });
  execSync(
    `npx @tauri-apps/cli signer generate -w "${keyPath}"`,
    { stdio: 'inherit', cwd: root }
  );
  console.log('');
}

// ── Step 2: Read the generated public key ────────────────────────────────────

// The signer generates two files: arus.key (private) and arus.key.pub (public)
const pubKeyPath = `${keyPath}.pub`;
if (!existsSync(pubKeyPath)) {
  console.error(`❌ Public key not found at ${pubKeyPath}`);
  console.error('   Run: npx @tauri-apps/cli signer generate -w ~/.tauri/arus.key');
  process.exit(1);
}

const pubKey = readFileSync(pubKeyPath, 'utf8').trim();
console.log(`✅ Public key read from ${pubKeyPath}`);
console.log(`   ${pubKey.slice(0, 40)}…\n`);

// ── Step 3: Inject public key into conf files ─────────────────────────────────

const PUBKEY_PLACEHOLDER = /REPLACE_WITH.*?signer generate[^"]*/g;
const REPO_PLACEHOLDER   = /YOUR_ORG\/arus-marine/g;

for (const confPath of CONF_FILES) {
  if (!existsSync(confPath)) continue;

  let content = readFileSync(confPath, 'utf8');
  let changed = false;

  // Inject public key
  if (PUBKEY_PLACEHOLDER.test(content)) {
    PUBKEY_PLACEHOLDER.lastIndex = 0; // reset after test()
    content = content.replace(PUBKEY_PLACEHOLDER, pubKey);
    changed = true;
  } else if (!content.includes(pubKey)) {
    console.warn(`⚠️  Could not find pubkey placeholder in ${confPath}`);
    console.warn('   Set plugins.updater.pubkey manually.');
  }

  // Inject repo URL
  if (repoArg && REPO_PLACEHOLDER.test(content)) {
    REPO_PLACEHOLDER.lastIndex = 0;
    content = content.replace(REPO_PLACEHOLDER, repoArg);
    changed = true;
  }

  if (changed) {
    writeFileSync(confPath, content, 'utf8');
    const rel = confPath.replace(root + '/', '');
    console.log(`✅ Updated ${rel}`);
  }
}

// ── Step 4: Print GitHub Actions secrets instructions ────────────────────────

console.log(`
${'─'.repeat(60)}
GitHub Actions secrets to add:
${'─'.repeat(60)}

Go to: https://github.com/${repoArg ?? 'YOUR_ORG/YOUR_REPO'}/settings/secrets/actions

Add these repository secrets:

  TAURI_SIGNING_PRIVATE_KEY
    Value: (contents of ${keyPath})

  TAURI_SIGNING_PRIVATE_KEY_PASSWORD
    Value: (the password you entered during key generation)
`);

if (!repoArg) {
  console.log(`Also run with --repo to set the update endpoint URL:
  node scripts/setup-signing.mjs --repo YOUR_ORG/YOUR_REPO
`);
} else {
  console.log(`✅ Updater endpoint set to:
   https://github.com/${repoArg}/releases/latest/download/latest.json
`);
}

// ── Step 5: Print the private key for CI copy-paste ─────────────────────────

console.log(`${'─'.repeat(60)}`);
console.log('Private key (for TAURI_SIGNING_PRIVATE_KEY secret):');
console.log(`${'─'.repeat(60)}`);
try {
  const privKey = readFileSync(keyPath, 'utf8').trim();
  console.log(privKey);
} catch {
  console.log(`(Read from ${keyPath})`);
}
console.log(`${'─'.repeat(60)}\n`);
console.log('⚠️  Back up ~/.tauri/arus.key — losing it means users cannot receive updates.\n');
