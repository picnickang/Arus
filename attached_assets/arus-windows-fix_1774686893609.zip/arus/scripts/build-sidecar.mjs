#!/usr/bin/env node
/**
 * build-sidecar.mjs
 *
 * Compiles the Express backend to a standalone binary for use as a
 * Tauri sidecar.  Three-stage process:
 *
 *   Stage 1 — esbuild bundles server/index.ts → dist/server-bundle.cjs
 *             Only true native addons (.node files) are marked external.
 *             bcryptjs is pure JS so it bundles cleanly — no native addon.
 *             libsql ships pre-built platform binaries that pkg snapshots.
 *
 *   Stage 2 — Build pkg asset manifest.
 *             Explicitly maps every libsql .node/.wasm file so pkg can
 *             embed them in the binary's virtual filesystem.  Uses exact
 *             known paths rather than a walk, since libsql's internal
 *             require() paths are deterministic.
 *
 *   Stage 3 — @yao-pkg/pkg compiles bundle + assets → standalone exe.
 *
 *   Stage 4 — Smoke test: runs the binary with --health-check to verify
 *             native modules load correctly before CI uploads the artifact.
 *
 * Output:
 *   src-tauri/binaries/arus-server-{triple}[.exe]   (Tauri sidecar)
 *   src-tauri/binaries/arus-server[.exe]             (dev copy)
 *
 * Usage:
 *   node scripts/build-sidecar.mjs              # current platform
 *   node scripts/build-sidecar.mjs --all        # all four targets
 *   node scripts/build-sidecar.mjs --skip-test  # skip smoke test
 */

import { execSync }                         from 'node:child_process';
import { mkdirSync, copyFileSync,
         writeFileSync, existsSync,
         readdirSync, statSync }            from 'node:fs';
import { join, dirname, relative, extname } from 'node:path';
import { fileURLToPath }                    from 'node:url';
import { platform, arch }                   from 'node:process';

const __dirname  = dirname(fileURLToPath(import.meta.url));
const root       = join(__dirname, '..');
const distDir    = join(root, 'dist');
const binDir     = join(root, 'src-tauri', 'binaries');
const bundleOut  = join(distDir, 'server-bundle.cjs');
const assetsJson = join(distDir, 'pkg-assets.json');
const nmDir      = join(root, 'node_modules');

// ── Platform → pkg target ─────────────────────────────────────────────────────

const TARGETS = {
  'x86_64-pc-windows-msvc':   { pkg: 'node20-win-x64',    ext: '.exe' },
  'aarch64-apple-darwin':     { pkg: 'node20-macos-arm64', ext: ''     },
  'x86_64-apple-darwin':      { pkg: 'node20-macos-x64',  ext: ''     },
  'x86_64-unknown-linux-gnu': { pkg: 'node20-linux-x64',  ext: ''     },
};

function currentTriple() {
  if (platform === 'win32')  return 'x86_64-pc-windows-msvc';
  if (platform === 'darwin') return arch === 'arm64'
    ? 'aarch64-apple-darwin' : 'x86_64-apple-darwin';
  return 'x86_64-unknown-linux-gnu';
}

// ── Stage 1: esbuild ──────────────────────────────────────────────────────────

function stage1_bundle() {
  console.log('\n📦 Stage 1 — esbuild bundle…');
  mkdirSync(distDir, { recursive: true });

  // Only packages with true native .node binaries need to be external.
  // bcrypt is REMOVED — replaced by bcryptjs (pure JS, no native addon).
  // libsql is external because it ships platform-specific pre-built .node
  // files that pkg will snapshot via the asset manifest in Stage 2.
  // sharp and better-sqlite3 are external for the same reason but are
  // optional — remove if not used in your server code.
  const externals = [
    // libsql platform packages (native .node per platform)
    '@libsql/client',
    '@libsql/darwin-arm64',
    '@libsql/darwin-x64',
    '@libsql/linux-x64-gnu',
    '@libsql/win32-x64-msvc',
    // optional — only if used
    'better-sqlite3',
    'sharp',
    'cpu-features',
    'ssh2',
    // bcrypt is NOT listed here — use bcryptjs instead (pure JS)
  ].map(p => `--external:${p}`).join(' ');

  execSync(
    `npx esbuild server/index.ts ` +
    `--platform=node --target=node20 --bundle --format=cjs ` +
    `--outfile=${bundleOut} --allow-overwrite ` +
    externals,
    { stdio: 'inherit', cwd: root }
  );
  console.log(`  ✅ ${bundleOut}`);
}

// ── Stage 2: asset manifest ───────────────────────────────────────────────────
//
// pkg embeds assets into the binary's virtual filesystem.  The key insight:
// pkg resolves require() paths relative to the *bundle file*, so all asset
// paths in the manifest must be relative to dirname(bundleOut).
//
// For libsql we explicitly enumerate known paths rather than relying on a
// walk, because libsql uses a custom resolver that looks for its binary at
// specific paths.  If we miss one, the binary silently falls back to WASM
// which is much slower — or crashes if the WASM is also missing.

function findFiles(dir, matchFn, results = []) {
  if (!existsSync(dir)) return results;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!['test', 'tests', '.bin'].includes(entry.name)) {
        findFiles(full, matchFn, results);
      }
    } else if (entry.isFile() && matchFn(entry.name, full)) {
      results.push(full);
    }
  }
  return results;
}

function relToBundle(absPath) {
  return relative(dirname(bundleOut), absPath).replace(/\\/g, '/');
}

function stage2_assetManifest() {
  console.log('\n📎 Stage 2 — Building asset manifest…');

  const assets = {};

  // 1. All .node files under @libsql (native platform binaries)
  const libsqlDir = join(nmDir, '@libsql');
  const nodeFiles = findFiles(libsqlDir,
    name => extname(name) === '.node');
  for (const f of nodeFiles) {
    assets[relToBundle(f)] = { isAsset: true };
    console.log(`  + ${relative(root, f)}`);
  }

  // 2. libsql WASM fallback (used when .node isn't available)
  const wasmFiles = findFiles(libsqlDir,
    name => extname(name) === '.wasm');
  for (const f of wasmFiles) {
    assets[relToBundle(f)] = { isAsset: true };
    console.log(`  + ${relative(root, f)} (wasm)`);
  }

  // 3. Any other .node files in node_modules (better-sqlite3, sharp, etc.)
  //    Only include packages that are actually external in esbuild above.
  const otherExternals = ['better-sqlite3', 'sharp'];
  for (const pkg of otherExternals) {
    const pkgDir = join(nmDir, pkg);
    const pkgNodes = findFiles(pkgDir, name => extname(name) === '.node');
    for (const f of pkgNodes) {
      assets[relToBundle(f)] = { isAsset: true };
      console.log(`  + ${relative(root, f)}`);
    }
  }

  const manifest = { assets, pkg: { assets } };
  writeFileSync(assetsJson, JSON.stringify(manifest, null, 2));
  console.log(`  ✅ Manifest: ${Object.keys(assets).length} asset(s)`);
}

// ── Stage 3: pkg compile ──────────────────────────────────────────────────────

function stage3_compile(triple) {
  const t = TARGETS[triple];
  if (!t) { console.error(`Unknown triple: ${triple}`); process.exit(1); }

  const outFile = join(binDir, `arus-server-${triple}${t.ext}`);
  console.log(`\n🔨 Stage 3 — pkg compile → ${triple}…`);
  mkdirSync(binDir, { recursive: true });

  execSync(
    `npx pkg ${bundleOut} ` +
    `--target ${t.pkg} ` +
    `--config ${assetsJson} ` +
    `--output ${outFile} ` +
    `--compress GZip`,
    { stdio: 'inherit', cwd: root }
  );
  console.log(`  ✅ ${outFile}`);
  return outFile;
}

// ── Stage 4: smoke test ───────────────────────────────────────────────────────
//
// Runs the compiled binary with --health-check which:
//   1. Imports @libsql/client (exercises native .node loading)
//   2. Opens an in-memory SQLite database
//   3. Runs a trivial query
//   4. Exits 0 on success, non-zero on failure
//
// This catches the "installs fine but crashes on first use" failure mode
// where a native addon is missing from the pkg virtual filesystem.
//
// NOTE: Only runs on the current platform (can't execute cross-compiled bins).

function stage4_smokeTest(binPath) {
  if (process.argv.includes('--skip-test')) {
    console.log('\n⏭  Smoke test skipped (--skip-test)');
    return;
  }

  console.log('\n🧪 Stage 4 — Smoke test…');
  try {
    execSync(`"${binPath}" --health-check`, {
      stdio: 'inherit',
      timeout: 15_000,
      env: {
        ...process.env,
        DATABASE_PATH: join(distDir, 'smoke-test.db'),
        PORT: '0',   // don't actually bind a port
      },
    });
    console.log('  ✅ Smoke test passed — native modules load correctly');
  } catch (e) {
    console.error('\n❌ Smoke test FAILED.');
    console.error('   The binary could not load its native modules.');
    console.error('   Check that all external packages are in the asset manifest.');
    console.error('   Error:', e.message);
    process.exit(1);
  }
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  const buildAll = process.argv.includes('--all');

  stage1_bundle();
  stage2_assetManifest();
  mkdirSync(binDir, { recursive: true });

  if (buildAll) {
    // Cross-compiled targets — smoke test only runs for the current platform.
    const current = currentTriple();
    for (const triple of Object.keys(TARGETS)) {
      const out = stage3_compile(triple);
      if (triple === current) stage4_smokeTest(out);
    }
  } else {
    const triple  = currentTriple();
    const outFile = stage3_compile(triple);
    stage4_smokeTest(outFile);

    // Un-suffixed dev copy for `tauri dev` (Tauri strips the triple in dev).
    const devCopy = join(binDir, `arus-server${TARGETS[triple].ext}`);
    copyFileSync(outFile, devCopy);
    console.log(`  ✅ Dev copy → ${devCopy}`);
  }

  console.log('\n✅ Sidecar build complete.\n');
}

main().catch(e => { console.error(e); process.exit(1); });
