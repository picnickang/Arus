#!/usr/bin/env node
/**
 * scripts/migrate-bcrypt.mjs
 *
 * Replaces all bcrypt imports and requires with bcryptjs throughout
 * the server/ directory.  bcryptjs is a pure-JS drop-in replacement
 * with an identical API so no other code changes are needed.
 *
 * Usage:
 *   node scripts/migrate-bcrypt.mjs          # dry run — shows what would change
 *   node scripts/migrate-bcrypt.mjs --apply  # applies changes
 *
 * Safe to run multiple times — already-migrated files are skipped.
 */

import { readdirSync, readFileSync, writeFileSync, statSync } from 'node:fs';
import { join, extname, relative, dirname }                   from 'node:path';
import { fileURLToPath }                                       from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root      = join(__dirname, '..');
const apply     = process.argv.includes('--apply');

// Directories to scan.
const SCAN_DIRS = ['server', 'shared'];

// File extensions to check.
const EXTENSIONS = new Set(['.ts', '.tsx', '.js', '.mjs', '.cjs']);

// Patterns to replace — ordered from most specific to least.
const REPLACEMENTS = [
  // ESM named imports:  import { hash, compare } from 'bcrypt'
  [/from\s+['"]bcrypt['"]/g,              "from 'bcryptjs'"],
  // ESM default import: import bcrypt from 'bcrypt'
  [/import\s+(\w+)\s+from\s+['"]bcrypt['"]/g, "import $1 from 'bcryptjs'"],
  // CJS require:        require('bcrypt')
  [/require\(['"]bcrypt['"]\)/g,           "require('bcryptjs')"],
  // Type import:        import type { ... } from 'bcrypt'
  [/from\s+['"]bcrypt\/types['"]/g,       "from 'bcryptjs'"],
];

// ── File walker ───────────────────────────────────────────────────────────────

function* walkDir(dir) {
  let entries;
  try { entries = readdirSync(dir, { withFileTypes: true }); }
  catch { return; }

  for (const entry of entries) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!['node_modules', 'dist', '.git', 'coverage'].includes(entry.name)) {
        yield* walkDir(full);
      }
    } else if (entry.isFile() && EXTENSIONS.has(extname(entry.name))) {
      yield full;
    }
  }
}

// ── Main ──────────────────────────────────────────────────────────────────────

let filesChanged = 0;
let filesSkipped = 0;

for (const scanDir of SCAN_DIRS) {
  const absDir = join(root, scanDir);
  for (const filePath of walkDir(absDir)) {
    const original = readFileSync(filePath, 'utf8');

    // Quick check — skip files that don't mention bcrypt at all.
    if (!original.includes("'bcrypt'") && !original.includes('"bcrypt"')) {
      continue;
    }

    // Skip files already using bcryptjs.
    if (original.includes('bcryptjs') && !original.includes("'bcrypt'")) {
      filesSkipped++;
      continue;
    }

    let updated = original;
    for (const [pattern, replacement] of REPLACEMENTS) {
      updated = updated.replace(pattern, replacement);
    }

    if (updated === original) {
      // The file mentions bcrypt but none of our patterns matched —
      // flag it for manual review.
      console.warn(`⚠️  Manual review needed: ${relative(root, filePath)}`);
      console.warn(`   Contains 'bcrypt' but no known import pattern matched.`);
      continue;
    }

    const rel = relative(root, filePath);
    if (apply) {
      writeFileSync(filePath, updated, 'utf8');
      console.log(`✅ Migrated: ${rel}`);
    } else {
      console.log(`📝 Would migrate: ${rel}`);
      // Show the specific lines that would change.
      const origLines = original.split('\n');
      const newLines  = updated.split('\n');
      origLines.forEach((line, i) => {
        if (line !== newLines[i]) {
          console.log(`   Line ${i + 1}:`);
          console.log(`     - ${line.trim()}`);
          console.log(`     + ${newLines[i].trim()}`);
        }
      });
    }
    filesChanged++;
  }
}

console.log('');
if (apply) {
  console.log(`✅ Migration complete — ${filesChanged} file(s) updated, ${filesSkipped} already migrated.`);
  if (filesChanged > 0) {
    console.log('\nNext: npm uninstall bcrypt && npm install   (removes native addon)');
  }
} else {
  console.log(`Dry run — ${filesChanged} file(s) would be updated.`);
  console.log('Run with --apply to apply changes:');
  console.log('  node scripts/migrate-bcrypt.mjs --apply');
}
