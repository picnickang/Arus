/**
 * client/src/components/DesktopSetupGuard.tsx
 *
 * Wraps the application router and redirects to the first-run setup
 * wizard when the desktop app hasn't been configured yet.
 *
 * Usage in App.tsx — wrap your existing router content:
 *
 *   import DesktopSetupGuard from '@/components/DesktopSetupGuard';
 *   import DesktopSetup from '@/pages/desktop-setup';
 *
 *   // Add the setup route first, then wrap everything else:
 *   function App() {
 *     return (
 *       <Router>
 *         <Route path="/setup" component={DesktopSetup} />
 *         <DesktopSetupGuard>
 *           <Route path="/" component={Dashboard} />
 *           // ... all your other routes
 *         </DesktopSetupGuard>
 *       </Router>
 *     );
 *   }
 *
 * The guard shows a neutral loading screen while it checks the backend,
 * then either renders children (setup done) or redirects to /setup.
 * In web/browser mode it renders children immediately with no check.
 */

import { useEffect, useState, ReactNode } from 'react';
import { useLocation }                    from 'wouter';
import { isDesktop }                      from '@/lib/desktop';
import { isDesktopSetupComplete }         from '@/lib/desktopFetch';

type GuardState = 'checking' | 'ready' | 'needs-setup';

interface Props {
  children: ReactNode;
}

export default function DesktopSetupGuard({ children }: Props) {
  const [, navigate]  = useLocation();
  const [state, setState] = useState<GuardState>(
    // Non-desktop environments skip the check entirely.
    isDesktop() ? 'checking' : 'ready'
  );

  useEffect(() => {
    if (!isDesktop()) return;

    let cancelled = false;

    isDesktopSetupComplete().then(complete => {
      if (cancelled) return;
      if (complete) {
        setState('ready');
      } else {
        setState('needs-setup');
        navigate('/setup', { replace: true });
      }
    });

    return () => { cancelled = true; };
  }, []);

  if (state === 'checking') {
    return <LoadingScreen />;
  }

  // 'needs-setup' renders nothing here — the navigate() above has already
  // redirected to /setup so the setup route's component will render instead.
  if (state === 'needs-setup') {
    return null;
  }

  return <>{children}</>;
}

// ── Loading screen ────────────────────────────────────────────────────────────
// Shown for the ~200 ms while we ping the backend and check setup status.
// Keep it minimal — it's only visible on first launch or when the backend
// takes a moment to start.

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="text-2xl font-bold text-white tracking-tight">ARUS</div>
        <div className="flex justify-center gap-1.5">
          {[0, 1, 2].map(i => (
            <div
              key={i}
              className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
        <p className="text-slate-500 text-sm">Starting…</p>
      </div>
    </div>
  );
}
