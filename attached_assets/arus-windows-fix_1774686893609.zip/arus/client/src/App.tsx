/**
 * client/src/App.tsx
 *
 * ARUS application root with desktop setup guard wired in.
 *
 * ── What changed from your original App.tsx ────────────────────────────────
 *
 *   1. Added import for DesktopSetup page
 *   2. Added import for DesktopSetupGuard component
 *   3. Added <Route path="/setup" component={DesktopSetup} /> OUTSIDE the guard
 *   4. Wrapped all existing routes INSIDE <DesktopSetupGuard>
 *
 * Everything else is your existing routing — adapt the route list below
 * to match your actual routes.  The pattern is what matters.
 *
 * ── How it works ────────────────────────────────────────────────────────────
 *
 *  Web browser:  Guard renders children immediately. /setup route exists
 *                but isDesktop() is false so nobody is redirected there.
 *
 *  Desktop, first launch:
 *                Guard checks /api/healthz + /api/setup/status.
 *                Backend not ready → guard redirects to /setup.
 *                Wizard starts backend (if vessel mode), completes setup,
 *                POSTs to /api/setup/complete, then navigate('/').
 *                Guard re-runs, setup is now complete, renders dashboard.
 *
 *  Desktop, subsequent launches:
 *                Guard checks /api/setup/status → complete: true.
 *                Children render immediately. Wizard never shown again.
 */

import { Switch, Route } from 'wouter';

// ── New imports (add these two lines) ────────────────────────────────────────
import DesktopSetup      from '@/pages/desktop-setup';
import DesktopSetupGuard from '@/components/DesktopSetupGuard';

// ── Your existing page imports (unchanged) ────────────────────────────────────
// import Dashboard        from '@/pages/dashboard';
// import Fleet            from '@/pages/fleet';
// import Maintenance      from '@/pages/maintenance';
// import Crew             from '@/pages/crew';
// import Inventory        from '@/pages/inventory';
// import Compliance       from '@/pages/compliance';
// import Analytics        from '@/pages/analytics';
// import Settings         from '@/pages/settings';
// import Admin            from '@/pages/admin';
// import NotFound         from '@/pages/not-found';

export default function App() {
  return (
    <Switch>

      {/*
        /setup MUST be outside DesktopSetupGuard.
        If it were inside, the guard would redirect to /setup,
        /setup would render, the guard would check again, and you'd
        get an infinite redirect loop.
      */}
      <Route path="/setup" component={DesktopSetup} />

      {/*
        All other routes are inside the guard.
        On desktop, the guard checks backend + setup status before
        rendering any of these.  On web it's a transparent pass-through.
      */}
      <DesktopSetupGuard>
        <Switch>
          {/* Replace these with your actual routes */}
          {/* <Route path="/"            component={Dashboard}   /> */}
          {/* <Route path="/fleet"       component={Fleet}       /> */}
          {/* <Route path="/maintenance" component={Maintenance} /> */}
          {/* <Route path="/crew"        component={Crew}        /> */}
          {/* <Route path="/inventory"   component={Inventory}   /> */}
          {/* <Route path="/compliance"  component={Compliance}  /> */}
          {/* <Route path="/analytics"   component={Analytics}   /> */}
          {/* <Route path="/settings"    component={Settings}    /> */}
          {/* <Route path="/admin"       component={Admin}       /> */}
          {/* <Route                     component={NotFound}    /> */}
        </Switch>
      </DesktopSetupGuard>

    </Switch>
  );
}
