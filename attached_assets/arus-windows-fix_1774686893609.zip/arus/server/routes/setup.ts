/**
 * server/routes/setup.ts
 *
 * POST /api/setup/complete
 *
 * Called by the first-run wizard (client/src/pages/desktop-setup.tsx)
 * on the final step.  Stores the admin password hash and optional vessel
 * ID, then marks setup as complete so the wizard never shows again.
 *
 * Registration in server/index.ts:
 *   import setupRouter from './routes/setup.js';
 *   app.use('/api/setup', setupRouter);
 *
 * This endpoint is intentionally available without authentication because
 * it only runs before any admin account exists.  It is guarded by a
 * one-time-use flag stored in admin_system_settings — once setup is
 * complete it returns 409 for all subsequent calls.
 *
 * Dependencies already in your project:
 *   bcryptjs, @libsql/client (vessel) or drizzle + postgres (cloud)
 *
 * Adapt the DB write calls to match your actual ORM/query layer.
 * The structure below follows the schema in init-db-entry.ts.
 */

import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';

const router = Router();

// ── POST /api/setup/complete ──────────────────────────────────────────────────

router.post('/complete', async (req: Request, res: Response) => {
  const { mode, vesselId, adminPassword } = req.body as {
    mode:          'vessel' | 'cloud';
    vesselId?:     string;
    adminPassword: string;
  };

  // ── Input validation ────────────────────────────────────────────────────────

  if (!adminPassword || typeof adminPassword !== 'string') {
    return res.status(400).json({ error: 'adminPassword is required' });
  }
  if (adminPassword.length < 8) {
    return res.status(400).json({ error: 'adminPassword must be at least 8 characters' });
  }
  if (!['vessel', 'cloud'].includes(mode)) {
    return res.status(400).json({ error: 'mode must be vessel or cloud' });
  }

  try {
    // ── Idempotency guard ─────────────────────────────────────────────────────
    // If setup has already been completed, refuse to overwrite.
    // This prevents an attacker who reaches the network before the operator
    // from resetting the admin password via the wizard endpoint.

    const alreadyDone = await isSetupComplete();
    if (alreadyDone) {
      return res.status(409).json({
        error: 'Setup has already been completed. Use the admin panel to change settings.',
      });
    }

    // ── Hash the admin password ───────────────────────────────────────────────
    // Cost factor 12 — appropriate for a server-side hash stored at rest.

    const passwordHash = await bcrypt.hash(adminPassword, 12);

    // ── Write to the database ─────────────────────────────────────────────────

    await saveAdminCredentials(passwordHash);

    if (vesselId?.trim()) {
      await saveVesselId(vesselId.trim());
    }

    if (mode) {
      await saveSetting('deployment', 'mode', mode);
    }

    // Mark setup as complete — this is what isSetupComplete() checks.
    await saveSetting('setup', 'completed', 'true');
    await saveSetting('setup', 'completed_at', new Date().toISOString());

    return res.status(200).json({ ok: true });

  } catch (err: any) {
    console.error('[ARUS] /api/setup/complete error:', err);
    return res.status(500).json({ error: 'Setup failed. Check server logs.' });
  }
});

// ── GET /api/setup/status ─────────────────────────────────────────────────────
// The first-run wizard and App.tsx guard can call this to check without
// making a full backend connection test.  Returns 200 always so the
// client can read the JSON body rather than catching a network error.

router.get('/status', async (_req: Request, res: Response) => {
  try {
    const complete = await isSetupComplete();
    return res.status(200).json({ complete });
  } catch {
    return res.status(200).json({ complete: false });
  }
});

// ── Database helpers ──────────────────────────────────────────────────────────
//
// These use the libsql client directly so this file works in both vessel
// (SQLite) and cloud (Postgres via a connection string) modes.
//
// If your project uses Drizzle ORM, replace these with your drizzle
// query calls — the table/column names match the schema in init-db-entry.ts.

async function getDbClient() {
  const { createClient } = await import('@libsql/client');

  const isVessel =
    process.env.DEPLOYMENT_MODE === 'VESSEL' ||
    process.env.LOCAL_MODE === 'true';

  if (isVessel) {
    const dbPath = process.env.DATABASE_PATH ?? 'data/vessel-local.db';
    return createClient({ url: `file:${dbPath}` });
  }

  // Cloud mode — DATABASE_URL should be a libsql/turso URL or postgres URL.
  // Adjust if you use a different cloud DB client.
  const url = process.env.TURSO_DB_URL ?? process.env.DATABASE_URL;
  if (!url) throw new Error('DATABASE_URL or TURSO_DB_URL is required in cloud mode');
  const authToken = process.env.TURSO_AUTH_TOKEN;
  return createClient({ url, authToken });
}

async function isSetupComplete(): Promise<boolean> {
  const client = await getDbClient();
  try {
    const result = await client.execute({
      sql: `SELECT value FROM admin_system_settings
            WHERE org_id = 'default-org-id'
              AND category = 'setup'
              AND key = 'completed'
            LIMIT 1`,
      args: [],
    });
    return result.rows.length > 0 && result.rows[0].value === 'true';
  } catch {
    // Table may not exist yet on a truly fresh install — that's fine.
    return false;
  } finally {
    client.close();
  }
}

async function saveAdminCredentials(passwordHash: string): Promise<void> {
  const client = await getDbClient();
  try {
    // Store in admin_system_settings so no separate users table is needed
    // for the initial desktop setup.  Your full auth system can read this.
    await client.execute({
      sql: `INSERT INTO admin_system_settings
              (org_id, category, key, value, data_type, is_sensitive, description)
            VALUES
              ('default-org-id', 'auth', 'admin_password_hash', ?, 'string', 1,
               'Bcrypt hash of the local admin password')
            ON CONFLICT(org_id, category, key)
            DO UPDATE SET value = excluded.value,
                          updated_at = strftime('%s','now')`,
      args: [passwordHash],
    });
  } finally {
    client.close();
  }
}

async function saveVesselId(vesselId: string): Promise<void> {
  const client = await getDbClient();
  try {
    await client.execute({
      sql: `UPDATE update_settings
            SET vessel_id  = ?,
                updated_at = strftime('%s','now')
            WHERE org_id = 'default-org-id'`,
      args: [vesselId],
    });
    // Also store in system settings for easy retrieval.
    await client.execute({
      sql: `INSERT INTO admin_system_settings
              (org_id, category, key, value, data_type, description)
            VALUES
              ('default-org-id', 'vessel', 'vessel_id', ?, 'string',
               'Vessel identifier set during initial setup')
            ON CONFLICT(org_id, category, key)
            DO UPDATE SET value = excluded.value,
                          updated_at = strftime('%s','now')`,
      args: [vesselId],
    });
  } finally {
    client.close();
  }
}

async function saveSetting(
  category: string,
  key: string,
  value: string,
): Promise<void> {
  const client = await getDbClient();
  try {
    await client.execute({
      sql: `INSERT INTO admin_system_settings
              (org_id, category, key, value, data_type)
            VALUES
              ('default-org-id', ?, ?, ?, 'string')
            ON CONFLICT(org_id, category, key)
            DO UPDATE SET value = excluded.value,
                          updated_at = strftime('%s','now')`,
      args: [category, key, value],
    });
  } finally {
    client.close();
  }
}

export default router;
