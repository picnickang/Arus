/**
 * server/desktop-init.ts
 *
 * Handles CLI flags injected by the Tauri desktop build.
 * Import this at the very top of server/index.ts, before anything else:
 *
 *   import './desktop-init.js';
 *
 * If neither flag is present this module does nothing and the normal
 * server startup continues.  If a flag IS present the process exits
 * before Express is ever constructed — so there is no risk of port
 * conflicts or DB connection attempts during installer actions.
 *
 * Flags:
 *   --init-db        Bootstrap SQLite schema (WiX post-install action)
 *   --health-check   Verify native modules load (pkg smoke test in CI)
 */

import { initDb } from './init-db-entry.js';

const args = process.argv;

// ── --init-db ─────────────────────────────────────────────────────────────────
// Called by WiX after the installer copies files:
//   arus-server.exe --init-db
// Must exit 0 on success, non-zero on failure so WiX knows whether to
// roll back the install.

if (args.includes('--init-db')) {
  console.log('[ARUS] Running database initialisation…');
  initDb()
    .then(() => {
      console.log('[ARUS] Database initialisation complete.');
      process.exit(0);
    })
    .catch(err => {
      console.error('[ARUS] Database initialisation failed:', err);
      process.exit(1);
    });

// ── --health-check ────────────────────────────────────────────────────────────
// Called by build-sidecar.mjs Stage 4 after pkg compilation.
// Verifies that all native modules load correctly inside the compiled binary.
// Exit 0 = binary is good. Exit 1 = missing .node files in pkg snapshot.

} else if (args.includes('--health-check')) {
  console.log('[ARUS] Health check: testing native module loading…');

  (async () => {
    try {
      // Test @libsql/client — the highest-risk native addon.
      const { createClient } = await import('@libsql/client');
      const client = createClient({ url: ':memory:' });
      const result = await client.execute('SELECT 1 AS ok');
      if (!result.rows[0]) throw new Error('libsql query returned no rows');
      client.close();
      console.log('[ARUS] ✅ @libsql/client — OK');

      // Test bcryptjs — pure JS but verify it's present and functional.
      const bcrypt = await import('bcryptjs');
      const hash = await bcrypt.hash('health-check-test', 8);
      const valid = await bcrypt.compare('health-check-test', hash);
      if (!valid) throw new Error('bcryptjs compare returned false');
      console.log('[ARUS] ✅ bcryptjs — OK');

      console.log('[ARUS] Health check PASSED.');
      process.exit(0);
    } catch (err: any) {
      console.error('[ARUS] Health check FAILED:', err.message);
      console.error('       A native module is missing from the pkg snapshot.');
      console.error('       Check the asset manifest in build-sidecar.mjs.');
      process.exit(1);
    }
  })();
}

// If neither flag matched, this module exits silently and normal server
// startup continues in server/index.ts.
