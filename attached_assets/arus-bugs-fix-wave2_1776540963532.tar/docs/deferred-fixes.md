# Wave 2 Deferred — Real Product Decisions Required

Two files in the top-10 have **real schema drift that requires product-architecture
decisions**, not just type-alignment. I've NOT generated fixes for these because
the right shape depends on how you want the feature to work in production.

---

## File 1: `server/domains/alerts/settings-service.ts` (35 errors)

### Diagnosis

The PG `notification_settings` schema is built around **alert notification
routing** (who gets notified about what):

```
notification_type, enabled, minSeverity, recipientEmails, recipientRoles,
recipientUserIds, deliveryMethod, webhookUrl, digestMode, digestSchedule
```

The code in `settings-service.ts` treats it as **email infrastructure
configuration** (how to send email at all):

```
emailEnabled, defaultToEmail, ccEmails, bccEmails, timezone, provider,
smtpHost, smtpPort, smtpUser, smtpUseTls, fromEmail, fromName,
dailyDigestEnabled, dailyDigestTime, alertCooldownMinutes, lastTestStatus
```

**These are two different concerns.** Conflating them in one table leads to 15+
columns that describe the SMTP server mixed with 10+ columns that describe the
delivery policy for a specific notification type.

### Recommended fix (needs your decision)

**Option A: Split into two tables** (recommended)

```
-- Email/SMTP config — one row per org
CREATE TABLE email_settings (
  org_id VARCHAR PK,
  provider TEXT,
  smtp_host, smtp_port, smtp_user, smtp_password_encrypted, smtp_use_tls,
  from_email, from_name,
  timezone,
  default_to_email, cc_emails, bcc_emails,
  last_test_status, last_test_at,
  created_at, updated_at
);

-- Notification routing (existing notification_settings, unchanged)
-- One row per org × notification_type
```

Then update `settings-service.ts` to query `email_settings` for infrastructure
and `notification_settings` for routing. Cleanest separation of concerns.

**Option B: Merge everything into notification_settings**

Add all the SMTP columns to `notification_settings`. The table becomes a
kitchen-sink for both concerns. Faster to implement, architecturally messier.

**Option C: Keep the schemas, rewrite the service**

Adapt `settings-service.ts` to use the existing columns:
- `emailEnabled` → `enabled`
- `defaultToEmail` → `recipientEmails[0]`
- `ccEmails/bccEmails` → not supported (document limitation)
- SMTP config → environment variables only (no DB-backed)

Takes the most work but no DB migration.

### To proceed

Tell me A / B / C and I'll generate the corresponding fix.

---

## File 2: `server/compliance/routes/ml-governance-routes.ts` (38 errors)

### Diagnosis

The PG `engineer_overrides` schema is a **generic override pattern** (works for
any entity, any override type):

```
overrideType, originalValue (jsonb), overrideValue (jsonb), reason,
approvedBy, createdBy, equipmentId, expiresAt, isActive
```

The ml-governance-routes code treats it as an **ML prediction override record**:

```
predictionId, workOrderId, originalRiskLevel, newRiskLevel,
originalConfidence, justification, engineerId, engineerName,
engineerCertifications
```

The generic design is flexible and better for reuse. The code is more ergonomic
but only for the ML prediction use case.

### Recommended fix (needs your decision)

**Option A: Adapt the route to the generic schema** (recommended)

Write an adapter in the route handler that packs/unpacks the ML-specific fields
into the generic `originalValue` and `overrideValue` JSONB:

```ts
// Outgoing (DB → API)
function adaptOverride(row: EngineerOverride): MlOverrideDto {
  const original = row.originalValue as OriginalML;
  const override = row.overrideValue as OverrideML;
  return {
    id: row.id,
    predictionId: original.predictionId,
    workOrderId: override.workOrderId,
    originalRiskLevel: original.riskLevel,
    newRiskLevel: override.riskLevel,
    // ... etc
    justification: row.reason,
    engineerId: row.createdBy,
    createdAt: row.createdAt,
  };
}

// Incoming (API → DB)
function packOverride(dto: MlOverrideRequest): InsertEngineerOverride {
  return {
    overrideType: "ml_prediction",
    originalValue: {
      predictionId: dto.predictionId,
      riskLevel: dto.originalRiskLevel,
      confidence: dto.originalConfidence,
    },
    overrideValue: {
      riskLevel: dto.newRiskLevel,
      workOrderId: dto.workOrderId,
    },
    reason: dto.justification,
    equipmentId: dto.equipmentId,
    createdBy: dto.engineerId,
  };
}
```

**Option B: Add ML-specific columns to engineer_overrides**

Migrate: add predictionId, workOrderId, originalRiskLevel, newRiskLevel,
originalConfidence, justification, engineerId, engineerName,
engineerCertifications as proper columns. Breaks the generic design.

**Option C: Create ml_prediction_overrides as a separate table**

Keep `engineer_overrides` generic and create a dedicated table for ML
prediction overrides. Cleanest but doubles the table count.

### To proceed

Tell me A / B / C and I'll generate the route or schema fix.

---

## Summary

Both of these are architectural decisions, not bugs. The code and schema
diverged because two different design philosophies met and neither won
cleanly. Pick the direction you want for each and I'll execute.

Meanwhile, wave 2 ships fixes for the 4 top-10 offenders where the right
direction is unambiguous:

| File | Status |
|---|---|
| db-operating-conditions.ts (46 errors) | ✅ Fixed (schema patch + file rewrite) |
| useOperatingParametersData.ts (43 errors) | ⏭ Downstream — will auto-resolve after schema patch |
| ml-governance-routes.ts (38 errors) | ⚠️ Deferred (see above) |
| db-hub-sync.ts (37 errors) | ✅ Fixed (schema patch + file rewrite) |
| settings-service.ts (35 errors) | ⚠️ Deferred (see above) |
| vessel-dashboard.tsx (35 errors) | ⏭ Downstream — UI consumer |
| auth-routes.ts (34 errors) | ✅ Fixed (types.ts patch for Request/Response) |
| db-maintenance-templates.ts (34 errors) | ⏭ Need source file from you |
| useFinanceModeData.ts (33 errors) | ⏭ Downstream — UI consumer |
| db-analytics.ts (32 errors) | ✅ Fixed (schema patch + file rewrite) |

**Wave 2 expected impact:** 46 + 37 + 34 + 32 = **149 errors directly fixed**,
plus likely 50-100 downstream cascade from the schema patches freeing up
derived types in hooks/pages that consume these tables.
