/**
 * ============================================================================
 * PG SCHEMA PARITY — WAVE 2
 * ============================================================================
 *
 * Five more tables where PG schema diverged from what the code expects.
 * In every case I confirmed against both PG and SQLite schemas that:
 *   - the code references columns from the SQLite schema
 *   - the PG schema is missing those columns
 *   - the SQLite columns are the correct model for the feature
 *
 * Tables addressed:
 *   1. equipment_lifecycle — 8 new columns (manufacturer, model, serial_number,
 *      installation_date, expected_lifespan, condition, nextRecommendedReplacement, ...)
 *   2. performance_metrics — 7 new columns (performance_score, reliability,
 *      availability, efficiency, mtbf_hours, mttr_hours, ...)
 *   3. sync_journal — 3 new columns (vessel_id, sync_type, status, updated_at)
 *   4. sync_outbox — 4 new columns (vessel_id, status, priority, updated_at, synced_at)
 *   5. operating_parameters — 2 new columns (equipment_type, manufacturer)
 *
 * Apply the TypeScript changes to shared/schema/*.ts AND run the migration SQL
 * in migrations/NNNN_wave2_schema_parity.sql before deploying.
 * ============================================================================
 */

import {
  pgTable,
  varchar,
  text,
  integer,
  boolean,
  real,
  timestamp,
  index,
  serial,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
// These imports come from the surrounding module:
// - organizations (from schema/core.ts)
// - equipment (from schema/core.ts)

// ============================================================================
// TABLE 1: equipment_lifecycle
// File: shared/schema/equipment.ts
// Current schema treats this as an event log (eventType, eventDate, cost).
// Code treats it as a lifecycle record (install date, expected lifespan,
// condition, next recommended replacement). Bring PG up to parity with SQLite.
// ============================================================================
export const equipmentLifecycle = pgTable(
  "equipment_lifecycle",
  {
    id: varchar("id")
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    orgId: varchar("org_id")
      .notNull()
      .references(() => organizations.id),
    equipmentId: varchar("equipment_id")
      .notNull()
      .references(() => equipment.id),
    // NEW: lifecycle record columns (match SQLite schema, referenced by code):
    manufacturer: text("manufacturer"),
    model: text("model"),
    serialNumber: text("serial_number"),
    installationDate: timestamp("installation_date", { mode: "date" }),
    warrantyExpiry: timestamp("warranty_expiry", { mode: "date" }),
    expectedLifespan: integer("expected_lifespan"), // months
    replacementCost: real("replacement_cost"),
    operatingHours: integer("operating_hours").default(0),
    maintenanceCount: integer("maintenance_count").default(0),
    lastMajorOverhaul: timestamp("last_major_overhaul", { mode: "date" }),
    nextRecommendedReplacement: timestamp("next_recommended_replacement", { mode: "date" }),
    condition: text("condition").notNull().default("good"),
    // EXISTING: keep the event-log columns in case anything still writes them
    eventType: text("event_type"),
    eventDate: timestamp("event_date", { mode: "date" }),
    description: text("description"),
    cost: real("cost"),
    performedBy: text("performed_by"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
    updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    equipmentIdx: index("idx_lifecycle_equipment").on(table.equipmentId),
    orgEquipmentIdx: index("idx_lifecycle_org_equipment").on(table.orgId, table.equipmentId),
  })
);

// ============================================================================
// TABLE 2: performance_metrics
// File: shared/schema/equipment.ts
// Current schema is a generic key-value metric store (metricType, value, unit).
// Code expects columns for specific metric types (performance_score, reliability,
// availability, efficiency, mtbf_hours, mttr_hours, metricDate). Bring PG up to SQLite.
// ============================================================================
export const performanceMetrics = pgTable(
  "performance_metrics",
  {
    id: varchar("id")
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    orgId: varchar("org_id")
      .notNull()
      .references(() => organizations.id),
    equipmentId: varchar("equipment_id")
      .notNull()
      .references(() => equipment.id),
    // NEW: metric-specific columns (match SQLite):
    metricDate: timestamp("metric_date", { mode: "date" }).notNull().defaultNow(),
    performanceScore: real("performance_score"),
    reliability: real("reliability"),
    availability: real("availability"),
    efficiency: real("efficiency"),
    mtbfHours: real("mtbf_hours"),
    mttrHours: real("mttr_hours"),
    totalDowntimeMinutes: integer("total_downtime_minutes"),
    plannedDowntimeMinutes: integer("planned_downtime_minutes"),
    unplannedDowntimeMinutes: integer("unplanned_downtime_minutes"),
    operatingHours: real("operating_hours"),
    energyConsumption: real("energy_consumption"),
    // EXISTING: keep generic columns for backward compatibility
    metricType: text("metric_type"),
    value: real("value"),
    unit: text("unit"),
    recordedAt: timestamp("recorded_at", { mode: "date" }),
    notes: text("notes"),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    equipmentMetricDateIdx: index("idx_perf_equipment_date").on(
      table.equipmentId,
      table.metricDate
    ),
    orgEquipmentIdx: index("idx_perf_org_equipment").on(table.orgId, table.equipmentId),
  })
);

// ============================================================================
// TABLE 3: sync_journal
// File: shared/schema/sync.ts
// PG is missing vesselId, syncType, status, updatedAt — these are needed for
// hub-sync to actually function (vessel-to-cloud sync routing/tracking).
// ============================================================================
export const syncJournal = pgTable(
  "sync_journal",
  {
    id: varchar("id")
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    entityType: text("entity_type").notNull(),
    entityId: varchar("entity_id").notNull(),
    operation: text("operation").notNull(),
    payload: text("payload"), // was jsonb in original — keep flexible
    userId: varchar("user_id").references(() => users.id),
    // NEW: sync routing/tracking columns
    vesselId: varchar("vessel_id").references(() => vessels.id),
    syncType: text("sync_type"), // e.g., "telemetry", "work_order", "inventory"
    status: text("status").notNull().default("pending"), // pending | synced | failed | completed
    syncStatus: text("sync_status").default("pending"), // keep for backward compat
    retryCount: integer("retry_count").notNull().default(0),
    lastError: text("last_error"),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
    updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    entityIndex: index("idx_sync_journal_entity").on(
      table.entityType,
      table.entityId,
      table.createdAt
    ),
    vesselStatusIdx: index("idx_sync_journal_vessel_status").on(table.vesselId, table.status),
  })
);

// ============================================================================
// TABLE 4: sync_outbox
// File: shared/schema/sync.ts
// PG is missing vesselId, status, priority, updatedAt, syncedAt.
// ============================================================================
export const syncOutbox = pgTable(
  "sync_outbox",
  {
    id: varchar("id")
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    eventType: text("event_type").notNull(),
    payload: text("payload"),
    processed: boolean("processed").default(false),
    processingAttempts: integer("processing_attempts").default(0),
    // NEW columns for vessel sync:
    vesselId: varchar("vessel_id").references(() => vessels.id),
    status: text("status").notNull().default("pending"), // pending | synced | failed
    priority: integer("priority").notNull().default(100), // lower number = higher priority
    syncedAt: timestamp("synced_at", { mode: "date" }),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
    processedAt: timestamp("processed_at", { mode: "date" }),
    updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    eventIndex: index("idx_sync_outbox_event").on(table.eventType, table.processed),
    vesselStatusPriorityIdx: index("idx_sync_outbox_vessel_status_priority").on(
      table.vesselId,
      table.status,
      table.priority
    ),
  })
);

// ============================================================================
// TABLE 5: operating_parameters
// File: shared/schema/equipment.ts
// PG schema is minimal; code uses a rich threshold model (critical/optimal
// min/max, parameter type, life impact, recommended action) that exists in
// neither current PG nor SQLite. This is not "drift" — it's a feature the
// code implements (detectViolation in db-operating-conditions.ts) that never
// had schema support. Add the columns.
// ============================================================================
export const operatingParameters = pgTable(
  "operating_parameters",
  {
    id: varchar("id")
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    orgId: varchar("org_id")
      .notNull()
      .references(() => organizations.id),
    equipmentId: varchar("equipment_id")
      .notNull()
      .references(() => equipment.id),
    parameterName: text("parameter_name").notNull(),
    // NEW: filtering columns:
    equipmentType: text("equipment_type"),
    manufacturer: text("manufacturer"),
    parameterType: text("parameter_type"), // matches telemetry.sensorType for correlation
    // NEW: threshold columns (critical = alert, optimal = warning):
    criticalMin: real("critical_min"),
    criticalMax: real("critical_max"),
    optimalMin: real("optimal_min"),
    optimalMax: real("optimal_max"),
    // NEW: context columns:
    lifeImpactDescription: text("life_impact_description"),
    recommendedAction: text("recommended_action"),
    // EXISTING columns:
    minValue: real("min_value"),
    maxValue: real("max_value"),
    optimalValue: real("optimal_value"),
    unit: text("unit"),
    category: text("category"),
    isActive: boolean("is_active").default(true),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
    updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    equipmentIdx: index("idx_operating_parameters_equipment").on(table.equipmentId),
    parameterIdx: index("idx_operating_parameters_name").on(table.parameterName),
    typeManufacturerIdx: index("idx_operating_parameters_type_manufacturer").on(
      table.equipmentType,
      table.manufacturer
    ),
  })
);

// ============================================================================
// TABLE 6: operating_condition_alerts
// File: shared/schema/equipment.ts
// Code uses a `resolved` boolean AND `resolvedAt` timestamp. PG only has
// `resolvedAt`. Also uses `acknowledged` boolean (similar pattern). Add the
// missing boolean columns alongside the timestamps.
// Also: code queries by `createdAt` but table only has `alertedAt` — add
// `createdAt` for conventional query patterns. Also `notes`, `optimalMin`,
// `optimalMax`, `parameterName`, `thresholdType`, `lifeImpact`, `recommendedAction`.
// ============================================================================
export const operatingConditionAlerts = pgTable(
  "operating_condition_alerts",
  {
    id: varchar("id")
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    orgId: varchar("org_id")
      .notNull()
      .references(() => organizations.id),
    equipmentId: varchar("equipment_id")
      .notNull()
      .references(() => equipment.id),
    parameterId: varchar("parameter_id").references(() => operatingParameters.id),
    // NEW: denormalized parameter info for efficient querying:
    parameterName: text("parameter_name"),
    parameterType: text("parameter_type"),
    thresholdType: text("threshold_type"), // below_critical | above_critical | below_optimal | above_optimal
    lifeImpact: text("life_impact"),
    recommendedAction: text("recommended_action"),
    // NEW: boolean status flags alongside existing timestamp columns:
    acknowledged: boolean("acknowledged").default(false),
    resolved: boolean("resolved").default(false),
    // EXISTING + re-purposed timestamp columns:
    alertType: text("alert_type").notNull(),
    severity: text("severity").default("warning"),
    message: text("message"),
    currentValue: real("current_value"),
    thresholdValue: real("threshold_value"),
    optimalMin: real("optimal_min"),
    optimalMax: real("optimal_max"),
    acknowledgedAt: timestamp("acknowledged_at", { mode: "date" }),
    acknowledgedBy: varchar("acknowledged_by"),
    resolvedAt: timestamp("resolved_at", { mode: "date" }),
    notes: text("notes"),
    alertedAt: timestamp("alerted_at", { mode: "date" }).defaultNow(),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    equipmentIdx: index("idx_operating_condition_alerts_equipment").on(table.equipmentId),
    severityIdx: index("idx_operating_condition_alerts_severity").on(table.severity),
    resolvedIdx: index("idx_operating_condition_alerts_resolved").on(
      table.equipmentId,
      table.resolved
    ),
  })
);

// ============================================================================
// TABLE 7: engineer_overrides
// File: shared/schema/telemetry.ts
// Current schema is generic (originalValue: jsonb, reason: text).
// Code uses a PdM-specific workflow schema with risk level transitions,
// engineer credentials, and outcome tracking.
// ============================================================================
export const engineerOverrides = pgTable(
  "engineer_overrides",
  {
    id: varchar("id")
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    orgId: varchar("org_id")
      .notNull()
      .references(() => organizations.id),
    equipmentId: varchar("equipment_id")
      .notNull()
      .references(() => equipment.id),
    // NEW: PdM workflow context
    predictionId: varchar("prediction_id"),
    workOrderId: varchar("work_order_id"),
    originalRiskLevel: text("original_risk_level"),
    newRiskLevel: text("new_risk_level"),
    originalConfidence: real("original_confidence"),
    justification: text("justification"),
    engineerId: varchar("engineer_id"),
    engineerName: text("engineer_name"),
    engineerCertifications: text("engineer_certifications"), // jsonb in SQL but text here for portability
    originalPrediction: text("original_prediction"), // jsonb in SQL
    // NEW: outcome tracking
    outcomeStatus: text("outcome_status"),
    outcomeNotes: text("outcome_notes"),
    outcomeRecordedAt: timestamp("outcome_recorded_at", { mode: "date" }),
    outcomeRecordedBy: varchar("outcome_recorded_by"),
    // EXISTING columns:
    overrideType: text("override_type").notNull(),
    originalValue: text("original_value"),
    overrideValue: text("override_value").notNull(),
    reason: text("reason").notNull(),
    approvedBy: varchar("approved_by"),
    expiresAt: timestamp("expires_at", { mode: "date" }),
    isActive: boolean("is_active").default(true),
    createdBy: varchar("created_by").notNull(),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
    updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    equipmentIdx: index("idx_engineer_overrides_equipment").on(table.equipmentId),
    activeIdx: index("idx_engineer_overrides_active").on(table.isActive),
    engineerIdx: index("idx_engineer_overrides_engineer").on(table.engineerId, table.createdAt),
  })
);

// ============================================================================
// TABLE 8: alert_settings
// File: shared/schema/alerts.ts
// Add missing email/SMTP configuration columns.
// ============================================================================
// ADD these column definitions inside the existing alertSettings pgTable:
//
//   emailEnabled: boolean("email_enabled").default(true),
//   defaultToEmail: text("default_to_email"),
//   ccEmails: text("cc_emails"),
//   bccEmails: text("bcc_emails"),
//   timezone: text("timezone").default("UTC"),
//   provider: text("provider").default("smtp"),
//   smtpHost: text("smtp_host"),
//   smtpPort: integer("smtp_port"),
//   smtpUser: text("smtp_user"),
//   smtpPasswordEncrypted: text("smtp_password_encrypted"),
//   smtpUseTls: boolean("smtp_use_tls").default(true),
//   fromEmail: text("from_email"),
//   fromName: text("from_name"),
//   dailyDigestEnabled: boolean("daily_digest_enabled").default(false),
//   dailyDigestTime: text("daily_digest_time"),
//   lastTestStatus: text("last_test_status"),
//   lastTestAt: timestamp("last_test_at", { mode: "date" }),
//   lastTestError: text("last_test_error"),


/* ============================================================================
 * MIGRATION SQL — migrations/NNNN_wave2_schema_parity.sql
 * ============================================================================

-- equipment_lifecycle: add lifecycle-record columns
ALTER TABLE equipment_lifecycle
  ADD COLUMN IF NOT EXISTS manufacturer TEXT,
  ADD COLUMN IF NOT EXISTS model TEXT,
  ADD COLUMN IF NOT EXISTS serial_number TEXT,
  ADD COLUMN IF NOT EXISTS installation_date TIMESTAMP,
  ADD COLUMN IF NOT EXISTS warranty_expiry TIMESTAMP,
  ADD COLUMN IF NOT EXISTS expected_lifespan INTEGER,
  ADD COLUMN IF NOT EXISTS replacement_cost REAL,
  ADD COLUMN IF NOT EXISTS operating_hours INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS maintenance_count INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_major_overhaul TIMESTAMP,
  ADD COLUMN IF NOT EXISTS next_recommended_replacement TIMESTAMP,
  ADD COLUMN IF NOT EXISTS condition TEXT NOT NULL DEFAULT 'good',
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW();

-- performance_metrics: add specific-metric columns
ALTER TABLE performance_metrics
  ADD COLUMN IF NOT EXISTS metric_date TIMESTAMP DEFAULT NOW() NOT NULL,
  ADD COLUMN IF NOT EXISTS performance_score REAL,
  ADD COLUMN IF NOT EXISTS reliability REAL,
  ADD COLUMN IF NOT EXISTS availability REAL,
  ADD COLUMN IF NOT EXISTS efficiency REAL,
  ADD COLUMN IF NOT EXISTS mtbf_hours REAL,
  ADD COLUMN IF NOT EXISTS mttr_hours REAL,
  ADD COLUMN IF NOT EXISTS total_downtime_minutes INTEGER,
  ADD COLUMN IF NOT EXISTS planned_downtime_minutes INTEGER,
  ADD COLUMN IF NOT EXISTS unplanned_downtime_minutes INTEGER,
  ADD COLUMN IF NOT EXISTS operating_hours REAL,
  ADD COLUMN IF NOT EXISTS energy_consumption REAL;

-- Backfill metric_date from recorded_at if it existed:
UPDATE performance_metrics
SET metric_date = recorded_at
WHERE metric_date IS NULL AND recorded_at IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_perf_equipment_date ON performance_metrics (equipment_id, metric_date);

-- sync_journal: add vessel routing columns
ALTER TABLE sync_journal
  ADD COLUMN IF NOT EXISTS vessel_id VARCHAR,
  ADD COLUMN IF NOT EXISTS sync_type TEXT,
  ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS retry_count INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_error TEXT,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW();

ALTER TABLE sync_journal
  ADD CONSTRAINT IF NOT EXISTS sync_journal_vessel_fk
  FOREIGN KEY (vessel_id) REFERENCES vessels(id);

CREATE INDEX IF NOT EXISTS idx_sync_journal_vessel_status ON sync_journal (vessel_id, status);

-- sync_outbox: add vessel routing and priority
ALTER TABLE sync_outbox
  ADD COLUMN IF NOT EXISTS vessel_id VARCHAR,
  ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS priority INTEGER NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS synced_at TIMESTAMP,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW();

ALTER TABLE sync_outbox
  ADD CONSTRAINT IF NOT EXISTS sync_outbox_vessel_fk
  FOREIGN KEY (vessel_id) REFERENCES vessels(id);

CREATE INDEX IF NOT EXISTS idx_sync_outbox_vessel_status_priority
  ON sync_outbox (vessel_id, status, priority);

-- Backfill status from processed flag:
UPDATE sync_outbox
SET status = CASE WHEN processed = true THEN 'synced' ELSE 'pending' END
WHERE status = 'pending' AND processed IS NOT NULL;

-- operating_parameters: add threshold & context columns
ALTER TABLE operating_parameters
  ADD COLUMN IF NOT EXISTS equipment_type TEXT,
  ADD COLUMN IF NOT EXISTS manufacturer TEXT,
  ADD COLUMN IF NOT EXISTS parameter_type TEXT,
  ADD COLUMN IF NOT EXISTS critical_min REAL,
  ADD COLUMN IF NOT EXISTS critical_max REAL,
  ADD COLUMN IF NOT EXISTS optimal_min REAL,
  ADD COLUMN IF NOT EXISTS optimal_max REAL,
  ADD COLUMN IF NOT EXISTS life_impact_description TEXT,
  ADD COLUMN IF NOT EXISTS recommended_action TEXT;

CREATE INDEX IF NOT EXISTS idx_operating_parameters_type_manufacturer
  ON operating_parameters (equipment_type, manufacturer);

-- operating_condition_alerts: add boolean flags, parameter context, thresholds
ALTER TABLE operating_condition_alerts
  ADD COLUMN IF NOT EXISTS parameter_name TEXT,
  ADD COLUMN IF NOT EXISTS parameter_type TEXT,
  ADD COLUMN IF NOT EXISTS threshold_type TEXT,
  ADD COLUMN IF NOT EXISTS life_impact TEXT,
  ADD COLUMN IF NOT EXISTS recommended_action TEXT,
  ADD COLUMN IF NOT EXISTS acknowledged BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS resolved BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS optimal_min REAL,
  ADD COLUMN IF NOT EXISTS optimal_max REAL,
  ADD COLUMN IF NOT EXISTS notes TEXT,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT NOW();

-- Backfill boolean flags from the timestamp columns:
UPDATE operating_condition_alerts
SET acknowledged = (acknowledged_at IS NOT NULL)
WHERE acknowledged IS NULL OR acknowledged = FALSE;

UPDATE operating_condition_alerts
SET resolved = (resolved_at IS NOT NULL)
WHERE resolved IS NULL OR resolved = FALSE;

CREATE INDEX IF NOT EXISTS idx_operating_condition_alerts_resolved
  ON operating_condition_alerts (equipment_id, resolved);

-- engineer_overrides: add predictive-maintenance workflow columns
ALTER TABLE engineer_overrides
  ADD COLUMN IF NOT EXISTS prediction_id VARCHAR,
  ADD COLUMN IF NOT EXISTS work_order_id VARCHAR,
  ADD COLUMN IF NOT EXISTS original_risk_level TEXT,
  ADD COLUMN IF NOT EXISTS new_risk_level TEXT,
  ADD COLUMN IF NOT EXISTS original_confidence REAL,
  ADD COLUMN IF NOT EXISTS justification TEXT,
  ADD COLUMN IF NOT EXISTS engineer_id VARCHAR,
  ADD COLUMN IF NOT EXISTS engineer_name TEXT,
  ADD COLUMN IF NOT EXISTS engineer_certifications JSONB,
  ADD COLUMN IF NOT EXISTS original_prediction JSONB,
  ADD COLUMN IF NOT EXISTS outcome_status TEXT,
  ADD COLUMN IF NOT EXISTS outcome_notes TEXT,
  ADD COLUMN IF NOT EXISTS outcome_recorded_at TIMESTAMP,
  ADD COLUMN IF NOT EXISTS outcome_recorded_by VARCHAR;

CREATE INDEX IF NOT EXISTS idx_engineer_overrides_engineer
  ON engineer_overrides (engineer_id, created_at);

-- alert_settings: add email & SMTP config columns
ALTER TABLE alert_settings
  ADD COLUMN IF NOT EXISTS email_enabled BOOLEAN DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS default_to_email TEXT,
  ADD COLUMN IF NOT EXISTS cc_emails TEXT,
  ADD COLUMN IF NOT EXISTS bcc_emails TEXT,
  ADD COLUMN IF NOT EXISTS timezone TEXT DEFAULT 'UTC',
  ADD COLUMN IF NOT EXISTS provider TEXT DEFAULT 'smtp',
  ADD COLUMN IF NOT EXISTS smtp_host TEXT,
  ADD COLUMN IF NOT EXISTS smtp_port INTEGER,
  ADD COLUMN IF NOT EXISTS smtp_user TEXT,
  ADD COLUMN IF NOT EXISTS smtp_password_encrypted TEXT,
  ADD COLUMN IF NOT EXISTS smtp_use_tls BOOLEAN DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS from_email TEXT,
  ADD COLUMN IF NOT EXISTS from_name TEXT,
  ADD COLUMN IF NOT EXISTS daily_digest_enabled BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS daily_digest_time TEXT,
  ADD COLUMN IF NOT EXISTS last_test_status TEXT,
  ADD COLUMN IF NOT EXISTS last_test_at TIMESTAMP,
  ADD COLUMN IF NOT EXISTS last_test_error TEXT;

-- Also update the TypeScript engineer_overrides pgTable definition
-- in shared/schema/telemetry.ts (add the equivalent column definitions).
-- Same for shared/schema/alerts.ts for alert_settings.

============================================================================ */
