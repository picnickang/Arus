# ARUS Bug Fix Package — Wave 2

**Baseline going in:** 3,897 TypeScript errors, 337/337 tests passing
(after wave 1 dropped from 4,554 → 3,897).

**Expected going out:** ~3,700 errors (dropping another ~200).

---

## What this wave fixes

### ✅ 4 of the top-10 offenders directly fixed

| File | Errors | Fix type |
|---|---|---|
| `server/db/operating-conditions/db-operating-conditions.ts` | 46 | Schema patch + file rewrite |
| `server/db/hub-sync/db-hub-sync.ts` | 37 | Schema patch + file rewrite |
| `server/domains/system-admin/routes/auth-routes.ts` | 34 | Types.ts patch (Request type) |
| `server/db/analytics/db-analytics.ts` | 32 | Schema patch + file rewrite |
| **Direct total** | **149** | |

### ⏭ Expected cascade from schema additions

The wave 2 schema parity patch adds columns to 6 tables. Many other files
query these tables; their errors were false positives caused by the missing
columns. Expected additional ~50-150 cascade fixes.

### ⚠️ 2 of the top-10 deferred — product decisions required

See `docs/deferred-fixes.md` for:
- `settings-service.ts` — notification_settings schema conflates SMTP config with routing
- `ml-governance-routes.ts` — engineer_overrides uses generic pattern, code expects ML-specific

### ⏭ 1 missing from bug bundle

`server/db/maintenance-templates/db-maintenance-templates.ts` (34 errors) wasn't
in the source bundle. Send the file and I'll fix it next wave.

### ⏭ 3 downstream UI consumers

`useOperatingParametersData.ts`, `vessel-dashboard.tsx`, `useFinanceModeData.ts`
consume data from the fixed backend tables. Most errors will auto-resolve once
the schema patches land. Any remaining errors will reveal themselves on next run.

---

## Package contents

```
shared/schema/
  wave2-parity.patch.ts           ← 6-table schema patch + full migration SQL

server/db/
  operating-conditions/db-operating-conditions.ts  ← DROP-IN REPLACEMENT
  hub-sync/db-hub-sync.ts                          ← DROP-IN REPLACEMENT
  analytics/db-analytics.ts                        ← DROP-IN REPLACEMENT

server/domains/system-admin/routes/
  types.patch.ts                   ← PATCH for Request/Response type confusion

docs/
  deferred-fixes.md                ← Explains the 2 deferred files + options

README.md                          ← This file
```

---

## Application order

### Step 1: Apply the wave 2 schema patch

Open `shared/schema/wave2-parity.patch.ts`. It contains 6 `pgTable` definitions
to replace in:
- `shared/schema/equipment.ts` — `equipmentLifecycle`, `performanceMetrics`,
  `operatingParameters`, `operatingConditionAlerts`
- `shared/schema/sync.ts` — `syncJournal`, `syncOutbox`

Replace each existing `pgTable` definition with the wave 2 version. The wave 2
versions KEEP all existing columns AND add the missing ones — backward-compatible.

Run:
```bash
npm run check 2>&1 | grep -c "error TS"
# Expect: ~3,850 (small drop; most wins come after the SQL migration)
```

### Step 2: Run the SQL migration

The migration SQL is at the bottom of `wave2-parity.patch.ts` inside the block
comment. Copy it to a new file:
```
migrations/NNNN_wave2_schema_parity.sql
```

Apply to **staging first**:
```bash
npm run db:migrate
# or: psql -f migrations/NNNN_wave2_schema_parity.sql $DATABASE_URL
```

Verify with `\d equipment_lifecycle`, `\d performance_metrics`, etc.

The migration uses `ADD COLUMN IF NOT EXISTS` and UPDATE backfills where
possible. Safe to re-run.

### Step 3: Add EntityType members to sync-events.ts

Append to the `EntityType` union:
```ts
| "operating_parameter"
| "operating_condition_alert"
```

Append to the `EventType` union:
```ts
| "operating_parameter.created"
| "operating_parameter.updated"
| "operating_parameter.deleted"
| "operating_condition_alert.created"
| "operating_condition_alert.updated"
| "operating_condition_alert.deleted"
```

### Step 4: Apply the Request type patch

Open `server/domains/system-admin/routes/types.ts` and replace the
Request/Response exports with the block from `types.patch.ts`. This is
the only change needed to fix all 34 errors in `auth-routes.ts`.

### Step 5: Drop in the three rewritten files

```bash
cp fix2/server/db/operating-conditions/db-operating-conditions.ts \
   ../arus/server/db/operating-conditions/db-operating-conditions.ts
cp fix2/server/db/hub-sync/db-hub-sync.ts \
   ../arus/server/db/hub-sync/db-hub-sync.ts
cp fix2/server/db/analytics/db-analytics.ts \
   ../arus/server/db/analytics/db-analytics.ts
```

### Step 6: Verify

```bash
npm run check 2>&1 | grep -c "error TS"
# Expect: ~3,700 (down ~200 from baseline 3,897)

npm run test:unit
# Must stay 337/337

npm run check:guards
# Must stay 5/5 green
```

### Step 7: Hit the API

```bash
# Confirm the changed tables read/write correctly:
curl http://localhost:5000/api/operating-parameters | head -10
curl http://localhost:5000/api/operating-condition-alerts | head -10
curl http://localhost:5000/api/analytics/performance | head -10
curl http://localhost:5000/api/sync/journal?limit=10 | head -10
```

---

## After applying

Send me:
1. New `npm run check 2>&1 | grep -c "error TS"` count
2. New top-10 offenders
3. Your decisions on the 2 deferred files (see `docs/deferred-fixes.md`)
4. Source of `server/db/maintenance-templates/db-maintenance-templates.ts`

I'll take the next pass with that data.
