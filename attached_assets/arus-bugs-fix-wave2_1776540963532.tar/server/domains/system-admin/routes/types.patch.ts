/**
 * ============================================================================
 * PATCH to server/domains/system-admin/routes/types.ts
 * ============================================================================
 *
 * auth-routes.ts imports `Request, Response` from "./types.js" and uses
 * Express-specific properties (req.ip, req.headers.origin, res.json(),
 * res.status()). All 34 errors in auth-routes.ts are caused by `Request`
 * resolving to the **Web Fetch API's Request** (which has only req.headers.get())
 * instead of **Express's Request** (which has req.ip, req.headers.origin, etc.).
 *
 * Root cause: either the types.ts file re-exports `Request` from a source
 * that has both `Request` (Express's) and `Request` (Web Fetch API, built-in
 * via DOM lib) and TypeScript picks the built-in, OR the types.ts file
 * directly imports the wrong Request (e.g., from a fetch/undici module).
 *
 * Fix: re-export Express types explicitly, using type-only imports with
 * the `express` module name to guarantee disambiguation.
 *
 * Search server/domains/system-admin/routes/types.ts for the existing
 * Request/Response exports and REPLACE that block with this.
 * ============================================================================
 */

import type {
  Express as ExpressApp,
  Request as ExpressRequest,
  Response as ExpressResponse,
  NextFunction as ExpressNextFunction,
} from "express";

// Re-export under the same names for drop-in compatibility.
// Using `export type` ensures no runtime import cycle.
export type Express = ExpressApp;
export type Request = ExpressRequest;
export type Response = ExpressResponse;
export type NextFunction = ExpressNextFunction;

// If the original types.ts had other exports (SystemAdminDependencies, etc.),
// keep them as-is. Only the Request/Response exports need to change.

/* ============================================================================
 * EXPECTED IMPACT:
 * - Eliminates all 34 errors in auth-routes.ts
 *   - `req.ip` now resolves (Express extends http.IncomingMessage, which has ip via trust-proxy)
 *   - `req.headers.origin` now resolves (Express headers are IncomingHttpHeaders, not Headers)
 *   - `res.json()`, `res.status()` now resolve (Express Response, not Fetch Response)
 *   - `withErrorHandling` call now matches (handler signature types line up)
 *
 * - Likely eliminates additional errors in any other route file that imports
 *   Request/Response from this same types.ts (search:
 *     grep -l "from \"./types\"" server/domains/system-admin/routes/)
 * ============================================================================ */
