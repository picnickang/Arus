/**
 * ============================================================================
 * PATCH to shared/schema/maintenance.ts
 * ============================================================================
 *
 * Bring PG schema to parity with SQLite. The code in db-checklists.ts was
 * written against the richer SQLite schema which has: stepNumber, title,
 * category, itemId, status, passed, actualValue, photoUrls, completedByName.
 *
 * These columns do not exist in the current PG schema, causing 80+ TS errors
 * in db-checklists.ts alone.
 *
 * Apply this patch by REPLACING the existing maintenanceChecklistItems and
 * maintenanceChecklistCompletions exports in shared/schema/maintenance.ts.
 *
 * Also run the migration SQL below before deploying.
 * ============================================================================
 */

import { pgTable, varchar, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
// NOTE: organizations and maintenanceTemplates imports come from the surrounding module;
// this patch is meant to be inlined, not imported separately.

// REPLACE existing maintenanceChecklistItems with this:
export const maintenanceChecklistItems = pgTable("maintenance_checklist_items", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  templateId: varchar("template_id")
    .notNull()
    .references(() => maintenanceTemplates.id),
  // NEW columns (match SQLite schema, referenced by db-checklists.ts):
  stepNumber: integer("step_number").notNull().default(0),
  title: text("title").notNull().default(""),
  category: text("category"),
  imageUrl: text("image_url"),
  safetyWarning: text("safety_warning"),
  expectedResult: text("expected_result"),
  acceptanceCriteria: text("acceptance_criteria"),
  // Existing columns:
  description: text("description").notNull(),
  sortOrder: integer("sort_order").default(0),
  isRequired: boolean("is_required").default(true),
  estimatedMinutes: integer("estimated_minutes"),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
});

// REPLACE existing maintenanceChecklistCompletions with this:
export const maintenanceChecklistCompletions = pgTable("maintenance_checklist_completions", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  orgId: varchar("org_id")
    .notNull()
    .references(() => organizations.id),
  workOrderId: varchar("work_order_id").notNull(),
  // NEW: code uses itemId (from SQLite schema) - keep both for compatibility:
  itemId: varchar("item_id"), // code references this
  checklistItemId: varchar("checklist_item_id") // original column, keep for legacy queries
    .references(() => maintenanceChecklistItems.id),
  // NEW columns (match SQLite schema):
  status: text("status").notNull().default("pending"),
  passed: boolean("passed"),
  actualValue: text("actual_value"),
  photoUrls: text("photo_urls").array(),
  completedByName: text("completed_by_name"),
  // Existing columns:
  isCompleted: boolean("is_completed").default(false),
  completedBy: text("completed_by"),
  completedAt: timestamp("completed_at", { mode: "date" }),
  notes: text("notes"),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
});

/* ============================================================================
 * MIGRATION SQL — run before deploying the schema patch
 * Save as: migrations/NNNN_checklist_schema_parity.sql
 * ============================================================================

ALTER TABLE maintenance_checklist_items
  ADD COLUMN IF NOT EXISTS step_number INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS title TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS category TEXT,
  ADD COLUMN IF NOT EXISTS image_url TEXT,
  ADD COLUMN IF NOT EXISTS safety_warning TEXT,
  ADD COLUMN IF NOT EXISTS expected_result TEXT,
  ADD COLUMN IF NOT EXISTS acceptance_criteria TEXT;

-- Backfill step_number from sort_order where possible:
UPDATE maintenance_checklist_items
SET step_number = COALESCE(sort_order, 0)
WHERE step_number = 0;

-- Backfill title from description (truncated) where title is empty:
UPDATE maintenance_checklist_items
SET title = LEFT(description, 100)
WHERE title = '' AND description IS NOT NULL;

ALTER TABLE maintenance_checklist_completions
  ADD COLUMN IF NOT EXISTS item_id VARCHAR,
  ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS passed BOOLEAN,
  ADD COLUMN IF NOT EXISTS actual_value TEXT,
  ADD COLUMN IF NOT EXISTS photo_urls TEXT[],
  ADD COLUMN IF NOT EXISTS completed_by_name TEXT;

-- Migrate data: copy checklist_item_id to item_id if populated:
UPDATE maintenance_checklist_completions
SET item_id = checklist_item_id
WHERE item_id IS NULL AND checklist_item_id IS NOT NULL;

-- Map is_completed to status for backfill:
UPDATE maintenance_checklist_completions
SET status = CASE
  WHEN is_completed = true THEN 'completed'
  ELSE 'pending'
END
WHERE status = 'pending' AND is_completed IS NOT NULL;

============================================================================ */
