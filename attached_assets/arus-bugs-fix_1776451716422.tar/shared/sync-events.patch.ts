/**
 * ============================================================================
 * PATCH to shared/sync-events.ts (or wherever EntityType/EventType are defined)
 * ============================================================================
 *
 * Add maintenance-related entity and event types so db-checklists.ts can
 * pass them to recordAndPublish without casts.
 *
 * Apply by ADDING these members to the existing EntityType and EventType unions.
 * ============================================================================
 */

// Add to EntityType union (extend the existing union):
export type EntityType =
  | "vessel"
  | "crew"
  | "crew_assignment"
  | "sensor"
  | "part"
  | "stock"
  | "supplier"
  | "substitution"
  | "work_order"
  | "schedule"
  | "rest_log"
  | "parts_inventory"
  | "inventory_movement"
  | "equipment"
  | "sync"
  // NEW entity types:
  | "maintenance_template"
  | "maintenance_checklist_item"
  | "maintenance_checklist_completion";

// Add to EventType union:
export type EventType =
  // ... existing entries ...
  | "maintenance_template.created"
  | "maintenance_template.updated"
  | "maintenance_template.deleted"
  | "maintenance_checklist_item.created"
  | "maintenance_checklist_item.updated"
  | "maintenance_checklist_item.deleted"
  | "maintenance_checklist_completion.created"
  | "maintenance_checklist_completion.updated"
  | "maintenance_checklist_completion.deleted";

// No other changes needed — the recordAndPublish function already
// auto-derives eventType from entityType + operation using the pattern:
//   `${entityType}.${operation === 'create' ? 'created' : ...}`
// So once these EntityType members exist, the derived events will type-check.
