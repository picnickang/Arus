# ARUS Bug Fix Package

**Baseline:** 4,554 TypeScript errors, 337/337 runtime tests passing.

This package delivers **high-confidence fixes** for the structural root causes.
Most errors cascade from 3 upstream issues; fixing those collapses the error count
without breaking runtime behavior.

## Expected impact after applying this package

| Fix | Files changed | Est. errors eliminated |
|---|---|---|
| schema-runtime.ts type casts | 1 | **~800** (false positives on columns PG has) |
| db-config.ts `db` proxy type | 1 | **~150** (transaction callback `tx: unknown` cascade) |
| maintenance.ts PG schema parity | 1 | **~80** (checklist tables) |
| sync-events.ts EntityType union | 1 | **~20** (EventType casts can be removed) |
| route-utils.ts generic `withErrorHandling` | 1 | **~160** (logbook routes `req: unknown`) |
| db-checklists.ts rewrite | 1 | **~54** (recordAndPublish + checklist columns) |
| db/inventory/index.ts rewrite | 1 | **~52** (recordAndPublish + tx typing) |
| Codemod: 16 property renames × 7 files | 7 | **~16** direct + ~100 cascade |
| **Total** | **~14 files** | **~1,300** errors eliminated |

Remaining ~3,250 errors will mostly cascade-resolve once the root causes above are fixed.
Some clusters (real UI/API drift, genuine schema drift beyond checklists) need case-by-case work.

---

## Root cause diagnosis

### Root cause #1: `schema-runtime.ts` ternary type narrowing (BIG ONE)

The file has 200 lines like this:
```ts
export const parts = isLocalMode ? sqliteVessel.partsSqlite : pgSchema.parts;
```

TypeScript infers the type as the **intersection** of the SQLite and PG table types.
Since the two schemas have diverged, the intersection includes only the common columns.
Every time code references a column that exists in only one schema (even if the
PG schema has it and PG is what's deployed), the compiler reports "Property X does not exist".

**Fix:** cast the ternary to `typeof pgSchema.<table>`:
```ts
export const parts = (isLocalMode ? sqliteVessel.partsSqlite : pgSchema.parts) as typeof pgSchema.parts;
```

This is applied to all 200 mode-aware exports. Runtime behavior is identical (the
ternary still chooses correctly at runtime); only the compile-time type changes.

**Verified examples:** The `parts` table actually HAS `partNo` in PG. The `cost_savings`
table HAS `workOrderId`, `totalSavings`, `calculatedAt`, `validationStatus`. The
`alert_notifications` table HAS both `acknowledged` AND `acknowledgedAt`. The
`user_sessions` table HAS `isRevoked` and `refreshToken`. All of these were being
hidden by the intersection type.

### Root cause #2: `db` is typed as `any`

`db` is `new Proxy({} as any, {...})`. The Proxy preserves runtime semantics but
gives TypeScript no type information. This cascades:
- `typeof db` is `any`
- `typeof db.transaction` is `any`
- `Parameters<any>` is `unknown[]`
- `Parameters<any>[0]` is `unknown`
- `Parameters<Parameters<typeof db.transaction>[0]>[0]` is `unknown`
- which fails constraints like `(...args: any) => any`

**Fix:** cast the Proxy to `ReturnType<typeof drizzlePgWs<typeof schema>>` in
`db-config.ts`. Export a `DbTransaction` type helper so repositories don't need
the nested `Parameters<Parameters<...>[0]>[0]` pattern.

### Root cause #3: `withErrorHandling` erases the Request type

The current wrapper accepts `(req: Request, res: Response) => Promise<void>` but
loses the Request type, so inside handlers `req` becomes `unknown`. This cascades
to ~160 TS18046 errors in the 4 logbook route files.

**Fix:** make `withErrorHandling<TReq extends Request = AuthenticatedRequest>`
generic. The default type parameter preserves the project's augmented Request type
(with `orgId`, `user`, etc.) without requiring changes in route files.

### Root cause #4: PG schema drift on checklist tables

Two tables (`maintenance_checklist_items`, `maintenance_checklist_completions`)
were simplified in PG but the code still references the richer SQLite schema's
columns. This is REAL schema drift — not a TypeScript false positive.

**Fix:** migration SQL + schema update adding the 13 missing columns to PG:
- `maintenance_checklist_items`: `step_number`, `title`, `category`, `image_url`,
  `safety_warning`, `expected_result`, `acceptance_criteria`
- `maintenance_checklist_completions`: `item_id`, `status`, `passed`, `actual_value`,
  `photo_urls`, `completed_by_name`

### Root cause #5: stale `recordAndPublish` signature

The function was refactored to `(entityType, entityId, operation, data, userId?)`
but ~106 call sites still pass the old shape: `await recordAndPublish(db.insert(...).returning(), "x", "create")`.
These code paths return `Promise<void>` but the caller destructures `[n]` from it
(type error) and treats the response as a `Part[]` (more errors).

**Fix:** rewrite the two worst-offender files (`db-checklists.ts`, `db-inventory/index.ts`)
with the new call pattern.

---

## Package contents

```
shared/
  schema-runtime.ts                 ← DROP-IN REPLACEMENT (200 cast fixes)
  schema/maintenance.patch.ts       ← INSTRUCTIONS for updating maintenance.ts
  sync-events.patch.ts              ← INSTRUCTIONS for EntityType/EventType unions

server/
  db-config.patch.ts                ← INSTRUCTIONS for typing the db proxy
  lib/route-utils.patch.ts          ← INSTRUCTIONS for generic withErrorHandling
  db/checklists/db-checklists.ts    ← DROP-IN REPLACEMENT (full rewrite)
  db/inventory/index.ts             ← DROP-IN REPLACEMENT (full rewrite)

scripts/
  apply-rename-codemod.mjs          ← automated property-access renames (16 pairs)

docs/
  (this README)
```

Files marked **DROP-IN REPLACEMENT** can be copied directly over the existing files.
Files marked **INSTRUCTIONS** are patches explaining what to change in existing files.

---

## Application order

Do these in order. Each step is independent and verifiable.

### Step 1: Apply `schema-runtime.ts` (biggest win)

```bash
cp shared/schema-runtime.ts ../arus/shared/schema-runtime.ts
npm run check 2>&1 | grep -c "error TS"
# Expect: ~3,700 errors (down from 4,554)
npm run test:unit
# Expect: still 337/337 passing
```

### Step 2: Apply `db-config.ts` patch

Open the patch file and replace lines 295-327 of `server/db-config.ts` with the
block in `server/db-config.patch.ts`. Also export `DbTransaction`.

```bash
npm run check 2>&1 | grep -c "error TS"
# Expect: ~3,500 errors
```

### Step 3: Apply `route-utils.ts` patch

Replace the `withErrorHandling` export in `server/lib/route-utils.ts` with the
generic version from `route-utils.patch.ts`.

```bash
npm run check 2>&1 | grep -c "error TS"
# Expect: ~3,300 errors (logbook cluster gone)
```

### Step 4: Apply `sync-events.ts` patch

Extend the `EntityType` and `EventType` unions with the maintenance members listed
in `shared/sync-events.patch.ts`.

### Step 5: Drop in the two rewritten files

```bash
cp server/db/checklists/db-checklists.ts ../arus/server/db/checklists/db-checklists.ts
cp server/db/inventory/index.ts ../arus/server/db/inventory/index.ts
npm run check 2>&1 | grep -c "error TS"
# Expect: ~3,200 errors
```

### Step 6: Apply the schema migration (requires DB access)

1. Apply the migration SQL from `shared/schema/maintenance.patch.ts` comments to a
   new migration file: `migrations/NNNN_checklist_schema_parity.sql`
2. Update `shared/schema/maintenance.ts` with the new column definitions
3. Run `npm run db:migrate` (or your equivalent) on staging first
4. Verify the ADD COLUMN IF NOT EXISTS statements applied cleanly

### Step 7: Run the rename codemod

```bash
# Dry-run first
node scripts/apply-rename-codemod.mjs
# Review the output, then:
node scripts/apply-rename-codemod.mjs --apply
npm run check 2>&1 | grep -c "error TS"
# Expect: ~3,100 errors
```

### Step 8: Manual review (the honest part)

The codemod deliberately does NOT apply 14 pairs flagged as "manual review".
These are renames where:
- The TypeScript hint is likely misleading (e.g., `deleteInventoryItem → createInventoryItem`
  is almost certainly wrong — TS is just matching on string distance)
- The rename involves a bare identifier (e.g., `conditions`, `vessel`, `roles`)
  that is almost always a local variable name
- The rename has semantic implications (unit changes, timestamp→user attribution)

Review each site individually. See the NOT APPLIED section in the codemod output.

---

## Verifying nothing broke

After each step:

```bash
npm run check                # TS error count should only decrease
npm run test:unit            # must stay at 337/337
npm run check:guards         # 5/5 green
# Smoke test live API:
curl http://localhost:5000/api/vessels | head -50
curl http://localhost:5000/api/work-orders | head -50
curl http://localhost:5000/api/parts | head -50
```

If `test:unit` drops below 337/337, roll back the last step and debug.
The schema-runtime and db-config changes are zero-risk (runtime unchanged,
only types changed). The checklist schema migration is the highest-risk step
because it modifies PG tables — apply to staging first.

---

## What this package does NOT fix

**~3,250 errors remaining** after applying everything above. These fall into
clusters that need case-by-case work I can't do from static analysis:

1. **~418 Drizzle column-drift errors on tables other than the checklist ones.**
   Example: `immutable_audit_trail.eventTimestamp` doesn't exist, but I don't
   have your PG schema to know whether it should be `eventAt` or `timestamp` or
   `createdAt`. Need `\d immutable_audit_trail` output.

2. **~150 UI/API shape drift.** Client hooks reference fields the server doesn't
   return. Fix requires per-field decision: extend server response type, or change
   the UI. I can do these one-by-one with the file contents but not in bulk.

3. **~150 TanStack Query v5 overload failures.** Likely a single fix somewhere
   in `queryClient.ts` or a type helper. Requires seeing the actual `useQuery<T>`
   call sites to diagnose.

4. **~551 implicit-any parameter errors.** Most will cascade-resolve once the
   source arrays become properly typed (which happens after fixing #1 and #2).
   Whatever remains needs per-site inspection.

---

## Send me when you've applied this package

- Updated `npm run check 2>&1 | grep "error TS" | wc -l` count
- Any files that refuse to drop in cleanly (likely merge conflicts with recent changes)
- The top 10 offending files from the new error list

I'll iterate from there on cluster-by-cluster basis with your actual schema data.
