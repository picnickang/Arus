/**
 * ============================================================================
 * PATCH to server/lib/route-utils.ts
 * ============================================================================
 *
 * The `withErrorHandling` wrapper currently types `req` as `unknown`,
 * which causes ~160 TS18046 errors across the 4 logbook route files
 * (every `req.orgId`, `req.params.id`, `req.query.X`, `req.body` access
 * reports "req is of type 'unknown'").
 *
 * The signature mismatch error is:
 *   (req: unknown, res: Response) => Promise<Response | undefined>
 *     is not assignable to parameter of type
 *   (req: unknown, res: Response) => Promise<void>
 *
 * Fix: make withErrorHandling generic over the Request type (defaulting to
 * the project's AuthenticatedRequest which has orgId), and accept handlers
 * that return either void or a Response object.
 *
 * FIND the existing withErrorHandling export in route-utils.ts and REPLACE it
 * with this implementation (adjust imports to match existing file):
 * ============================================================================
 */

import type { Request, Response, NextFunction, RequestHandler } from "express";

// The project's augmented Request type with orgId, user, etc.
// If your codebase names this something different (e.g., AuthedRequest),
// adjust the default generic parameter accordingly.
export interface AuthenticatedRequest extends Request {
  orgId: string;
  user?: {
    id: string;
    email: string;
    role: string;
    [key: string]: unknown;
  };
}

/**
 * Wrap an async route handler with consistent error handling.
 *
 * @param operation - Human-readable operation name for error logs
 * @param handler   - Async handler receiving typed req and res
 *
 * Generic over TReq so that callers keep full Request typing including
 * augmentations like orgId. Handler may return void or a Response (for
 * patterns like `return res.status(404).json(...)`).
 */
export function withErrorHandling<TReq extends Request = AuthenticatedRequest>(
  operation: string,
  handler: (req: TReq, res: Response) => Promise<void | Response>
): RequestHandler {
  return async (req, res, next) => {
    try {
      await handler(req as TReq, res);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      console.error(`[${operation}] failed:`, err);
      if (!res.headersSent) {
        res.status(500).json({
          error: "Internal server error",
          operation,
          message,
        });
      } else {
        next(err);
      }
    }
  };
}

/**
 * 404 helper
 */
export function sendNotFound(res: Response, entity: string, id?: string): Response {
  return res.status(404).json({
    error: "Not found",
    entity,
    id,
  });
}

/**
 * 201 Created helper
 */
export function sendCreated<T>(res: Response, data: T): Response {
  return res.status(201).json(data);
}

/**
 * 204 No Content helper for successful deletes
 */
export function sendDeleted(res: Response): Response {
  return res.status(204).send();
}

/* ============================================================================
 * EXPECTED IMPACT:
 * - Eliminates ~160 TS18046 errors across the 4 logbook route files
 *   (engine-log-entries, engine-log-daily, deck-log-entries, deck-log-daily)
 * - Eliminates ~60 additional TS2345 errors from the signature mismatch
 *   (Promise<Response | undefined> vs Promise<void>)
 *
 * NO changes needed in the route files themselves after this patch —
 * the compiler will correctly infer `req: AuthenticatedRequest` from the
 * default type parameter.
 *
 * If a specific route needs a different Request type (e.g., admin routes
 * using AdminAuthenticatedRequest), pass it as an explicit generic:
 *
 *   withErrorHandling<AdminRequest>("operation", async (req, res) => { ... })
 * ============================================================================
 */
