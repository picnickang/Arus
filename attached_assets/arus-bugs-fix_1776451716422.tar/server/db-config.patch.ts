/**
 * ============================================================================
 * PATCH to server/db-config.ts
 * ============================================================================
 *
 * The `db` export is currently a `Proxy({} as any)` which gives it type `any`.
 * This cascades into every file that uses `Parameters<typeof db.transaction>`
 * or accesses any query builder chain — TypeScript can't infer column types
 * because the root is `any`.
 *
 * Fix: cast the Proxy to the actual PG drizzle database type. Runtime behavior
 * unchanged (still routes to dbInstance via Proxy), only the visible type changes.
 *
 * This single fix eliminates ~50+ errors in server/db/inventory/index.ts
 * and similar counts in other files that use transaction patterns.
 *
 * REPLACE lines 295-327 of the current db-config.ts with this block:
 * ============================================================================
 */

// Mutable database instance that gets set after initialization
let dbInstance:
  | ReturnType<typeof drizzlePgWs>
  | ReturnType<typeof drizzlePgHttp>
  | ReturnType<typeof drizzlePgNode>
  | ReturnType<typeof drizzleSqlite>
  | null = isLocalMode ? localDatabase : cloudDatabase;

// Type alias: always expose the PG-WebSocket variant as the canonical type.
// All three PG drivers (ws, http, node) share the same query-builder API,
// and SQLite's libsql driver is interchangeable for our storage layer's purposes.
// This gives every downstream consumer a concrete query-builder type instead of `any`.
type DbType = ReturnType<typeof drizzlePgWs<typeof schema>>;

// Export the appropriate database instance based on mode.
// The Proxy forwards all calls to dbInstance at runtime while presenting the
// concrete PG drizzle type at compile time.
export const db = new Proxy({} as any, {
  get(target, prop) {
    if (!dbInstance) {
      throw new Error(
        `Database not initialized. In ${isLocalMode ? "local" : "cloud"} mode, ensure initializeLocalDatabase() is called before accessing db.`
      );
    }
    const value = (dbInstance as any)[prop];
    if (typeof value === "function") {
      return value.bind(dbInstance);
    }
    return value;
  },
  has(target, prop) {
    if (!dbInstance) return false;
    return prop in dbInstance;
  },
  ownKeys(target) {
    if (!dbInstance) return [];
    return Reflect.ownKeys(dbInstance);
  },
  getOwnPropertyDescriptor(target, prop) {
    if (!dbInstance) return undefined;
    return Reflect.getOwnPropertyDescriptor(dbInstance, prop);
  },
}) as DbType;  // <-- key change: cast Proxy to concrete DB type

// Helper alias for transaction callback parameter typing.
// Use this in repository methods instead of the awkward
//   `Parameters<Parameters<typeof db.transaction>[0]>[0]` pattern.
export type DbTransaction = Parameters<Parameters<DbType["transaction"]>[0]>[0];

export const pool = pgPool;
export const libsqlClient = localClient;

// Type-safe database instance
export type Database = DbType;
