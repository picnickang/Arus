# Logistics Improvements — Deployment Instructions

## Step 1: Run the database migration FIRST

Before deploying any code changes, run the migration SQL:

```bash
psql $DATABASE_URL -f server/migrations/001_sequences_and_indexes.sql
```

This migration:
- Creates PostgreSQL sequences for PR, PO, and SO number generation (improvement #3)
- Adds `rejected_quantity` and `rejection_reason` columns to `purchase_order_items` (#6)
- Adds `revised_amount`, `revision_notes`, `revised_at` to `service_orders` (#8)
- Creates performance indexes for low-stock queries and inventory movements

If you cannot run raw SQL migrations, apply each ALTER TABLE statement manually
via your ORM migration tool before deploying.

---

## Step 2: Copy files to their destinations

```
server/migrations/001_sequences_and_indexes.sql  → server/migrations/

server/purchasing/repository.ts                  → server/purchasing/repository.ts
server/purchasing/pr-draft-service.ts            → server/purchasing/pr-draft-service.ts
server/purchasing/pr-send-service.ts             → server/purchasing/pr-send-service.ts
server/purchasing/pr-routes.ts                   → server/purchasing/pr-routes.ts
server/purchasing/po-routes.ts                   → server/purchasing/po-routes.ts
server/purchasing/email-worker.ts                → server/purchasing/email-worker.ts (NEW FILE)

server/service-orders/routes.ts                  → server/service-orders/routes.ts
server/service-orders/repository.ts              → server/service-orders/repository.ts

server/db/inventory/index.ts                     → server/db/inventory/index.ts

server/domains/inventory/interfaces/routes.ts    → server/domains/inventory/interfaces/routes.ts

client/src/pages/inventory-management.tsx        → client/src/pages/inventory-management.tsx
client/src/pages/logistics-hub.tsx               → client/src/pages/logistics-hub.tsx

client/src/features/purchasing/components/
  POProgressBar.tsx                              → (NEW FILE)
  usePRAutoSave.tsx                              → (NEW FILE)

client/src/features/serviceOrders/components/
  ServiceOrderCalendar.tsx                       → (NEW FILE)

client/src/components/inventory/
  LowStockReplenishmentPanel.tsx                 → (NEW FILE)
```

---

## Step 3: Start the email worker

In your server entry point (e.g. `server/index.ts`), add:

```typescript
import { startEmailWorker, stopEmailWorker } from "./purchasing/email-worker";

// After DB connection is ready:
startEmailWorker();

// On graceful shutdown:
process.on("SIGTERM", () => {
  stopEmailWorker();
  // ... rest of shutdown
});
```

Set these environment variables for email to work:
```
SMTP_HOST=your-smtp-host
SMTP_PORT=587
SMTP_USER=your-smtp-user
SMTP_PASS=your-smtp-password
SMTP_FROM=noreply@yourcompany.com
```

---

## Step 4: Add the new API endpoint to your inventory service

The paginated inventory endpoint calls `inventoryService.listPartsInventoryPaginated()`.
Verify this method exists on your InventoryService. If it doesn't, add:

```typescript
async listPartsInventoryPaginated(orgId: string, options: {
  limit?: number; offset?: number; search?: string; category?: string;
  criticality?: string; stockStatus?: string; supplier?: string;
  sortBy?: string; sortOrder?: "asc" | "desc";
}): Promise<{ items: any[]; total: number }> {
  return this.storage.getPartsInventoryPaginated(orgId, options);
}
```

Also add `getLowStockParts` if missing:
```typescript
async getLowStockParts(orgId: string) {
  return this.storage.getLowStockParts(orgId);
}
```

---

## Step 5: One breaking change — releasePartsFromWorkOrder

The signature changed from:
```typescript
releasePartsFromWorkOrder(workOrderId: string)
```
to:
```typescript
releasePartsFromWorkOrder(workOrderId: string, orgId: string)
```

Search for all callers in your codebase and add the `orgId` argument.

---

## What each improvement does

| # | File(s) | What it does |
|---|---------|-------------|
| 1 | `interfaces/routes.ts` | Server-side pagination for inventory — no longer loads full catalog |
| 2 | `db/inventory/index.ts` | Inventory movement log for reserve/release operations |
| 3 | `repository.ts`, `pr-send-service.ts`, `service-orders/repository.ts`, migration | PostgreSQL sequences for PR/PO/SO numbers — no race conditions |
| 4 | `email-worker.ts` | Email queue worker with retry, exponential backoff, dead-letter handling |
| 6 | `po-routes.ts`, migration | Partial rejection flow on PO items |
| 7 | `LowStockReplenishmentPanel.tsx`, `inventory-management.tsx`, `interfaces/routes.ts` | Low stock → Create PR shortcut |
| 8 | `service-orders/routes.ts`, migration | Cost revision (change order) endpoint for in-progress SOs |
| 9 | `pr-draft-service.ts` | Substitution suggestions when added part is out of stock |
| 10 | `po-routes.ts` | PO receipt → PR fulfillment bulk trigger |
| 13 | `pr-draft-service.ts` | ROB snapshot from partsInventory (stock) not parts (catalog) |
| 14 | `usePRAutoSave.tsx`, `pr-routes.ts` | PR draft auto-save every 30s of inactivity |
| 15 | `POProgressBar.tsx` | PO delivery progress bar component for list view |
| 16 | `ServiceOrderCalendar.tsx` | Calendar view of scheduled service orders |
| 17 | `logistics-hub.tsx` | "Vendors & Providers" label clarification |
| 18 | `pr-routes.ts` | DELETE PR fetches once instead of twice |
| 19 | `po-routes.ts` | PATCH endpoint to update quoted unit price on PO items |
| 20 | `service-orders/routes.ts` | sanitize() maps "" → null so fields can be cleared |
