# TS Error Cleanup — Wave 4

**Starting point:** 2,732 errors across 545 files (355K LOC).
**This wave:** 49 files modified, 1 new file.
**Estimated impact:** ~120–160 errors removed once `tsc` re-runs.

The exact post-wave count needs `npm run typecheck` on Replit since I can't
run `tsc` in this sandbox. Numbers below are the count of error lines I
believe each change addresses based on the input error file.

## What changed

### Foundation — new ambient types & re-exports

| File | What |
|---|---|
| `client/src/types/speech.d.ts` (NEW) | Ambient declarations for `SpeechRecognition`, `SpeechRecognitionEvent`, `SpeechRecognitionErrorEvent`, `SpeechGrammarList`, and `BeforeInstallPromptEvent`. Adds `Window.SpeechRecognition` / `webkitSpeechRecognition`. Fixes the 3 errors in `AgentChatPanel` and 1 in `main.tsx`. |
| `client/src/features/ml-ai/types.ts` | Added `ReportType`, `AudienceType`, `LlmModelType`, `AIModel`, `Audience`, `GeneratedReport`, `VesselIntelligence`, `MlModelDisplay`. Kept the existing `ModelType` for ML algorithm names to avoid breaking other consumers. |
| `client/src/features/maintenance/types.ts` | Re-exports `TemplateFormData`, `ChecklistItemFormData`, `PdmAlert`, `PdmBaseline`, `AnalysisResult`, `BearingFormData`, `PumpFormData` from `./lib/*Utils` so hooks importing from `../types` resolve. |
| `client/src/features/analytics/hooks/useMaintenanceModeData.ts` | Exported the private `WorkOrderData` and `PdmScoreData` interfaces and extended `WorkOrderData` with `reason`, `description`, `equipmentId`, `equipmentName`. |
| `client/src/features/work-orders/hooks/useWorkOrderTasksTabData.ts` | Exported `ChecklistItem`; added `WorkOrderTask` alias. |
| `client/src/components/SyncAdmin.tsx` | Local `SyncMetrics` type (server returns `Record<string, unknown>`). |
| `server/purchasing/types.ts` | Added `EmailQueue`, `InsertEmailQueue` to the `@shared/schema` import. |
| `client/src/features/purchaseRequests/hooks/usePurchaseRequests.ts` | Typed `useCreatePR` with a new exported `PurchaseRequestRecord` interface — eliminates 6 `pr is of type unknown` errors across inventory components. |

### Generic API helper

`client/src/lib/admin-api.ts` — `adminApiRequest` is now generic
(`adminApiRequest<T = unknown>`). Callers can pass a type argument to narrow
the response. Three sites updated in this wave:

- `ThresholdCalibratorCard.tsx` (9 errors closed)
- `VesselSimulatorCard.tsx` (7 errors closed, plus the `SetStateAction<VesselType[]>` mismatch at L64)

### Renamed imports (LLM-vs-ML-algorithm `ModelType` collision)

`useAiInsightsData.ts` and `ReportsTab.tsx` now import `LlmModelType` for the
LLM-model-name use case (`"gpt-4o"`, `"claude-..."`, etc.) so they don't
collide with the algorithm `ModelType` (`"lstm" | "xgboost" | ...`).
Resolves the TS2345 at `useAiInsightsData.ts:42`.

### Real bug fixes (not just typing)

- `server/routes/equipment-context/summary-handler.ts` — 4 `catch {}` blocks
  reference `e` but had no parameter. Restored `catch (e)`. (12 errors closed)
- `server/backup-recovery/status.ts` — same pattern: `catch {}` references
  `error`. Restored `catch (error)` and tightened the template literal
  formatter. (1 error closed)
- `server/services/data-reconciliation/validators.ts` — same pattern,
  restored `catch (error)`. (2 errors closed)
- `server/services/rag/security/file-validator.ts` — `ext` was scoped inside
  an `if (sanitized.length > 200)` block but referenced outside it on the
  next `if`. Hoisted the `const ext` to outer scope. (1 error closed)
- `client/src/features/work-orders/hooks/useWorkOrderFilterData.ts` — file
  used `STATUS_OPTIONS` / `PRIORITY_OPTIONS` locally but only re-exported
  them; `export { X as Y }` does **not** create a local binding. Added
  local `const` aliases. (2 errors closed)

### Mechanical typing sweeps

**TS7006 (implicit any) — closed 18 of the 50:**

- `MaintenanceMode.tsx` (2): wo/score now `WorkOrderData` / `PdmScoreData`
- `pdm-equipment-detail.tsx` (2): anomaly/wo annotated inline
- `useFinanceModeData.ts` (1): trend
- `useDataIntegrityData.ts` (1): source: string
- `useOrganizationData.ts` (2): `useQuery<Organization[]>`, `useQuery<User[]>`
- `useStorageSettings.ts` (2): annotated onSuccess params
- `useEquipmentViewData.ts` (1): error: unknown
- `useVesselManagementData.ts` (1): data: unknown
- `useWorkOrderFilterData.ts` (2): s/p in find lambdas
- `acoustic-monitoring/analyzer.ts` (2): reduce(min, mag)
- `beast/trends-routes.ts` (3): c (correlation)
- `beast/weibull-routes.ts` (1): pred
- `crew/certification-routes.ts` (1): cert
- `crew/document-routes.ts` (1): doc
- `enhanced-llm/context-enrichment.ts` (2): snippet/index
- `enhanced-trends/index.ts` (1): reading
- `insights-engine/compute-fleet-kpi.ts` (1): s.trim()
- `ml-routes/acoustic-routes.ts` (2): reduce(sum, val)
- `ml-routes/model-routes.ts` (3): history.map(h), sort(a, b)
- `objectStorage.ts` (1): stream err: Error

**TS18046 (unknown narrowing) — closed ~20 of the 69:**

- `ThresholdCalibratorCard.tsx` (9), `VesselSimulatorCard.tsx` (7),
  `useAiInsightsData.ts` (5 via typed apiRequest), inventory `pr` cluster (6
  via typed `useCreatePR`), `useDigitalTwinData.ts` (1), 3 deck-logbook
  hooks (3 via typed `onSuccess(data: ...)`), `useDeckLogbookData.ts` (3 via
  typed apiRequest).

**TS2551 (did-you-mean property renames) — closed 9:**

- `.vessel` → `.vesselId` on 6 sites in `compliance-excel/*` and
  `compliance-pdf/*` and `useVesselManagementData.ts`
- `estimatedDurationHours` → `estimatedDuration` on 3 sites in maintenance
  templates page/hook

## Out of scope — needs your call

These I deliberately did **not** touch because the right fix requires a
schema or architecture decision that's yours, not mine:

### Schema drift (cluster size in parens — total ~110 errors)

- `server/domains/alerts/settings-service.ts` (35) — consumer expects
  ~20 fields on `notification_settings` (`emailEnabled`,
  `defaultToEmail`, `ccEmails`, `bccEmails`, `timezone`, `provider`,
  `smtpHost`, `smtpPort`, `smtpUser`, `smtpUseTls`, `fromEmail`,
  `fromName`, `dailyDigestEnabled`, `dailyDigestTime`, `lastTestStatus`,
  `lastTestAt`, `lastTestError`, `apiKeyEncrypted`,
  `smtpEncryptedPassword`) that the schema doesn't have. Either extend
  the table or split a new `notification_provider_settings` table.
- `server/ml-routes/model-routes.ts` (31), `server/beast/vibration-routes.ts`
  (29), `server/vessel-simulator/sensor-mappings.ts` (24) — similar shape
  drift; consumer fields don't match storage rows. Many TS2339s.
- Fuel emissions: consumers expect separate `foConsumptionMt` /
  `doConsumptionMt` / `soxEmissionsKg` / `noxEmissionsKg` fields, schema has
  aggregated `consumptionMt` / `co2EmissionsMt` / `sox_emissionsMt` /
  `nox_emissionsMt`. Affects `useFuelEmissionsData.ts` and
  `fuel-emissions-log.tsx`. TS suggested "Did you mean `consumptionMt`?"
  for everything, but that's wrong — they're genuinely different fields.
- `useMaintenanceModeData.ts:118` — consumer reads `preventiveSavings` on
  `CostSavingsSummary` but only `predictiveSavings` exists. Semantically
  different (preventive vs predictive maintenance). Don't auto-rename.

### Missing modules (TS2307, 79 errors)

The `Cannot find module` errors cluster around imports like
`'../ml-time-bucketing.js'`, `'../ml-preprocessing-params.js'`,
`'../ml-random-forest.js'`, `'../ml-data-preprocessing.js'`,
`'../../rul-engine.js'`, `'../../cii-service.js'`,
`'../../../narrative-summary-service.js'`. Several of these were referenced
by `server/ml-prediction/predictors.ts` (which has 20 errors that cascade
from the missing imports). The files genuinely don't exist in the tree —
either deleted during a refactor or moved. **15 of the 50 TS7006 errors
also live in this file and will resolve automatically once the imports
resolve**, so this is high leverage.

A few likely candidates:

- `analyzeInsightBundle` — referenced by `insights-engine/llm-overview.ts`
- `scheduleWithORTools` — referenced by `job-processors/scheduling-processors.ts`
- `storage` (from `../repositories`) — referenced by two job processors
- `SimulationConfig`, `SimulationResult` — referenced by `vessel-simulator/simulator.ts`
- `SelectPortCall`, `SelectVessel`, `SchedulerPublication`,
  `NotificationHistory`, `InsertNotificationHistory` — missing schema exports

### Still pending in the long tail

- TS7006: 15 in `server/ml-prediction/predictors.ts` (blocked on missing modules)
- TS18046: ~49 remaining (server-side mostly; needs per-call type annotations)
- TS18047/TS18048 (possibly null/undefined): 68 untouched
- TS2554 (wrong arity): 92 untouched — these need per-call inspection
- TS2769 (no overload matches): 130 untouched

## Recommended next-wave prompt

Pick **one** of these for a clean scoped run:

1. **"Restore or remove missing ML pipeline modules"** — give me a
   directive on whether `ml-time-bucketing`, `ml-preprocessing-params`,
   `ml-random-forest`, `ml-data-preprocessing` should be restored from git
   history, refactored into existing files, or whether their consumers
   should be deleted/stubbed. Unlocks ~50 errors.

2. **"Extend `notification_settings` schema"** — give me the additive
   migration spec (which fields go on which table) and I'll produce the
   drizzle migration, schema update, and update the consumer. Unlocks
   35 errors.

3. **"Continue mechanical sweeps"** — I close out TS7006 stragglers,
   TS18046 server-side, and TS18047/18048 across worst-hit files. Each
   targeted at 30–50 errors per call.
