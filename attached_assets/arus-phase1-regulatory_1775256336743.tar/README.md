# ARUS Phase 1 — Regulatory Blockers (Remaining Items)

Closes evaluation items #1, #4, #5 from Phase 1.

## What's Included

| # | Eval Item | Files | Impact |
|---|-----------|-------|--------|
| 1 | Equipment certificate registry | `005-certificates-hazmat-devmode.sql`, `shared/schema/certificates.ts`, `server/domains/certificates/routes.ts` | Class surveyors can see certificate registry with conditions of class, endorsements, and survey windows |
| 4 | Dev mode permission bypass | `dev-mode-guard.patch.ts` | Dev mode code is tree-shaken from production builds — doesn't exist in the vessel bundle |
| 5 | Hazmat/IMDG fields on parts | `005-certificates-hazmat-devmode.sql` | Dedicated columns for IMO DG class, UN number, IMDG code, shelf life, MSDS — queryable and filterable |

## Integration Steps

### 1. Run the migration

```bash
psql $DATABASE_URL -f server/migrations/005-certificates-hazmat-devmode.sql
```

This creates the `vessel_certificates` and `certificate_events` tables, and adds hazmat columns to `parts`.

### 2. Add the Drizzle schema

Copy `shared/schema/certificates.ts` into your schema directory and add the export to your schema barrel file:

```typescript
// In shared/schema/index.ts (or wherever you aggregate schema exports)
export * from "./certificates";
```

### 3. Also patch the parts schema

Add these columns to your existing `parts` pgTable definition in `shared/schema/inventory.ts`:

```typescript
// After existing columns, before createdAt:
imoDgClass: text("imo_dg_class"),
unNumber: text("un_number"),
imdgCode: text("imdg_code"),
isHazmat: boolean("is_hazmat").notNull().default(false),
hazmatHandling: text("hazmat_handling"),
shelfLifeDays: integer("shelf_life_days"),
customsTariffCode: text("customs_tariff_code"),
msdsUrl: text("msds_url"),
```

### 4. Register certificate routes

```typescript
import { certificateRouter } from "./domains/certificates/routes.js";

app.use("/api/certificates", certificateRouter);
```

### 5. Apply dev mode patches

Follow the 4 patches in `dev-mode-guard.patch.ts`. The key change: replace every `if (isDevMode)` with `if (import.meta.env.DEV && isDevMode)`. Verify with:

```bash
npx vite build
grep -r "devMode\|isDevMode" dist/assets/*.js
# Should return zero results
```

## Certificate API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/certificates` | List certificates (filter by vessel, type, status) |
| GET | `/api/certificates/summary` | Compliance dashboard (counts by status, expiring, conditions) |
| GET | `/api/certificates/expiring?days=90` | Certificates expiring within N days |
| GET | `/api/certificates/:id` | Certificate detail with events history |
| POST | `/api/certificates` | Create certificate |
| PATCH | `/api/certificates/:id` | Update certificate (status, dates, notes) |
| POST | `/api/certificates/:id/conditions` | Add condition of class |
| PATCH | `/api/certificates/:id/conditions/:condId` | Close/reopen condition |
| POST | `/api/certificates/:id/endorsements` | Add flag state endorsement |
| DELETE | `/api/certificates/:id` | Delete certificate (cascades events) |

Note: Summary and expiring routes are registered BEFORE `/:id` to avoid the Express route-shadowing bug that existed in the class_surveys routes.

## What a Class Surveyor Sees

The certificate summary endpoint returns:

```json
{
  "totalCertificates": 24,
  "valid": 21,
  "expired": 1,
  "suspended": 0,
  "pendingRenewal": 2,
  "expiringIn30Days": 3,
  "expiringIn90Days": 5,
  "surveysDueIn90Days": 4,
  "openConditionsOfClass": 2,
  "expiredCertificates": [
    { "certificateName": "IOPP Certificate", "expiryDate": "2026-03-15" }
  ]
}
```

This is the data a PSC officer asks for during an inspection — "show me your certificate status" — and what a class surveyor reviews before a renewal survey.
