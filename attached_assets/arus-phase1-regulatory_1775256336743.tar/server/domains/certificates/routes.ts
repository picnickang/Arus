/**
 * Certificate Registry Routes
 *
 * CRUD for vessel certificates + compliance summary endpoints.
 *
 * Key differences from class_surveys routes:
 *   - Certificates have conditions of class (JSONB array management)
 *   - Certificates have flag state endorsements
 *   - Certificates link to surveys (survey completion → certificate renewal)
 *   - Expiry dashboard shows all certificates approaching renewal
 *
 * Register: app.use(certificateRouter);
 */

import { Router, Request, Response } from "express";
import { z } from "zod";
import { db } from "../../db.js";
import {
  vesselCertificates,
  certificateEvents,
  insertVesselCertificateSchema,
  CERTIFICATE_TYPES,
  CERTIFICATE_STATUSES,
  ISSUING_AUTHORITY_TYPES,
} from "@shared/schema.js";
import { vessels } from "@shared/schema.js";
import { eq, and, lte, gte, sql, desc, inArray } from "drizzle-orm";
import { requireOrgId, type AuthenticatedRequest } from "../../middleware/auth.js";
import { createRateLimiter } from "../../lib/rate-limit-factory.js";
import { createLogger } from "../../lib/structured-logger.js";

const logger = createLogger("certificate-routes");
const router = Router();
const generalLimit = createRateLimiter("general");
const writeLimit = createRateLimiter("write");

function getOrgId(req: Request): string {
  return (req as AuthenticatedRequest).orgId as string;
}

// ── Validation schemas ──────────────────────────────────────────────────────

const createCertificateSchema = z.object({
  vesselId: z.string().min(1),
  certificateType: z.enum(CERTIFICATE_TYPES as unknown as [string, ...string[]]),
  certificateName: z.string().min(1),
  certificateNumber: z.string().optional(),
  issuingAuthority: z.string().min(1),
  issuingAuthorityType: z.enum(ISSUING_AUTHORITY_TYPES as unknown as [string, ...string[]]).optional(),
  issueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  expiryDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  nextSurveyDue: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  surveyWindowStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  surveyWindowEnd: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  equipmentId: z.string().optional(),
  surveyId: z.string().optional(),
  notes: z.string().optional(),
  documentUrl: z.string().url().optional(),
});

const updateCertificateSchema = z.object({
  status: z.enum(CERTIFICATE_STATUSES as unknown as [string, ...string[]]).optional(),
  certificateNumber: z.string().optional(),
  expiryDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().nullable(),
  nextSurveyDue: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().nullable(),
  lastSurveyDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  surveyWindowStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().nullable(),
  surveyWindowEnd: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().nullable(),
  surveyId: z.string().optional(),
  notes: z.string().optional(),
  documentUrl: z.string().url().optional().nullable(),
});

const conditionSchema = z.object({
  description: z.string().min(1),
  dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  imposedDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

const endorsementSchema = z.object({
  flagState: z.string().min(1),
  endorsementNumber: z.string().min(1),
  issueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  expiryDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

// ── GET /api/certificates — List ────────────────────────────────────────────

// IMPORTANT: Put summary and expiring routes BEFORE /:id to avoid
// Express matching "summary" or "expiring" as an :id parameter.
// (This was a bug in the class_surveys routes — fixing it here.)

router.get("/summary", requireOrgId, generalLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const vesselId = req.query.vesselId as string | undefined;

    const conditions = [eq(vesselCertificates.orgId, orgId)];
    if (vesselId) conditions.push(eq(vesselCertificates.vesselId, vesselId));

    const certs = await db
      .select()
      .from(vesselCertificates)
      .where(and(...conditions));

    const now = new Date();
    const thirtyDays = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const ninetyDays = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000);

    const expired = certs.filter((c) => c.expiryDate && new Date(c.expiryDate) < now && c.status === "valid");
    const expiringIn30 = certs.filter((c) =>
      c.expiryDate && new Date(c.expiryDate) >= now && new Date(c.expiryDate) <= thirtyDays && c.status === "valid"
    );
    const expiringIn90 = certs.filter((c) =>
      c.expiryDate && new Date(c.expiryDate) >= now && new Date(c.expiryDate) <= ninetyDays && c.status === "valid"
    );
    const surveysDue = certs.filter((c) =>
      c.nextSurveyDue && new Date(c.nextSurveyDue) <= ninetyDays && c.status === "valid"
    );

    // Count open conditions of class across all certificates
    let openConditions = 0;
    for (const cert of certs) {
      const conditions = (cert.conditionsOfClass as any[]) || [];
      openConditions += conditions.filter((c: any) => c.status === "open" || c.status === "overdue").length;
    }

    res.json({
      totalCertificates: certs.length,
      valid: certs.filter((c) => c.status === "valid").length,
      expired: expired.length,
      suspended: certs.filter((c) => c.status === "suspended").length,
      pendingRenewal: certs.filter((c) => c.status === "pending_renewal").length,
      expiringIn30Days: expiringIn30.length,
      expiringIn90Days: expiringIn90.length,
      surveysDueIn90Days: surveysDue.length,
      openConditionsOfClass: openConditions,
      expiredCertificates: expired.map((c) => ({
        id: c.id,
        certificateName: c.certificateName,
        certificateType: c.certificateType,
        expiryDate: c.expiryDate,
        vesselId: c.vesselId,
      })),
    });
  } catch (err) {
    logger.error("Error getting certificate summary", { error: err });
    res.status(500).json({ error: "Failed to get certificate summary" });
  }
});

router.get("/expiring", requireOrgId, generalLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const days = Number(req.query.days) || 90;
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() + days);

    const certs = await db
      .select({
        cert: vesselCertificates,
        vesselName: vessels.name,
      })
      .from(vesselCertificates)
      .leftJoin(vessels, eq(vesselCertificates.vesselId, vessels.id))
      .where(
        and(
          eq(vesselCertificates.orgId, orgId),
          eq(vesselCertificates.status, "valid"),
          lte(vesselCertificates.expiryDate, cutoffDate)
        )
      )
      .orderBy(vesselCertificates.expiryDate);

    res.json(certs.map(({ cert, vesselName }) => ({
      ...cert,
      vesselName,
      daysUntilExpiry: cert.expiryDate
        ? Math.ceil((new Date(cert.expiryDate).getTime() - Date.now()) / (24 * 60 * 60 * 1000))
        : null,
    })));
  } catch (err) {
    logger.error("Error getting expiring certificates", { error: err });
    res.status(500).json({ error: "Failed to get expiring certificates" });
  }
});

// ── GET /api/certificates — List all ────────────────────────────────────────

router.get("/", requireOrgId, generalLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const { vesselId, type, status } = req.query;

    const conditions = [eq(vesselCertificates.orgId, orgId)];
    if (vesselId) conditions.push(eq(vesselCertificates.vesselId, vesselId as string));
    if (type) conditions.push(eq(vesselCertificates.certificateType, type as string));
    if (status) conditions.push(eq(vesselCertificates.status, status as string));

    const certs = await db
      .select({
        cert: vesselCertificates,
        vesselName: vessels.name,
      })
      .from(vesselCertificates)
      .leftJoin(vessels, eq(vesselCertificates.vesselId, vessels.id))
      .where(and(...conditions))
      .orderBy(vesselCertificates.expiryDate);

    res.json(certs.map(({ cert, vesselName }) => ({ ...cert, vesselName })));
  } catch (err) {
    logger.error("Error listing certificates", { error: err });
    res.status(500).json({ error: "Failed to list certificates" });
  }
});

// ── GET /api/certificates/:id ───────────────────────────────────────────────

router.get("/:id", requireOrgId, generalLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const [cert] = await db
      .select({
        cert: vesselCertificates,
        vesselName: vessels.name,
      })
      .from(vesselCertificates)
      .leftJoin(vessels, eq(vesselCertificates.vesselId, vessels.id))
      .where(and(eq(vesselCertificates.id, req.params.id), eq(vesselCertificates.orgId, orgId)))
      .limit(1);

    if (!cert) return res.status(404).json({ error: "Certificate not found" });

    // Get events
    const events = await db
      .select()
      .from(certificateEvents)
      .where(eq(certificateEvents.certificateId, req.params.id))
      .orderBy(desc(certificateEvents.createdAt));

    res.json({ ...cert.cert, vesselName: cert.vesselName, events });
  } catch (err) {
    logger.error("Error getting certificate", { error: err });
    res.status(500).json({ error: "Failed to get certificate" });
  }
});

// ── POST /api/certificates ──────────────────────────────────────────────────

router.post("/", requireOrgId, writeLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const data = createCertificateSchema.parse(req.body);

    const [cert] = await db
      .insert(vesselCertificates)
      .values({
        orgId,
        vesselId: data.vesselId,
        certificateType: data.certificateType,
        certificateName: data.certificateName,
        certificateNumber: data.certificateNumber,
        issuingAuthority: data.issuingAuthority,
        issuingAuthorityType: data.issuingAuthorityType || "class_society",
        issueDate: new Date(data.issueDate),
        expiryDate: data.expiryDate ? new Date(data.expiryDate) : null,
        nextSurveyDue: data.nextSurveyDue ? new Date(data.nextSurveyDue) : null,
        surveyWindowStart: data.surveyWindowStart ? new Date(data.surveyWindowStart) : null,
        surveyWindowEnd: data.surveyWindowEnd ? new Date(data.surveyWindowEnd) : null,
        equipmentId: data.equipmentId || null,
        surveyId: data.surveyId || null,
        notes: data.notes || null,
        documentUrl: data.documentUrl || null,
        createdBy: (req as any).user?.id,
        status: "valid",
      } as any)
      .returning();

    await db.insert(certificateEvents).values({
      orgId,
      certificateId: cert.id,
      eventType: "issued",
      userId: (req as any).user?.id,
      details: { certificateType: data.certificateType, issuingAuthority: data.issuingAuthority },
    });

    res.status(201).json(cert);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: err.flatten() });
    }
    logger.error("Error creating certificate", { error: err });
    res.status(500).json({ error: "Failed to create certificate" });
  }
});

// ── PATCH /api/certificates/:id ─────────────────────────────────────────────

router.patch("/:id", requireOrgId, writeLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const data = updateCertificateSchema.parse(req.body);

    const updates: Record<string, unknown> = { updatedAt: new Date(), updatedBy: (req as any).user?.id };

    if (data.status !== undefined) updates.status = data.status;
    if (data.certificateNumber !== undefined) updates.certificateNumber = data.certificateNumber;
    if (data.expiryDate !== undefined) updates.expiryDate = data.expiryDate ? new Date(data.expiryDate) : null;
    if (data.nextSurveyDue !== undefined) updates.nextSurveyDue = data.nextSurveyDue ? new Date(data.nextSurveyDue) : null;
    if (data.lastSurveyDate !== undefined) updates.lastSurveyDate = new Date(data.lastSurveyDate);
    if (data.surveyWindowStart !== undefined) updates.surveyWindowStart = data.surveyWindowStart ? new Date(data.surveyWindowStart) : null;
    if (data.surveyWindowEnd !== undefined) updates.surveyWindowEnd = data.surveyWindowEnd ? new Date(data.surveyWindowEnd) : null;
    if (data.surveyId !== undefined) updates.surveyId = data.surveyId;
    if (data.notes !== undefined) updates.notes = data.notes;
    if (data.documentUrl !== undefined) updates.documentUrl = data.documentUrl;

    const [updated] = await db
      .update(vesselCertificates)
      .set(updates)
      .where(and(eq(vesselCertificates.id, req.params.id), eq(vesselCertificates.orgId, orgId)))
      .returning();

    if (!updated) return res.status(404).json({ error: "Certificate not found" });

    if (data.status) {
      await db.insert(certificateEvents).values({
        orgId,
        certificateId: req.params.id,
        eventType: data.status === "valid" ? "reinstated" : data.status,
        userId: (req as any).user?.id,
        details: updates,
      });
    }

    res.json(updated);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: err.flatten() });
    }
    logger.error("Error updating certificate", { error: err });
    res.status(500).json({ error: "Failed to update certificate" });
  }
});

// ── POST /api/certificates/:id/conditions — Add condition of class ──────────

router.post("/:id/conditions", requireOrgId, writeLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const data = conditionSchema.parse(req.body);

    const [cert] = await db
      .select()
      .from(vesselCertificates)
      .where(and(eq(vesselCertificates.id, req.params.id), eq(vesselCertificates.orgId, orgId)))
      .limit(1);

    if (!cert) return res.status(404).json({ error: "Certificate not found" });

    const conditions = ((cert.conditionsOfClass as any[]) || []).slice();
    const newCondition = {
      id: `coc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      description: data.description,
      dueDate: data.dueDate,
      imposedDate: data.imposedDate || new Date().toISOString().split("T")[0],
      status: "open",
    };
    conditions.push(newCondition);

    const [updated] = await db
      .update(vesselCertificates)
      .set({ conditionsOfClass: conditions, updatedAt: new Date() })
      .where(and(eq(vesselCertificates.id, req.params.id), eq(vesselCertificates.orgId, orgId)))
      .returning();

    await db.insert(certificateEvents).values({
      orgId,
      certificateId: req.params.id,
      eventType: "condition_added",
      userId: (req as any).user?.id,
      details: newCondition,
    });

    res.status(201).json({ condition: newCondition, certificate: updated });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: err.flatten() });
    }
    logger.error("Error adding condition", { error: err });
    res.status(500).json({ error: "Failed to add condition" });
  }
});

// ── PATCH /api/certificates/:id/conditions/:conditionId — Close condition ───

router.patch("/:id/conditions/:conditionId", requireOrgId, writeLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const { conditionId } = req.params;
    const { status } = z.object({ status: z.enum(["open", "closed"]) }).parse(req.body);

    const [cert] = await db
      .select()
      .from(vesselCertificates)
      .where(and(eq(vesselCertificates.id, req.params.id), eq(vesselCertificates.orgId, orgId)))
      .limit(1);

    if (!cert) return res.status(404).json({ error: "Certificate not found" });

    const conditions = ((cert.conditionsOfClass as any[]) || []).map((c: any) => {
      if (c.id === conditionId) {
        return {
          ...c,
          status,
          closedDate: status === "closed" ? new Date().toISOString().split("T")[0] : undefined,
          closedBy: status === "closed" ? (req as any).user?.id : undefined,
        };
      }
      return c;
    });

    const [updated] = await db
      .update(vesselCertificates)
      .set({ conditionsOfClass: conditions, updatedAt: new Date() })
      .where(and(eq(vesselCertificates.id, req.params.id), eq(vesselCertificates.orgId, orgId)))
      .returning();

    await db.insert(certificateEvents).values({
      orgId,
      certificateId: req.params.id,
      eventType: "condition_closed",
      userId: (req as any).user?.id,
      details: { conditionId, status },
    });

    res.json(updated);
  } catch (err) {
    logger.error("Error updating condition", { error: err });
    res.status(500).json({ error: "Failed to update condition" });
  }
});

// ── POST /api/certificates/:id/endorsements — Add endorsement ───────────────

router.post("/:id/endorsements", requireOrgId, writeLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);
    const data = endorsementSchema.parse(req.body);

    const [cert] = await db
      .select()
      .from(vesselCertificates)
      .where(and(eq(vesselCertificates.id, req.params.id), eq(vesselCertificates.orgId, orgId)))
      .limit(1);

    if (!cert) return res.status(404).json({ error: "Certificate not found" });

    const endorsements = ((cert.endorsements as any[]) || []).slice();
    endorsements.push(data);

    const [updated] = await db
      .update(vesselCertificates)
      .set({ endorsements, updatedAt: new Date() })
      .where(and(eq(vesselCertificates.id, req.params.id), eq(vesselCertificates.orgId, orgId)))
      .returning();

    await db.insert(certificateEvents).values({
      orgId,
      certificateId: req.params.id,
      eventType: "endorsement_added",
      userId: (req as any).user?.id,
      details: data,
    });

    res.status(201).json(updated);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: err.flatten() });
    }
    logger.error("Error adding endorsement", { error: err });
    res.status(500).json({ error: "Failed to add endorsement" });
  }
});

// ── DELETE /api/certificates/:id ────────────────────────────────────────────

router.delete("/:id", requireOrgId, writeLimit, async (req: Request, res: Response) => {
  try {
    const orgId = getOrgId(req);

    // Events cascade-delete via FK
    const result = await db
      .delete(vesselCertificates)
      .where(and(eq(vesselCertificates.id, req.params.id), eq(vesselCertificates.orgId, orgId)))
      .returning({ id: vesselCertificates.id });

    if (result.length === 0) return res.status(404).json({ error: "Certificate not found" });

    res.json({ success: true });
  } catch (err) {
    logger.error("Error deleting certificate", { error: err });
    res.status(500).json({ error: "Failed to delete certificate" });
  }
});

export { router as certificateRouter };
export default router;
