/**
 * Dev Mode Permission Guard
 *
 * Evaluation finding: "The frontend includes a 'Dev Mode' toggle that
 * bypasses permission checks. If this ships to a vessel, any user who
 * discovers it can elevate their privileges."
 *
 * This file provides two things:
 *   1. A build-time constant that strips dev mode from production builds
 *   2. A patch for the existing DevModeToggle component
 *
 * The key change: dev mode is gated by import.meta.env.DEV (Vite build-time
 * constant), NOT by a runtime check. In production builds, the dev mode
 * code is tree-shaken out entirely — it doesn't exist in the bundle.
 */

// ============================================================================
// APPROACH: Build-time guard using Vite's import.meta.env.DEV
// ============================================================================

/**
 * PATCH 1: In your AdminAccessContext.tsx (or wherever devMode state lives)
 *
 * FIND:
 * -----------------------------------------------
 *   const [isDevMode, setIsDevMode] = useState(false);
 * -----------------------------------------------
 *
 * REPLACE WITH:
 * -----------------------------------------------
 *   // DEV MODE: Only available in development builds.
 *   // import.meta.env.DEV is replaced by Vite at build time:
 *   //   - true  in `vite dev` (development)
 *   //   - false in `vite build` (production) — code is tree-shaken out
 *   const [isDevMode, setIsDevMode] = useState(false);
 *   const canEnableDevMode = import.meta.env.DEV;
 * -----------------------------------------------
 *
 * Then update the toggle function:
 * -----------------------------------------------
 *   const toggleDevMode = useCallback(() => {
 *     if (!import.meta.env.DEV) return; // No-op in production
 *     setIsDevMode((prev) => !prev);
 *   }, []);
 * -----------------------------------------------
 *
 * And update the context value:
 * -----------------------------------------------
 *   const value = useMemo(() => ({
 *     isDevMode: import.meta.env.DEV ? isDevMode : false,
 *     toggleDevMode,
 *     canEnableDevMode: import.meta.env.DEV,
 *   }), [isDevMode, toggleDevMode]);
 * -----------------------------------------------
 */

/**
 * PATCH 2: In your DevPerformanceOverlay.tsx (or DevModeToggle component)
 *
 * FIND (the component that renders the dev mode toggle):
 * -----------------------------------------------
 *   export function DevPerformanceOverlay() {
 * -----------------------------------------------
 *
 * REPLACE the entire component with:
 * -----------------------------------------------
 *   export function DevPerformanceOverlay() {
 *     // Entire component is stripped from production builds
 *     if (!import.meta.env.DEV) return null;
 *
 *     // ... existing dev overlay code ...
 *   }
 * -----------------------------------------------
 *
 * Because import.meta.env.DEV is a compile-time constant, Vite's
 * dead code elimination will remove the entire component body in
 * production builds. The function still exists (so imports don't break)
 * but it returns null immediately.
 */

/**
 * PATCH 3: In your PermissionGate component (if it checks devMode)
 *
 * FIND:
 * -----------------------------------------------
 *   if (isDevMode) return <>{children}</>; // Bypass in dev mode
 * -----------------------------------------------
 *
 * REPLACE WITH:
 * -----------------------------------------------
 *   // Dev mode bypass only works in development builds
 *   if (import.meta.env.DEV && isDevMode) return <>{children}</>;
 * -----------------------------------------------
 */

/**
 * PATCH 4: In your permission checking hooks (useUserPermissions, etc.)
 *
 * FIND any pattern like:
 * -----------------------------------------------
 *   if (devMode) return true; // Skip permission check
 * -----------------------------------------------
 *
 * REPLACE WITH:
 * -----------------------------------------------
 *   if (import.meta.env.DEV && devMode) return true;
 * -----------------------------------------------
 */

/**
 * VERIFICATION: After applying these patches, run a production build
 * and search the output bundle for "devMode" or "isDevMode":
 *
 *   npx vite build
 *   grep -r "devMode\|isDevMode\|toggleDevMode" dist/assets/*.js
 *
 * The grep should return zero results (or only the context type definition
 * if TypeScript types leak through). If you see runtime devMode checks,
 * the build-time guard isn't working — check that import.meta.env.DEV
 * is used directly (not stored in a variable that the bundler can't trace).
 */

export {};
