/**
 * Migration 005: Certificate Registry + Hazmat Parts + Dev Mode Guard
 *
 * Addresses Phase 1 items #1, #4, #5 from the professional evaluation:
 *   1. Equipment certificate registry (class, statutory, flag state)
 *   4. Dev mode permission bypass removal (build-time guard)
 *   5. Hazmat/IMDG classification fields on inventory parts
 *
 * Run: psql $DATABASE_URL -f 005-certificates-hazmat-devmode.sql
 */

-- ============================================================================
-- PART 1: Equipment Certificate Registry
-- ============================================================================
-- Certificates are DIFFERENT from surveys. A survey is an inspection event.
-- A certificate is a document with a validity period, issued by an authority,
-- that may have conditions of class and endorsements attached.
-- Survey completion → certificate renewal is a common workflow.

CREATE TABLE IF NOT EXISTS vessel_certificates (
  id              VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id          VARCHAR NOT NULL REFERENCES organizations(id),
  vessel_id       VARCHAR NOT NULL REFERENCES vessels(id),

  -- Certificate identity
  certificate_type    TEXT NOT NULL,
  -- Types: 'safety_equipment', 'safety_radio', 'safety_construction',
  --        'load_line', 'iopp', 'ispp', 'class_machinery', 'class_hull',
  --        'class_electrical', 'smc', 'issc', 'doc', 'mlc', 'ism',
  --        'tonnage', 'registry', 'minimum_safe_manning', 'other'

  certificate_number  TEXT,
  certificate_name    TEXT NOT NULL,

  -- Issuing authority
  issuing_authority   TEXT NOT NULL,
  -- Examples: 'DNV', 'Lloyd's Register', 'BV', 'Flag State (Panama)',
  --           'Flag State (Marshall Islands)', 'RO on behalf of Flag'
  issuing_authority_type TEXT NOT NULL DEFAULT 'class_society',
  -- Types: 'class_society', 'flag_state', 'recognized_organization', 'port_state'

  -- Validity
  issue_date          DATE NOT NULL,
  expiry_date         DATE,
  -- Some certificates don't expire (e.g., tonnage certificate)

  -- Survey windows (for certificates tied to periodic surveys)
  last_survey_date      DATE,
  next_survey_due       DATE,
  survey_window_start   DATE,
  -- Survey window: typically +/- 3 months around anniversary date
  survey_window_end     DATE,

  -- Status
  status              TEXT NOT NULL DEFAULT 'valid',
  -- Statuses: 'valid', 'expired', 'suspended', 'withdrawn', 'pending_renewal'

  -- Conditions of class (for class certificates)
  conditions_of_class JSONB DEFAULT '[]',
  -- Array of: { id, description, dueDate, status: 'open'|'closed'|'overdue', imposedDate }

  -- Flag state endorsements
  endorsements        JSONB DEFAULT '[]',
  -- Array of: { flagState, endorsementNumber, issueDate, expiryDate }

  -- Links
  survey_id           VARCHAR,
  -- References class_surveys(id) when certificate was issued/renewed after a survey
  equipment_id        VARCHAR REFERENCES equipment(id),
  -- Some certificates are equipment-specific (e.g., lifeboat davit test cert)

  -- Document storage
  document_url        TEXT,
  -- URL to the scanned PDF of the physical certificate

  -- Audit
  notes               TEXT,
  created_by          VARCHAR,
  updated_by          VARCHAR,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_vessel_certs_org_vessel
  ON vessel_certificates (org_id, vessel_id);
CREATE INDEX IF NOT EXISTS idx_vessel_certs_expiry
  ON vessel_certificates (org_id, expiry_date)
  WHERE status = 'valid';
CREATE INDEX IF NOT EXISTS idx_vessel_certs_survey_due
  ON vessel_certificates (org_id, next_survey_due)
  WHERE status = 'valid';
CREATE INDEX IF NOT EXISTS idx_vessel_certs_type
  ON vessel_certificates (certificate_type, status);
CREATE INDEX IF NOT EXISTS idx_vessel_certs_status
  ON vessel_certificates (org_id, status);

-- Certificate events audit trail (immutable log)
CREATE TABLE IF NOT EXISTS certificate_events (
  id              VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id          VARCHAR NOT NULL REFERENCES organizations(id),
  certificate_id  VARCHAR NOT NULL REFERENCES vessel_certificates(id) ON DELETE CASCADE,
  event_type      TEXT NOT NULL,
  -- Types: 'issued', 'renewed', 'suspended', 'withdrawn', 'reinstated',
  --        'condition_added', 'condition_closed', 'endorsement_added',
  --        'survey_linked', 'expiry_warning', 'document_uploaded'
  user_id         VARCHAR,
  details         JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cert_events_cert
  ON certificate_events (certificate_id, created_at DESC);

-- ============================================================================
-- PART 2: Hazmat / IMDG Classification Fields on Parts
-- ============================================================================
-- Adds dedicated columns to the parts table for dangerous goods classification.
-- These were previously stored in the generic JSONB 'specifications' field,
-- which meant they couldn't be queried, filtered, or validated.

ALTER TABLE parts
  ADD COLUMN IF NOT EXISTS imo_dg_class        TEXT,
  -- IMO Dangerous Goods classes: '1' through '9', with subdivisions
  -- e.g., '2.1' (flammable gas), '3' (flammable liquid), '8' (corrosive)

  ADD COLUMN IF NOT EXISTS un_number           TEXT,
  -- UN identification number for the substance (e.g., 'UN1950' for aerosols)

  ADD COLUMN IF NOT EXISTS imdg_code           TEXT,
  -- IMDG Code reference for shipping requirements

  ADD COLUMN IF NOT EXISTS is_hazmat           BOOLEAN NOT NULL DEFAULT false,
  -- Quick filter: does this part require hazmat handling?

  ADD COLUMN IF NOT EXISTS hazmat_handling      TEXT,
  -- Storage and handling requirements text
  -- e.g., 'Store in ventilated area away from heat sources. Max stack: 2 layers.'

  ADD COLUMN IF NOT EXISTS shelf_life_days     INTEGER,
  -- Shelf life in days from manufacture date (null = no expiry)
  -- Critical for: paints, sealants, batteries, refrigerants, medical supplies

  ADD COLUMN IF NOT EXISTS customs_tariff_code TEXT,
  -- HS/customs tariff code for port clearing
  -- Required when ordering parts to foreign ports

  ADD COLUMN IF NOT EXISTS msds_url            TEXT;
  -- URL to Material Safety Data Sheet PDF

-- Index for hazmat queries (PSC officers ask "show me your hazmat inventory")
CREATE INDEX IF NOT EXISTS idx_parts_hazmat
  ON parts (is_hazmat, imo_dg_class)
  WHERE is_hazmat = true;

-- Index for shelf life expiry tracking
CREATE INDEX IF NOT EXISTS idx_parts_shelf_life
  ON parts (shelf_life_days)
  WHERE shelf_life_days IS NOT NULL;


-- ============================================================================
-- PART 3: Comments for documentation
-- ============================================================================

COMMENT ON TABLE vessel_certificates IS 'Statutory and class certificates for vessels. Tracks validity, survey windows, conditions of class, and flag state endorsements. Linked to class_surveys for renewal tracking.';
COMMENT ON COLUMN vessel_certificates.conditions_of_class IS 'JSONB array of conditions imposed by class society. Each: {id, description, dueDate, status, imposedDate}. Open conditions must be resolved before certificate renewal.';
COMMENT ON COLUMN vessel_certificates.endorsements IS 'JSONB array of flag state endorsements. Each: {flagState, endorsementNumber, issueDate, expiryDate}. Required for vessels operating under multiple flags.';
COMMENT ON COLUMN parts.imo_dg_class IS 'IMO Dangerous Goods class (1-9 with subdivisions). Required for IMDG Code compliance when shipping parts to/from vessels.';
COMMENT ON COLUMN parts.shelf_life_days IS 'Shelf life in days from manufacture. Null means no expiry. Used for paints, sealants, batteries, refrigerants, medical supplies.';
