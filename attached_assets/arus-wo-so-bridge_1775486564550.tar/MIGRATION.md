# Work Order ↔ Service Order Bridge — Migration Guide

## The Gap

Work orders (internal maintenance) and service orders (external vendor engagement)
had no formal link. A WO could spawn an SO but:
- No FK column existed on service_orders
- WO status didn't reflect "awaiting external service"
- No way to see linked SOs from the WO detail view
- No way to see the originating WO from the SO detail view

## What This Package Adds

### Database
- `service_orders.work_order_id` — FK to `work_orders.id` (nullable)
- `service_orders.work_order_number` — denormalized for display/search
- `work_orders_with_service_info` — database view with SO count, IDs, statuses
- WO status gains "awaiting_service" value (set when SO is created from WO)

### API Endpoints
- `GET /api/work-orders/:id/service-orders` — all SOs linked to a WO
- `POST /api/work-orders/:id/service-orders` — create SO pre-linked to WO
- `GET /api/service-orders/:id/work-order` — get linked WO for an SO
- `PATCH /api/service-orders/:id/link-work-order` — retroactively link SO to WO
- `POST /api/service-orders/:id/sync-work-order-status` — update WO when all SOs complete

### Frontend Hooks
- `useWorkOrderServiceOrders(woId)` — fetch linked SOs
- `useServiceOrderWorkOrder(soId)` — fetch linked WO
- `useCreateServiceOrderFromWO()` — create SO from WO context
- `useLinkServiceOrderToWO()` — retroactive linking
- `useSyncWOStatusFromSO()` — status sync after SO completion

### UI Components
- `LinkedServiceOrdersPanel` — shows in WO detail drawer with SO list + "Request Service" button
- `LinkedWorkOrderBadge` — compact badge for SO cards showing originating WO
- `LinkedWorkOrderPanel` — full panel for SO detail drawer showing originating WO details

## Files

```
server/
  migrations/wo-so-bridge.ts         — Database migration (run once)
  routes/wo-so-bridge-routes.ts      — API endpoints (register in server setup)

client/src/
  features/work-orders/hooks/
    useWoSoBridge.ts                  — Frontend hooks

  components/work-orders/
    LinkedServiceOrdersPanel.tsx      — WO → SO panel (add to WO detail drawer)

  components/service-orders/
    LinkedWorkOrderBadge.tsx          — SO → WO badge + panel (add to SO views)
```

## Integration Steps

### 1. Run database migration

```typescript
import { migrateWorkOrderServiceOrderBridge } from "./migrations/wo-so-bridge";
await migrateWorkOrderServiceOrderBridge(db);
```

Add this to your startup migration sequence, after the service_orders and
work_orders tables exist.

### 2. Register API routes

```typescript
import { registerWoSoBridgeRoutes } from "./routes/wo-so-bridge-routes";

// In your server setup, after other route registrations:
registerWoSoBridgeRoutes(app, { writeOperationRateLimit, generalApiRateLimit });
```

### 3. Add LinkedServiceOrdersPanel to Work Order detail drawer

In `WorkOrderDetailDrawer.tsx`, add below the existing detail sections:

```tsx
import { LinkedServiceOrdersPanel } from "@/components/work-orders/LinkedServiceOrdersPanel";

// Inside the drawer content, after existing sections:
<LinkedServiceOrdersPanel
  workOrderId={workOrder.id}
  workOrderNumber={workOrder.workOrderNumber}
  workOrderStatus={workOrder.status}
/>
```

### 4. Add LinkedWorkOrderBadge to Service Order cards

In `SOCard.tsx` (or wherever SO cards are rendered), add:

```tsx
import { LinkedWorkOrderBadge } from "@/components/service-orders/LinkedWorkOrderBadge";

// Inside the SO card, near the SO number:
{order.workOrderId && (
  <LinkedWorkOrderBadge
    workOrderId={order.workOrderId}
    workOrderNumber={order.workOrderNumber}
  />
)}
```

### 5. Add LinkedWorkOrderPanel to Service Order detail view

If you have an SO detail drawer/page, add:

```tsx
import { LinkedWorkOrderPanel } from "@/components/service-orders/LinkedWorkOrderBadge";

// Inside the SO detail:
<LinkedWorkOrderPanel serviceOrderId={serviceOrder.id} />
```

### 6. Handle "awaiting_service" status in WO status displays

Add "awaiting_service" to your WO status color/label maps:

```typescript
// In your status utilities:
case "awaiting_service": return "Awaiting Service";
case "awaiting_service": return "bg-amber-500/15 text-amber-600";
```

### 7. Sync WO status after SO completion

In your service order complete/cancel handlers, call the sync endpoint:

```typescript
import { useSyncWOStatusFromSO } from "@/features/work-orders/hooks/useWoSoBridge";

const syncMutation = useSyncWOStatusFromSO();

// After completing a service order:
await completeMutation.mutateAsync(serviceOrderId);
await syncMutation.mutateAsync(serviceOrderId);
```

## The Flow

1. Chief engineer creates a work order: "Replace deck crane slew bearing"
2. Work is external → clicks "Request Service" in the WO detail drawer
3. Dialog opens with WO context pre-filled (equipment, vessel, scope)
4. Selects a vendor, sets cost estimate and schedule → creates SO
5. WO status auto-updates to "Awaiting Service"
6. SO goes through its lifecycle: draft → sent → confirmed → in_progress → completed
7. When SO completes, WO status auto-reverts to "in_progress"
8. Chief engineer completes the WO

Both sides show the link: WO shows its SOs, SO shows its originating WO.
