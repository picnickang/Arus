/**
 * WO ↔ SO Bridge — API Routes
 *
 * New endpoints:
 *   GET  /api/work-orders/:id/service-orders
 *        → Returns all service orders linked to a work order
 *
 *   POST /api/work-orders/:id/service-orders
 *        → Creates a service order pre-linked to the work order
 *        → Optionally sets WO status to "awaiting_service"
 *
 *   GET  /api/service-orders/:id/work-order
 *        → Returns the linked work order for a service order
 *
 *   PATCH /api/service-orders/:id/link-work-order
 *        → Links an existing SO to a WO (retroactive linking)
 */

import type { Express, Request, Response } from "express";
import { db } from "../../db-config.js";
import { eq, and, sql, desc } from "drizzle-orm";
import { requireOrgId, requireOrgIdAndValidateBody } from "../../middleware/auth.js";
import { withErrorHandling, sendCreated, sendNotFound } from "../../lib/route-utils.js";
import { logger } from "../../utils/logger.js";

function getOrgId(req: any): string {
  const orgId = req.orgId || req.headers["x-org-id"];
  if (!orgId) throw new Error("Missing orgId");
  return orgId as string;
}

export function registerWoSoBridgeRoutes(
  app: Express,
  rateLimiters: {
    writeOperationRateLimit: any;
    generalApiRateLimit: any;
  }
) {
  const { writeOperationRateLimit, generalApiRateLimit } = rateLimiters;

  // ── GET /api/work-orders/:id/service-orders ─────────────────────────────
  // Returns all service orders linked to this work order
  app.get(
    "/api/work-orders/:id/service-orders",
    requireOrgId,
    generalApiRateLimit,
    withErrorHandling("fetch work order service orders", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const workOrderId = req.params.id;

      const rows = await db.execute(sql`
        SELECT
          so.id,
          so.so_number,
          so.status,
          so.service_provider_id,
          so.service_provider_name,
          so.scope,
          so.estimated_cost,
          so.actual_cost,
          so.scheduled_start_date,
          so.scheduled_end_date,
          so.vessel_name,
          so.equipment_name,
          so.created_at,
          so.updated_at
        FROM service_orders so
        WHERE so.work_order_id = ${workOrderId}
          AND so.org_id = ${orgId}
        ORDER BY so.created_at DESC
      `);

      res.json({
        workOrderId,
        serviceOrders: rows.rows || rows,
        count: (rows.rows || rows).length,
      });
    })
  );

  // ── POST /api/work-orders/:id/service-orders ────────────────────────────
  // Creates a new service order pre-linked to this work order
  app.post(
    "/api/work-orders/:id/service-orders",
    requireOrgIdAndValidateBody,
    writeOperationRateLimit,
    withErrorHandling("create service order from work order", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const workOrderId = req.params.id;

      // Verify work order exists
      const [wo] = await db.execute(sql`
        SELECT id, work_order_number, equipment_id, description, vessel_id, org_id
        FROM work_orders
        WHERE id = ${workOrderId} AND org_id = ${orgId}
      `).then((r) => r.rows || r);

      if (!wo) {
        return sendNotFound(res, "Work Order");
      }

      // Generate SO number
      const [seqResult] = await db.execute(sql`
        SELECT COALESCE(
          MAX(CAST(SUBSTRING(so_number FROM 'SO-([0-9]+)') AS INTEGER)),
          0
        ) + 1 AS next_num
        FROM service_orders
        WHERE org_id = ${orgId}
      `).then((r) => r.rows || r);
      const soNumber = `SO-${String(seqResult?.next_num || 1).padStart(4, "0")}`;

      const {
        serviceProviderId,
        serviceProviderName,
        scope,
        estimatedCost,
        scheduledStartDate,
        scheduledEndDate,
        estimatedDurationHours,
        severity,
        notes,
        updateWorkOrderStatus = true,
      } = req.body;

      // Create the service order with work_order_id pre-linked
      const [newSo] = await db.execute(sql`
        INSERT INTO service_orders (
          id, org_id, so_number, status,
          work_order_id, work_order_number,
          service_provider_id, service_provider_name,
          scope, estimated_cost,
          scheduled_start_date, scheduled_end_date,
          estimated_duration_hours, severity, notes,
          vessel_id, vessel_name,
          equipment_id, equipment_name,
          created_at, updated_at
        )
        SELECT
          gen_random_uuid()::text,
          ${orgId},
          ${soNumber},
          'draft',
          ${workOrderId},
          wo.work_order_number,
          ${serviceProviderId || null},
          ${serviceProviderName || null},
          ${scope || wo.description || null},
          ${estimatedCost || null},
          ${scheduledStartDate || null},
          ${scheduledEndDate || null},
          ${estimatedDurationHours || null},
          ${severity || "medium"},
          ${notes || null},
          wo.vessel_id,
          v.name,
          wo.equipment_id,
          eq.name
        FROM work_orders wo
        LEFT JOIN vessels v ON v.id = wo.vessel_id
        LEFT JOIN equipment eq ON eq.id = wo.equipment_id
        WHERE wo.id = ${workOrderId}
        RETURNING *
      `).then((r) => r.rows || r);

      // Optionally update WO status to reflect external service dependency
      if (updateWorkOrderStatus) {
        await db.execute(sql`
          UPDATE work_orders
          SET
            status = CASE
              WHEN status IN ('open', 'in_progress') THEN 'awaiting_service'
              ELSE status
            END,
            updated_at = NOW(),
            notes = COALESCE(notes, '') || E'\n[' || NOW()::text || '] Service order ' || ${soNumber} || ' created — awaiting external service.'
          WHERE id = ${workOrderId} AND org_id = ${orgId}
        `);
      }

      logger.info(`Created service order ${soNumber} from work order ${workOrderId}`);
      sendCreated(res, newSo);
    })
  );

  // ── GET /api/service-orders/:id/work-order ──────────────────────────────
  // Returns the linked work order for a service order
  app.get(
    "/api/service-orders/:id/work-order",
    requireOrgId,
    generalApiRateLimit,
    withErrorHandling("fetch service order work order", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const serviceOrderId = req.params.id;

      const [row] = await db.execute(sql`
        SELECT
          wo.id,
          wo.work_order_number,
          wo.description,
          wo.status,
          wo.priority,
          wo.equipment_id,
          eq.name AS equipment_name,
          wo.vessel_id,
          v.name AS vessel_name,
          wo.created_at,
          wo.updated_at,
          wo.completed_at
        FROM service_orders so
        JOIN work_orders wo ON wo.id = so.work_order_id
        LEFT JOIN equipment eq ON eq.id = wo.equipment_id
        LEFT JOIN vessels v ON v.id = wo.vessel_id
        WHERE so.id = ${serviceOrderId}
          AND so.org_id = ${orgId}
          AND so.work_order_id IS NOT NULL
      `).then((r) => r.rows || r);

      if (!row) {
        return res.json({ workOrder: null, linked: false });
      }

      res.json({ workOrder: row, linked: true });
    })
  );

  // ── PATCH /api/service-orders/:id/link-work-order ───────────────────────
  // Retroactively link an existing SO to a WO
  app.patch(
    "/api/service-orders/:id/link-work-order",
    requireOrgIdAndValidateBody,
    writeOperationRateLimit,
    withErrorHandling("link service order to work order", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const serviceOrderId = req.params.id;
      const { workOrderId } = req.body;

      if (!workOrderId) {
        return res.status(400).json({ error: "workOrderId is required" });
      }

      // Verify both exist in same org
      const [wo] = await db.execute(sql`
        SELECT id, work_order_number FROM work_orders
        WHERE id = ${workOrderId} AND org_id = ${orgId}
      `).then((r) => r.rows || r);

      if (!wo) {
        return sendNotFound(res, "Work Order");
      }

      const [so] = await db.execute(sql`
        UPDATE service_orders
        SET
          work_order_id = ${workOrderId},
          work_order_number = ${wo.work_order_number},
          updated_at = NOW()
        WHERE id = ${serviceOrderId} AND org_id = ${orgId}
        RETURNING *
      `).then((r) => r.rows || r);

      if (!so) {
        return sendNotFound(res, "Service Order");
      }

      logger.info(`Linked service order ${serviceOrderId} to work order ${workOrderId}`);
      res.json(so);
    })
  );

  // ── Auto-update WO status when SO status changes ────────────────────────
  // This is a webhook/trigger pattern — call after SO status transitions
  app.post(
    "/api/service-orders/:id/sync-work-order-status",
    requireOrgIdAndValidateBody,
    writeOperationRateLimit,
    withErrorHandling("sync work order status from service order", async (req: Request, res: Response) => {
      const orgId = getOrgId(req);
      const serviceOrderId = req.params.id;

      // Get the SO and its linked WO
      const [so] = await db.execute(sql`
        SELECT id, work_order_id, status, so_number
        FROM service_orders
        WHERE id = ${serviceOrderId} AND org_id = ${orgId}
      `).then((r) => r.rows || r);

      if (!so || !so.work_order_id) {
        return res.json({ synced: false, reason: "No linked work order" });
      }

      // Check if ALL service orders for this WO are completed
      const [soStatus] = await db.execute(sql`
        SELECT
          COUNT(*)::int AS total,
          COUNT(*) FILTER (WHERE status = 'completed')::int AS completed,
          COUNT(*) FILTER (WHERE status = 'cancelled')::int AS cancelled
        FROM service_orders
        WHERE work_order_id = ${so.work_order_id} AND org_id = ${orgId}
      `).then((r) => r.rows || r);

      const allDone = soStatus.completed + soStatus.cancelled === soStatus.total;

      if (allDone && soStatus.completed > 0) {
        // All SOs done → move WO back to in_progress (service work complete, WO can resume)
        await db.execute(sql`
          UPDATE work_orders
          SET
            status = CASE
              WHEN status = 'awaiting_service' THEN 'in_progress'
              ELSE status
            END,
            updated_at = NOW(),
            notes = COALESCE(notes, '') || E'\n[' || NOW()::text || '] All service orders completed — work order resumed.'
          WHERE id = ${so.work_order_id} AND org_id = ${orgId}
        `);
        return res.json({ synced: true, workOrderStatus: "in_progress", reason: "All service orders completed" });
      }

      res.json({ synced: false, reason: `${soStatus.total - soStatus.completed - soStatus.cancelled} service orders still active` });
    })
  );
}
