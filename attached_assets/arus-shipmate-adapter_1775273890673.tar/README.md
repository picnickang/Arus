# ARUS ↔ SHIPMATE Integration Adapter

## What This Is

An import adapter that reads data exported from **SBN SHIPMATE** (the PMS/ERP system currently used by ARUS Sdn Bhd) and feeds it into the ARUS AI/analytics platform.

**ARUS does not replace SHIPMATE.** SHIPMATE remains the system of record for:
- Planned Maintenance (PMS) — Bureau Veritas class-certified
- Stores & Procurement (SPS)
- Crew Management & Payroll (CMS)
- Quality & Safety (HSEQ)
- Ship-to-shore data replication

**ARUS adds on top of SHIPMATE:**
- Predictive maintenance from sensor telemetry + SHIPMATE job history
- AI equipment health scoring (health index, RUL prediction, failure mode analysis)
- RAG knowledge base — ask "what was the last failure mode for the turbocharger?" and get answers from years of SHIPMATE job records
- Real-time digital twins fed by EFMS and other telemetry
- CII/emissions analytics
- Fleet dashboards with cost trends, MTBF, and risk scoring

## SHIPMATE Modules Supported

| Module | SHIPMATE Source | ARUS Usage | Read-Only? |
|--------|---------------|------------|------------|
| `pms_equipment` | Equipment Register | Equipment hierarchy, specs, running hours for PdM baseline | No — creates/updates equipment |
| `pms_jobs` | Job History / Completed WOs | Maintenance history → RAG knowledge base + MTBF analysis | No — creates work order records |
| `sps_stores` | Spare Parts & ROB | Stock levels, parts catalog, hazmat classification | No — creates/updates parts + stock |
| `cms_crew_certs` | Crew Certificates | STCW compliance dashboard, expiry alerts | Yes — analytics only |
| `cms_rest_hours` | Work & Rest Hours | MLC compliance, fatigue risk scoring | Yes — analytics only |

## How to Export from SHIPMATE

SHIPMATE's export path depends on your installation. Common options:

1. **PMS Reports → Export to CSV**: In SHIPMATE PMS, run the Equipment Register report or Job History report, then use the export/download function (usually top-right of the report view)
2. **SPS Reports → Export to CSV**: Run the ROB (Remaining On Board) report for a vessel, export to CSV
3. **Database export**: If ARUS and SHIPMATE run on the same vessel server, query SHIPMATE's database directly (typically SQL Server or PostgreSQL)
4. **Ship-to-shore replication files**: SHIPMATE's replication can be configured to drop CSV snapshots that ARUS picks up automatically

## Integration Steps

### 1. Copy adapter files

```
server/import-adapters/shipmate/
├── index.ts           — Barrel export
├── field-mapping.ts   — SHIPMATE field → ARUS schema mapping
├── import-service.ts  — Import orchestrator with hierarchy + RAG
└── routes.ts          — REST API endpoints
```

### 2. Register routes

```typescript
import { shipmateImportRouter } from "./import-adapters/shipmate/index.js";

app.use("/api/import/shipmate", shipmateImportRouter);
```

### 3. Import equipment register (one-time setup per vessel)

```bash
# Preview first (dry run)
curl -X POST http://localhost:5000/api/import/shipmate/preview \
  -H "Content-Type: application/json" \
  -H "x-org-id: default-org-id" \
  -d '{
    "module": "pms_equipment",
    "vesselName": "Green Belait",
    "filename": "equipment-register.csv",
    "content": "Component No,Component Name,System,Maker,Model,Serial No,Criticality,Running Hours\n1,Main Engine,Propulsion,MAN,6S50ME-C,12345,Critical,4523.5\n1.1,Turbocharger,Propulsion,ABB,A175-L,67890,Essential,4523.5\n1.1.1,TC Bearing Assembly,Propulsion,SKF,23130,,Important,4523.5\n1.2,Fuel Injection System,Propulsion,MAN,,FIS-001,Critical,4523.5\n2,Generator No.1,Electrical,Caterpillar,3516B,GEN-001,Critical,3100.2"
  }'
```

### 4. Import job history (feeds RAG knowledge base)

```bash
curl -X POST http://localhost:5000/api/import/shipmate \
  -H "Content-Type: application/json" \
  -H "x-org-id: default-org-id" \
  -d '{
    "module": "pms_jobs",
    "vesselName": "Green Belait",
    "feedToRag": true,
    "filename": "job-history-2023-2025.csv",
    "content": "Job No,Job Name,Component No,Job Type,Status,Done Date,Actual Hours,Remarks\nGB-PM-0001,Turbocharger overhaul,1.1,Preventive,Completed,15-Jan-2024,24,Replaced bearing assembly and seals\nGB-CM-0015,Fuel injector replacement,1.2,Corrective,Completed,22-Mar-2024,8,Injector #3 failed - scoring on nozzle tip\nGB-PM-0042,Generator 500hr service,2,Preventive,Completed,01-Jun-2024,6,Oil change and filter replacement"
  }'
```

### 5. Import stores/ROB

```bash
curl -X POST http://localhost:5000/api/import/shipmate \
  -H "Content-Type: application/json" \
  -H "x-org-id: default-org-id" \
  -d '{
    "module": "sps_stores",
    "vesselName": "Green Belait",
    "content": "Part No,Part Name,Category,Maker,ROB,Min Stock,Unit Price,Location,Component No\nSP-001,Oil Filter Element,Filters,MANN,12,5,45.00,Engine Store,1\nSP-002,TC Bearing Kit,Bearings,SKF,2,1,1250.00,Engine Store,1.1.1\nSP-003,Fuel Injector Nozzle,Fuel System,MAN,4,2,890.00,Engine Store,1.2"
  }'
```

## SHIPMATE-Specific Handling

### Component Number Hierarchy
SHIPMATE uses dot notation for equipment hierarchy: `1.2.3` means level 3 under parent `1.2`. The adapter automatically extracts parent-child relationships:
- `1` → top-level (no parent)
- `1.1` → parent is `1`
- `1.1.1` → parent is `1.1`

The import service sorts rows by hierarchy depth (parents first) so FK references resolve correctly.

### Header Normalization
SHIPMATE installations use inconsistent CSV headers. The adapter normalizes common variations:
- "Comp No" / "Comp. No" / "Component No." → "Component No"
- "R.O.B" / "R.O.B." / "ROB" / "Qty On Board" → "ROB"
- "Maker Name" / "Mfr" → "Manufacturer"
- "Running Hrs" / "Run Hrs" → "Running Hours"

### Date Formats
SHIPMATE uses DD-MMM-YYYY (e.g., "15-Jan-2024") in most installations. The adapter also handles DD/MM/YYYY and ISO formats.

### Crew Data (Read-Only)
Crew certificates and work/rest hours are imported for **analytics only**. ARUS does not write crew data back — SHIPMATE remains the system of record for crew management. This prevents conflicts with SHIPMATE's crew scheduling and payroll modules.

## What the RAG Integration Enables

After importing SHIPMATE job history with `feedToRag: true`, the AI assistant can answer:

- "What was the last failure mode for the turbocharger?" → Finds the corrective WO from SHIPMATE
- "When was the last time we overhauled component 1.1?" → Finds the preventive WO with date and hours
- "What spare parts do we need for a generator service?" → Cross-references job records with parts catalog
- "How many hours between turbocharger overhauls?" → Calculates MTBF from job history running hours

This is the core value proposition: SHIPMATE has the data, ARUS makes it searchable and intelligent.
