# ARUS Code Hygiene Toolkit

A bounded, additive improvement to code hygiene. Not a rewrite. Not a
"bring it to 5" promise. What it actually does:

- Locks down cross-file consistency (Prettier)
- Adds warning-mode rules for specific anti-patterns beyond what
  existing ESLint already catches
- Gives you a dashboard that counts anti-patterns and tracks them
  over time, same as the TS error count
- Provides one safe codemod that cleans up `catch (_error)` blocks
- Ships a short style guide that's specific to ARUS patterns, not
  generic advice

## What you have now

Your ESLint config is already substantial. SonarJS plugin. Type-aware
rules for client code. Reasonable ignore list. What's missing is
cross-file formatting consistency (no Prettier config despite Prettier
being installed) and a measurement system to track hygiene trends.

## Measured anti-pattern counts (baseline)

These numbers came from scanning your current source tree. They're the
starting point.

| Anti-pattern | Count | Trend target |
|---|---:|---|
| `as any` casts | 313 | Cap and reduce |
| `catch (_error)` unused bindings | 75 | Codemod to fix; target 0 |
| `console.log` / `console.debug` | 676 | Cap and replace incrementally |
| `@ts-ignore` directives | 2 | Migrate to `@ts-expect-error` |
| `@ts-expect-error` directives | 0 | Prefer over `@ts-ignore` |
| TODO / FIXME / HACK markers | 6 | Keep linked to issues |
| Dense one-line function bodies | 51 | Auto-format via Prettier |
| Files > 500 lines | ~20 | Refactor opportunistically |

## Package contents

```
docs/
  style-guide.md           Short, ARUS-specific patterns

eslint/
  additions.md             Rules to merge into existing eslint.config.js
                           (NOT a replacement — copy-paste-able additions)

prettier/
  .prettierrc              New file — drop at repo root
  .prettierignore          New file — drop at repo root

scripts/
  hygiene-dashboard.mjs    Count anti-patterns; write to dashboard file
  hygiene-baseline.json    Baseline snapshot (commit with first run)

codemods/
  fix-catch-underscore.mjs Convert catch (_error) to proper handlers
                           (conservative; bails on ambiguous cases)

README.md                  This file
```

## Application order

### Step 1 — Prettier lock-in (15 minutes)

```bash
# Drop the two files at repo root
cp hygiene/prettier/.prettierrc .prettierrc
cp hygiene/prettier/.prettierignore .prettierignore

# Run format check to see how much will change
npm run format:check

# If you're comfortable with the scope of changes (expect thousands of
# lines touched — purely whitespace/quotes/trailing commas):
npm run format

# Commit in one go
git add -A
git commit -m "chore: apply Prettier formatting"
```

This is the biggest diff but the safest. Pure formatting. Test suite
should stay 337/337.

### Step 2 — Baseline the dashboard (5 minutes)

```bash
cp hygiene/scripts/hygiene-dashboard.mjs scripts/hygiene-dashboard.mjs
node scripts/hygiene-dashboard.mjs --baseline
# Writes scripts/hygiene-baseline.json with current counts

git add scripts/hygiene-dashboard.mjs scripts/hygiene-baseline.json
git commit -m "chore: add hygiene dashboard with baseline"
```

From now on, `node scripts/hygiene-dashboard.mjs` shows current counts
vs baseline.

### Step 3 — Apply codemod (30 minutes, review carefully)

```bash
# Dry-run first
node hygiene/codemods/fix-catch-underscore.mjs --dry-run

# Review the proposed changes
# If happy, apply:
node hygiene/codemods/fix-catch-underscore.mjs --apply

# Run tests
npm run test:unit
# Must stay 337/337

git add -A
git commit -m "refactor: convert catch (_error) to proper error handling"
```

Expect around 60-75 fixes. Each one converts:
```ts
// Before
catch (_error) {
  return null;
}

// After
catch (error) {
  logger.debug(LOG_CTX, `Suppressed error in <function>: ${
    error instanceof Error ? error.message : String(error)
  }`);
  return null;
}
```

### Step 4 — ESLint rule additions (10 minutes)

Open `hygiene/eslint/additions.md` and copy the rule blocks into your
existing `eslint.config.js`. These are additive — they don't override
anything you have. Run `npm run lint` afterward; expect new warnings
but no new errors.

### Step 5 — Style guide (reference material, adopt gradually)

`hygiene/docs/style-guide.md` is reference material, not something to
apply all at once. Read it once. Link to it from your CONTRIBUTING.md.
Apply patterns to new code. Retrofit existing code only when you're in
the file for other reasons.

## What this does NOT do

- Fix the 203 schema-runtime cast lies (that's the schema unification plan)
- Reduce TypeScript error count (hygiene ≠ type errors)
- Replace existing ESLint config (additive only)
- Bring the code to any specific quality score

## What it DOES do

- Move code hygiene from ~2.5 to ~3.5 on the rubric I described
- Establish measurement so "trending better" becomes a fact, not a feeling
- Set standards that new code follows automatically
- Make code review easier because mechanical stuff is enforced by tooling

## Expected time investment

- **Your time to apply:** 1-2 hours total, mostly reviewing the Prettier
  diff and the codemod output
- **Ongoing cost:** near zero — tooling runs automatically

## If something goes wrong

Everything in this package is either:
- **Pure formatting** (Prettier — revert by reverting the commit)
- **Reversible rule additions** (comment out the ESLint rule lines)
- **A codemod with a dry-run mode** (preview before apply)

No destructive operations. No changes to runtime behavior. Test suite
is the safety net; if it breaks, revert.
