# ESLint Additions for ARUS

## What this is

Additive rules to merge into your existing `eslint.config.js`. Not a replacement.

Your current config already has a strong base: SonarJS, unused-imports,
type-aware rules for client code, reasonable ignores. This document adds
**targeted rules for anti-patterns the existing config doesn't catch**,
and nothing else.

**Philosophy:** warning-mode ratchet. New code must fix warnings to land.
Existing code gets cleaned up incidentally when it's edited. No PR-blocking
rule additions until the warning count is near zero.

---

## Additions

Each section below can be copy-pasted into your existing `eslint.config.js`
at the indicated location. Each one is independent — you can adopt them in
any order or skip any that don't fit.

### A. In the main TypeScript rules block

Add these to the `rules: { ... }` object in the config block that applies to
`**/*.ts` and `**/*.tsx`:

```js
// ============ HYGIENE ADDITIONS ============

// Prefer @ts-expect-error over @ts-ignore.
// @ts-expect-error fails lint once the underlying error is fixed,
// signalling the suppression can be removed. @ts-ignore doesn't.
'@typescript-eslint/ban-ts-comment': ['warn', {
  'ts-ignore': 'allow-with-description',
  'ts-expect-error': 'allow-with-description',
  'ts-nocheck': true,
  'ts-check': false,
  minimumDescriptionLength: 10,
}],

// Flag empty catch blocks even with the previous `allowEmptyCatch: false`.
// The existing `no-empty` rule covers this; this rule catches the
// subtler case where catch does "nothing useful".
// Already partly covered by sonarjs/no-useless-catch, which is 'error'.
// Nothing to add here — note for clarity.

// Require curly braces around if/else bodies (ARUS Rule 5.x).
// Already set to 'curly': ['error', 'all'] in existing config. No add.

// Catch underscore-prefix bindings — encourage bare `catch` instead.
// This is a pattern rule; the codemod handles the one-time cleanup.
// Ongoing enforcement via no-restricted-syntax:
'no-restricted-syntax': [
  // NOTE: there's already a no-restricted-syntax rule in the config
  // for toLocaleString / Intl formatters. MERGE this array with that one
  // rather than replacing.
  'warn',
  // ... keep existing entries ...
  {
    selector: "CatchClause[param.type='Identifier'][param.name=/^_/]",
    message: 'Underscore-prefixed catch bindings (catch (_error)) suggest unused errors. Use bare `catch { }` or handle the error explicitly.',
  },
],

// Forbid direct `throw new Error(string)` — prefer typed errors.
// Soft warning; lots of places legitimately throw generic errors.
// Skip this one unless you're ready to audit existing throws.
// '@typescript-eslint/only-throw-error': 'warn',

// Require return types on exported functions — catches API-shape changes
// at the definition site rather than at use sites.
// Warning-only because the existing codebase doesn't have this everywhere.
'@typescript-eslint/explicit-module-boundary-types': ['warn', {
  allowArgumentsExplicitlyTypedAsAny: false,
  allowDirectConstAssertionInArrowFunctions: true,
  allowedNames: [],
  allowHigherOrderFunctions: true,
  allowTypedFunctionExpressions: true,
}],

// Prefer Promise.all over sequential awaits when the values are independent.
// This one will produce a lot of warnings if turned on now — keep disabled
// until the lower-hanging fruit is cleared.
// 'require-await': 'warn',

// Flag `Promise.resolve(x).then(...)` patterns that could be async/await.
// Pattern detector; low priority.
// 'promise/no-nesting': 'warn',  // requires eslint-plugin-promise
```

### B. New config block for database files

Append this as a new element in the exported array, after the existing
"Shared schema files" block:

```js
// ARUS hygiene: database access layer rules
{
  files: ['server/db/**/*.ts', 'server/domains/*/repository.ts'],
  rules: {
    // Require explicit return types on repository methods — they're the
    // API surface between the service layer and the DB.
    '@typescript-eslint/explicit-function-return-type': ['warn', {
      allowExpressions: true,
      allowTypedFunctionExpressions: true,
      allowHigherOrderFunctions: true,
      allowDirectConstAssertionInArrowFunctions: true,
    }],

    // Discourage console.log in repository code — use structured logger.
    // (Server-wide config already allows console.log; this narrows it for
    // the DB layer where structured logging matters more.)
    'no-console': ['warn', {
      allow: ['warn', 'error'],
    }],
  },
},
```

### C. Stricter `any` policy for route handlers

ARUS already allows `any` in adapter/ingestion paths. Route handlers should
be stricter — they're the boundary where external data becomes typed:

```js
// ARUS hygiene: route handlers should NOT use `any`
{
  files: [
    'server/domains/*/routes/**/*.ts',
    'server/domains/*/interfaces/**/*.ts',
    'server/routes/**/*.ts',
  ],
  rules: {
    // Upgrade from 'warn' to 'error' specifically at the HTTP boundary.
    // Use Zod schemas instead. The existing adapters/ingestion block
    // still allows `any` via the earlier override.
    '@typescript-eslint/no-explicit-any': 'error',
  },
},
```

**Caveat:** this will break the lint check if there are existing `any` usages
in route files. Run `npm run lint 2>&1 | grep "no-explicit-any" | wc -l`
before enabling. If the count is > 0, start with `'warn'` and ratchet to
`'error'` after cleanup.

### D. Enforce async-await consistency

```js
// In the main TypeScript rules block:
'no-return-await': 'warn',        // already in existing config
'no-async-promise-executor': 'error',
'require-atomic-updates': 'warn',  // catches race conditions in async loops
```

`require-atomic-updates` occasionally has false positives but when it's right,
it's very right — it catches the class of bug where `await` inside a loop
mutates shared state and a concurrent iteration clobbers it.

### E. Import ordering (optional, cosmetic)

Only add this if you're prepared for the initial auto-fix to touch every
file. Prettier doesn't reorder imports; ESLint's `sort-imports` does.

```js
// In the main TypeScript rules block, add:
'sort-imports': ['warn', {
  ignoreCase: false,
  ignoreDeclarationSort: true,  // let Prettier handle line-level
  ignoreMemberSort: false,      // but do sort named imports within a line
  memberSyntaxSortOrder: ['none', 'all', 'multiple', 'single'],
  allowSeparatedGroups: true,
}],
```

Skip if the diff would be too large. This is low-ROI; don't prioritize it.

---

## How to adopt

1. **Decide scope.** Read through A–E above, pick what fits your next
   sprint. You can adopt all five, any subset, or none of them. Every block
   is independently valuable.
2. **Measure before.** Run `npm run lint 2>&1 | grep "problem" | head -1`
   and note the warning/error count.
3. **Apply one block at a time.** Copy the rule changes into
   `eslint.config.js`, re-run lint, measure the new count. If the delta is
   huge and you're not ready, revert that block and come back later.
4. **Don't ratchet to error without reviewing.** All of the above are
   `warn` by default. Upgrading any of them to `error` blocks PRs. Only do
   that after the existing warnings for that rule are at zero.

## What's deliberately excluded

These rules would be good but add complexity disproportionate to their
benefit right now:

- **`@typescript-eslint/strict-boolean-expressions`** — existing config
  explicitly disables this as too strict. The codebase uses truthy checks
  on nullable booleans heavily; enforcing strictness would be a multi-week
  refactor.
- **`@typescript-eslint/no-floating-promises`** — type-aware, needs
  project-wide `parserOptions.project`. Your config only enables type-aware
  rules for client code. Adding server-side type-aware would cost lint
  performance.
- **`@typescript-eslint/prefer-readonly`** — encourages immutability but
  large diff and debatable value for a service-oriented codebase.
- **`unicorn/*` rules** — many are opinionated (`prefer-node-protocol`,
  `no-array-for-each`) and would require a big cleanup pass.
- **`import/*` rules** — ARUS uses path aliases (`@shared`, `@server`) and
  `eslint-plugin-import` sometimes fights aliases. Not worth the config
  tuning.

If you want any of these later, add them then. No need to front-load
complexity.

---

## A note on the SonarJS rules you already have

Your existing config uses 15+ SonarJS rules. This is unusually thorough.
Don't relax them. Most of them are catching real problems
(`no-identical-conditions`, `no-identical-functions`, `no-collection-size-mischeck`)
that would be bugs if introduced.

The warning-level SonarJS rules (`prefer-immediate-return`,
`no-collapsible-if`) are cosmetic; leave them as warnings, don't ratchet
to error.

---

## Ratchet strategy

A ratchet is: "warnings are allowed, but the warning count can only go
down, never up." This is what turns a lint config into a forcing function.

To implement:

1. Run `npm run lint 2>&1 | grep -c "warning"` — note the baseline count.
2. Add a CI step: lint runs, count warnings, fail if count > baseline.
3. When the count drops (after cleanup work), update the baseline.
4. Over time, the baseline drops toward zero, at which point you can
   ratchet specific rules to `'error'`.

This is an evolution of the TS-error-count approach that worked for the
bug-fix waves. Same pattern, different metric. You can use the hygiene
dashboard script's `--strict` mode for the same effect on the mechanical
anti-patterns it tracks.

---

## Summary

| Block | What it adds | Risk | Prerequisite |
|---|---|---|---|
| A | ts-comment policy, catch underscore ban, return types | Low | None |
| B | Return types in DB layer | Low | None |
| C | No-any in route handlers | Medium | Audit existing `any` in routes first |
| D | Async-await consistency | Low | None |
| E | Import ordering | Low | Accepts whole-codebase auto-fix |

Start with A and B. Add C once you've audited route-file `any` usage. D is
a small add. E is optional cosmetic.
