/**
 * Home Page Role Configurations
 *
 * FIX: Extracted from inline definition in home.tsx to a shared config.
 * Updated quick actions to point to current navigation targets.
 *
 * Changes from inline version:
 *   - Chief Engineer: "Check PdM Alerts" → "Fleet Intelligence" → /equipment-intelligence
 *   - Fleet Manager: pinnedGroups updated to match current nav structure
 */

import {
  Wrench, AlertTriangle, Clock, Activity, Ship, Shield,
  ClipboardCheck, Anchor, BookOpen, BarChart3, Settings,
  Brain, Gauge,
} from "lucide-react";

export interface QuickActionDef {
  label: string;
  icon: any;
  href: string;
  variant?: "default" | "destructive" | "outline";
}

export interface RoleConfig {
  id: string;
  label: string;
  description: string;
  icon: any;
  quickActions: QuickActionDef[];
  pinnedGroups: string[];
}

export const ROLES: Record<string, RoleConfig> = {
  chief_engineer: {
    id: "chief_engineer",
    label: "Chief Engineer",
    description: "Work orders, equipment health, PdM alerts",
    icon: Wrench,
    quickActions: [
      { label: "New Work Order", icon: ClipboardCheck, href: "/work-orders?action=create" },
      { label: "Fleet Intelligence", icon: Brain, href: "/equipment-intelligence" },
      { label: "Log Engine Entry", icon: BookOpen, href: "/engine-logbook?action=new" },
      { label: "Report Defect", icon: AlertTriangle, href: "/work-orders?action=create&type=corrective" },
    ],
    pinnedGroups: ["maintenance", "operations", "fleet"],
  },
  deck_officer: {
    id: "deck_officer",
    label: "Deck Officer",
    description: "Logbooks, STCW hours, vessel track, weather",
    icon: Anchor,
    quickActions: [
      { label: "New Deck Entry", icon: BookOpen, href: "/deck-logbook?action=new" },
      { label: "Record Rest Hours", icon: Clock, href: "/hours-of-rest?action=record" },
      { label: "Vessel Position", icon: Ship, href: "/vessel-track-log" },
      { label: "Compliance Check", icon: Shield, href: "/logs-compliance" },
    ],
    pinnedGroups: ["records", "crew", "operations"],
  },
  fleet_manager: {
    id: "fleet_manager",
    label: "Fleet Manager (Shore)",
    description: "Fleet health, CII compliance, analytics, costs",
    icon: BarChart3,
    quickActions: [
      { label: "Fleet Dashboard", icon: Gauge, href: "/dashboard" },
      { label: "Fleet Intelligence", icon: Brain, href: "/equipment-intelligence" },
      { label: "Analytics", icon: BarChart3, href: "/analytics" },
      { label: "Governance", icon: Shield, href: "/governance-dashboard" },
    ],
    pinnedGroups: ["operations", "analytics", "fleet"],
  },
  system_admin: {
    id: "system_admin",
    label: "System Admin",
    description: "Diagnostics, configuration, sensors, AI admin",
    icon: Settings,
    quickActions: [
      { label: "Diagnostics", icon: Activity, href: "/diagnostics" },
      { label: "Copilot Admin", icon: Brain, href: "/copilot-admin" },
      { label: "Configuration", icon: Settings, href: "/configuration" },
      { label: "Sensor Management", icon: Activity, href: "/sensors" },
    ],
    pinnedGroups: ["system", "analytics", "operations"],
  },
};
