/**
 * Work Order Completion Routes — LEGACY RETIRED
 *
 * The POST /api/work-orders/:id/complete endpoint is now a thin redirect
 * to the workflow service's completeWithFeedback method.
 *
 * This ensures:
 *   - All completion paths go through one service method
 *   - Prediction feedback is always processed when available
 *   - Savings auto-void fires on every cancellation
 *   - No "two paths" for the same operation
 *
 * The GET routes (completions list, analytics, by-work-order) are preserved
 * unchanged — they were never duplicated.
 */

import type { Express, Request, Response } from "express";
import { workOrderAppService as workOrderService } from "../application";
import { requireOrgId, requireOrgIdAndValidateBody, type AuthenticatedRequest } from "../../../middleware/auth";
import { withErrorHandling, sendNotFound, sendCreated } from "../../../lib/route-utils";
import type { RateLimitMiddleware } from "./types";
import {
  WorkOrderWorkflowRepositoryAdapter,
  CostSavingsWorkflowAdapter,
  PredictionFeedbackWorkflowAdapter,
} from "../infrastructure/workflow-adapters";
import { WorkOrderWorkflowService } from "../application/wo-workflow-service";

// Singleton workflow service for the legacy route redirect
let _workflowService: WorkOrderWorkflowService | null = null;
function getWorkflowService(): WorkOrderWorkflowService {
  if (!_workflowService) {
    _workflowService = new WorkOrderWorkflowService(
      new WorkOrderWorkflowRepositoryAdapter(),
      new CostSavingsWorkflowAdapter(),
      new PredictionFeedbackWorkflowAdapter(),
    );
  }
  return _workflowService;
}

export function registerCompletionRoutes(app: Express, rateLimit: RateLimitMiddleware) {
  const { writeOperationRateLimit } = rateLimit;

  /**
   * POST /api/work-orders/:id/complete
   *
   * RETIRED: This now delegates to WorkOrderWorkflowService.completeWithFeedback().
   * Callers that pass predictionFeedback in the body get the full feedback flow.
   * Callers that don't (legacy clients) still get completion + savings calculation.
   *
   * The old code path that manually assembled completion data, parsed schemas,
   * and called workOrderService.completeWorkOrder() is removed. The workflow
   * service handles status update, procurement cost aggregation, savings
   * calculation, and prediction feedback in one atomic operation.
   */
  app.post("/api/work-orders/:id/complete", requireOrgIdAndValidateBody, writeOperationRateLimit,
    withErrorHandling("complete work order", async (req: Request, res: Response) => {
      const orgId = (req as AuthenticatedRequest).orgId;
      const userId = (req as any).userId || (req as any).user?.id || req.headers["x-user-id"] || "system";
      const workOrderId = req.params.id;

      const result = await getWorkflowService().completeWithFeedback(
        {
          workOrderId,
          orgId,
          completionNotes: req.body.completionNotes || req.body.notes,
          actualHours: req.body.actualDowntimeHours || req.body.actualHours,
          predictionFeedback: req.body.predictionFeedback || undefined,
        },
        userId as string,
      );

      if (!result.completed) {
        if (result.error === "Work order not found") {
          return sendNotFound(res, "Work order");
        }
        return res.status(400).json({ message: result.error });
      }

      // Return in the shape legacy callers expect
      res.status(201).json({
        workOrderId: result.workOrderId,
        completed: true,
        savingsCalculated: result.savingsCalculated,
        savingsValidationStatus: result.savingsValidationStatus,
        predictionFeedbackRecorded: result.predictionFeedbackRecorded,
      });
    })
  );

  // ── GET routes below are NOT legacy — they're the only path for these queries ──

  app.get("/api/work-order-completions", requireOrgId,
    withErrorHandling("fetch work order completions", async (req: Request, res: Response) => {
      const { equipmentId, vesselId, startDate, endDate } = req.query;
      const orgId = (req as AuthenticatedRequest).orgId;

      const filters = {
        equipmentId: equipmentId as string | undefined,
        vesselId: vesselId as string | undefined,
        startDate: startDate ? new Date(startDate as string) : undefined,
        endDate: endDate ? new Date(endDate as string) : undefined,
        orgId,
      };

      const completions = await workOrderService.getCompletions(filters);
      res.json(completions);
    })
  );

  app.get("/api/work-order-completions/analytics", requireOrgId,
    withErrorHandling("fetch work order completion analytics", async (req: Request, res: Response) => {
      const { equipmentId, vesselId, startDate, endDate } = req.query;
      const orgId = (req as AuthenticatedRequest).orgId;

      const filters = {
        equipmentId: equipmentId as string | undefined,
        vesselId: vesselId as string | undefined,
        startDate: startDate ? new Date(startDate as string) : undefined,
        endDate: endDate ? new Date(endDate as string) : undefined,
        orgId,
      };

      const analytics = await workOrderService.getWorkOrderCompletionAnalytics(filters);
      res.json(analytics);
    })
  );

  app.get("/api/work-order-completions/:id", requireOrgId,
    withErrorHandling("fetch work order completion", async (req: Request, res: Response) => {
      const completion = await workOrderService.getWorkOrderCompletion(req.params.id);
      if (!completion) {
        return sendNotFound(res, "Work order completion");
      }
      res.json(completion);
    })
  );

  app.get("/api/work-orders/:id/completions", requireOrgId,
    withErrorHandling("fetch work order completions", async (req: Request, res: Response) => {
      const completions = await workOrderService.getWorkOrderCompletionsByWorkOrder(req.params.id);
      res.json(completions);
    })
  );
}
