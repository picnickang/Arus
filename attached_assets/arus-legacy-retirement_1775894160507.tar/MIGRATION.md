# Legacy Retirement — Migration Guide

## What This Retires

One concept: **work order completion has one path, not two.**

Before this package, completing a work order could happen through:
1. `POST /api/work-orders/:id/complete` (legacy, in `completion.ts`)
2. `POST /api/work-orders/:id/complete-with-feedback` (new, in `workflow-routes.ts`)
3. `useCompleteWorkOrder()` hook calling the legacy endpoint
4. `completeWorkOrderMutation` in `useWorkOrdersPageData` calling the legacy endpoint

After this package:
- **One server path**: Both URLs delegate to `WorkOrderWorkflowService.completeWithFeedback()`
- **One client path**: All hooks call `/complete-with-feedback` directly
- **No fallback**: The client doesn't try one URL then fall back to another
- **Backward compatible**: The old `/complete` URL still works (for bookmarked API calls, 
  Tauri desktop clients, etc.) but internally runs the same code

## Files (all drop-in replacements)

| File | What changed |
|------|-------------|
| `server/domains/work-orders/interfaces/completion.ts` | Legacy `POST /complete` now delegates to `WorkOrderWorkflowService.completeWithFeedback()` instead of running its own completion logic. GET routes unchanged. |
| `client/src/features/work-orders/hooks/useWorkOrders.ts` | `useCompleteWorkOrder()` calls `/complete-with-feedback` directly. Accepts `predictionFeedback` param. |
| `client/src/features/work-orders/hooks/useWorkOrdersPageData.ts` | `completeWorkOrderMutation` calls `/complete-with-feedback` directly. No fallback. |
| `client/src/pages/work-orders.tsx` | `onComplete` passes `{ orderId, predictionFeedback }` to mutation. |
| `client/src/components/work-orders/WorkOrderDetailDrawer.tsx` | `onComplete` callback signature includes optional prediction feedback. |
| `client/src/pages/home.tsx` | ROLES imported from config. Quick WO FAB on left side. |
| `client/src/config/roles.ts` | Extracted ROLES config. Single source of truth. |

## What Convergence Looks Like After This

| Concern | Before | After |
|---------|--------|-------|
| WO completion path | 2 server endpoints × 2 client hooks | 1 service method, 2 URLs (both delegate to it) |
| ROLES config | Inline in home.tsx + separate config/roles.ts | Single import from config/roles.ts |
| Prediction feedback | Collected by form, never sent to server | Flows through mutation → endpoint → service → savings validation |
| Quick WO FAB position | Overlaps CopilotFab on desktop | Left side, no overlap |
| Savings on false alarm | Counted as "valid" | Auto-disputed with audit trail |
| Savings on cancellation | May or may not void | Always voided (cancelWithVoid in service) |

## Integration

All files are drop-in replacements. No new dependencies. No schema changes.

```bash
# Copy all files into your project
cp server/domains/work-orders/interfaces/completion.ts → your project
cp client/src/features/work-orders/hooks/useWorkOrders.ts → your project
cp client/src/features/work-orders/hooks/useWorkOrdersPageData.ts → your project
cp client/src/pages/work-orders.tsx → your project
cp client/src/components/work-orders/WorkOrderDetailDrawer.tsx → your project
cp client/src/pages/home.tsx → your project
cp client/src/config/roles.ts → your project (new file)
```

## What ChatGPT Said vs What This Fixes

| ChatGPT's concern | Status after this package |
|---|---|
| "Multiple patterns coexisting" | One completion path. Both URLs run the same service method. |
| "Coexisting paths causing inconsistent behavior" | Eliminated. All completion goes through WorkOrderWorkflowService. |
| "Transition debt from fallback" | Fallback removed. Client calls one endpoint. Server has one implementation. |
| "Legacy fallbacks left in place" | The old URL still works but runs new code — not a fallback, a redirect. |
| "One config source per concept" | ROLES extracted to config/roles.ts. Home.tsx imports it. |
