# UX Structural Redesign — Migration Guide

## Package Contents

This package implements the structural redesign from `arus-ux-structural-redesign.md`.
It builds on top of the previous `arus-ux-consolidation.tar.gz` package (shared health-risk
utilities, ARUS Copilot, navigation config, Equipment Intelligence drawer consolidation).

### Files in this package

| File | Replaces | Lines | What Changed |
|------|----------|-------|-------------|
| `pages/dashboard-improved.tsx` | Previous dashboard-improved.tsx | 340 | 5 metrics + 5 tabs + collapsibles → 3 metrics + 3 zones (Needs Attention strip, AI Summary, Activity Feed). Zero tabs. Zero collapsibles. |
| `pages/analytics-hub.tsx` | Previous analytics-hub.tsx (9-item grid) | 310 | Grid of 9 items → stacked summary with 5 headline metrics, AI Key Findings, 4 domain strips. MissionOverview's 9 cards → single paragraph. |
| `pages/knowledge-base.tsx` | Previous knowledge-base.tsx (2-tab Chat + Documents) | 320 | Chat tab deleted (Copilot handles it). Upload panel collapsed to button + drop zone. Single-purpose document list with inline search. |
| `pages/copilot-admin.tsx` | Previous copilot-admin.tsx (5-tab layout) | 420 | 5 tabs with 7+ cards → monitoring dashboard + config dialog. Status sidebar + usage overview + schedules list. Configuration opens in a dialog, not a tab. |

### Dependencies from previous package (required)

These files must be installed from `arus-ux-consolidation.tar.gz` first:

- `client/src/lib/health-risk.ts` — shared health/risk utilities
- `client/src/components/shared/ARUSCopilot.tsx` — unified AI assistant
- `client/src/config/navigationConfig.ts` — restructured navigation
- `client/src/pages/equipment-intelligence.tsx` — consolidated drawer (3 sections)

## Integration Steps

### Step 1: Install previous package first
Ensure all files from `arus-ux-consolidation.tar.gz` are in place.

### Step 2: Replace Dashboard
```bash
cp pages/dashboard-improved.tsx → client/src/pages/dashboard-improved.tsx
```
The new dashboard uses `useDashboardData()` from `@/features/analytics` — same hook
as before, but only a subset of its return values are consumed. The unused data
(devices, telemetry tables, maintenance collapsibles) is still fetched by the hook
but not rendered. This is intentional — no hook changes needed.

The `DashboardTabs` component (`components/dashboard-tabs.tsx`) is no longer imported.
It can be deleted or kept for backward compatibility.

### Step 3: Replace Analytics Hub
```bash
cp pages/analytics-hub.tsx → client/src/pages/analytics-hub.tsx
```
The new hub fetches summary data from existing endpoints:
- `/api/equipment/health` — fleet health scores
- `/api/work-orders/summary` — WO counts and completion rate
- `/api/pdm/cost-savings/summary` — financial metrics
- `/api/reconciliation/status` — data integrity score

The full mode pages (OperationsMode, MaintenanceMode, FinanceMode,
DataIntegrityDashboard) are NOT changed — they load as separate routes
when "Open" is clicked. The hub just shows their headline numbers.

Equipment Intelligence, Knowledge Base, KB Assistant, and Optimizer are
removed from the grid. They have their own pages accessed via navigation.

### Step 4: Replace Knowledge Base
```bash
cp pages/knowledge-base.tsx → client/src/pages/knowledge-base.tsx
```
Chat tab is deleted. The `ChatInterface` component is no longer imported.
The `useKnowledgeBase` hook from `@/features/ml-ai` is still used for
documents, search, and upload. No backend changes needed.

Add this redirect for the old KB Chat route:
```tsx
// In your router setup
{ from: "/kb-chat", to: "/knowledge-base" }
```

### Step 5: Replace Copilot Admin
```bash
cp pages/copilot-admin.tsx → client/src/pages/copilot-admin.tsx
```
Same API endpoints as before. The 5 tabs are restructured into:
- Main view: usage overview + schedules list
- Dialog: all configuration settings
- Collapsed section: data management (export/purge)

Suggestions tab content is removed from this page. Suggestions can
appear as inline notifications in the Copilot itself or on the Dashboard.

### Step 6: Delete unused components (optional)

These components are no longer imported by any page after the redesign:

- `client/src/components/dashboard-tabs.tsx` — Dashboard no longer uses tabs
- `client/src/components/dashboard/FleetRisksCard.tsx` — replaced by Needs Attention strip
- `client/src/components/shared/InlineAIAssistant.tsx` — replaced by ARUSCopilot
- `client/src/components/rag/ChatInterface.tsx` — KB chat removed

Do NOT delete these immediately — keep them for 1-2 sprints in case rollback
is needed. They're just not imported anymore.

## What This Does NOT Change

- All backend APIs (no endpoint changes)
- Equipment Intelligence page (already redesigned in previous package)
- PdM Dashboard, PdM Pack, PdM Platform, Digital Twin (kept as-is)
- Work Orders, Maintenance Schedules, Templates
- Crew, Logistics, Records pages
- Vessel Dashboard, Fleet Management
- All hooks and data fetching logic

## Verification Checklist

After deploying, verify:

- [ ] Dashboard loads with 3 metric cards (no tabs visible)
- [ ] "Needs Attention" strip shows critical items when they exist
- [ ] "All Systems Nominal" shows when no critical items exist
- [ ] AI Summary paragraph renders with fleet status
- [ ] Activity Feed shows recent events
- [ ] Analytics Hub shows 5 headline metrics + 4 domain strips
- [ ] Analytics Hub "Open" buttons navigate to full mode pages
- [ ] Knowledge Base shows document list (no Chat tab)
- [ ] Upload button opens drop zone
- [ ] Semantic search triggers for question-like queries
- [ ] Copilot Admin shows monitoring dashboard (not config tabs)
- [ ] "Edit Configuration" button opens config dialog
- [ ] Schedules list shows with run/pause/delete actions
- [ ] ARUS Copilot floating button works on all pages
- [ ] `/kb-chat` redirects to `/knowledge-base`
